"""仅同步两篇现行稿的water-cycle名称；保持OOXML格式及绘图区像素。"""
from pathlib import Path
from zipfile import ZipFile
from copy import deepcopy
from datetime import datetime
from io import BytesIO
import hashlib, json, re, shutil, sys
from lxml import etree
from PIL import Image, ImageDraw, ImageFont, PngImagePlugin
import numpy as np

sys.stdout.reconfigure(encoding='utf-8')
WORK = Path(__file__).resolve().parent
BASE = Path(r'D:\科研王！\MCPE\1.0\part12\拆分稿_20261027')
SOURCES = {
    'part1': BASE / 'Part 1-Optimization of Carbon Cycling Parameters in ESMs-3.0.docx',
    'part2': BASE / 'c29同步更新_20261030' / 'Optimization of Carbon Cycling Parameters in ESM-Part 2.docx',
}
PART2_PAIR = BASE / 'Part 2-Optimization of Carbon Cycling Parameters in ESMs-3.0.docx'
NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
      'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math'}
W = '{' + NS['w'] + '}'
COUPLED = 'atmosphere–ocean–ice–land coupled'
SEPARATOR = r'[\s\-\u2010-\u2015]+'
WATER = r'\bwater' + SEPARATOR + r'cycle\b'
PATTERN = re.compile(
    r'\batmospheric and water' + SEPARATOR + r'cycle\b'
    r'|\bcoupled water' + SEPARATOR + r'cycle' + SEPARATOR + r'carbon' + SEPARATOR + r'cycle pathways\b'
    r'|\bcoupled water' + SEPARATOR + r'cycle states\b'
    r'|\bwater and carbon cycles\b'
    r'|' + WATER + r'(?= and \d+ carbon-cycle parameters)'
    r'|' + WATER, re.I)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def canonical(el):
    return etree.tostring(el, method='c14n')

def replacement(match):
    s = match.group(0)
    lower = s.lower()
    if lower.endswith('pathways'):
        result = 'coupling pathways between the ' + COUPLED + ' model and the carbon cycle'
    elif lower.startswith('coupled '):
        result = COUPLED + ' model states'
    elif lower == 'water and carbon cycles':
        result = COUPLED + ' model and the carbon cycle'
    elif lower.startswith('atmospheric and '):
        result = COUPLED + ' model'
    elif re.match(r' and \d+ carbon-cycle parameters', match.string[match.end():]):
        result = COUPLED + ' model parameters'
    else:
        result = COUPLED + ' model'
    if s[0].isupper():
        result = result[0].upper() + result[1:]
    return result

def set_span(nodes, start, end, value):
    offset = 0
    touched = []
    for node in nodes:
        text = node.text or ''
        a, b = max(start - offset, 0), min(end - offset, len(text))
        if a < b:
            touched.append((node, a, b))
        offset += len(text)
    assert touched
    for i, (node, a, b) in enumerate(touched):
        s = node.text or ''
        node.text = s[:a] + (value if i == 0 else '') + s[b:]

def edit_xml(data):
    old = etree.fromstring(data)
    root = etree.fromstring(data)
    audit = []
    for i, paragraph in enumerate(root.xpath('//w:p', namespaces=NS)):
        nodes = [n for n in paragraph.xpath('.//w:t', namespaces=NS)
                 if next(n.iterancestors(W + 'p')) is paragraph]
        before = ''.join(n.text or '' for n in nodes)
        matches = list(PATTERN.finditer(before))
        if not matches:
            continue
        for m in reversed(matches):
            set_span(nodes, m.start(), m.end(), replacement(m))
        after = ''.join(n.text or '' for n in nodes)
        assert after == PATTERN.sub(replacement, before)
        audit.append({'paragraph': i, 'before': before, 'after': after,
                      'replacements': [{'before': m.group(), 'after': replacement(m)} for m in matches]})
    assert not PATTERN.search(''.join(root.xpath('//w:t/text()', namespaces=NS)))
    old_masked, new_masked = deepcopy(old), deepcopy(root)
    for masked in (old_masked, new_masked):
        for node in masked.xpath('//w:t', namespaces=NS):
            node.text = None
    assert canonical(old_masked) == canonical(new_masked), '非文字XML结构或格式发生变化'
    for name in ('oMath', 'oMathPara'):
        assert [canonical(n) for n in old.xpath('//m:' + name, namespaces=NS)] == [canonical(n) for n in root.xpath('//m:' + name, namespaces=NS)]
    return etree.tostring(root, encoding='UTF-8', xml_declaration=True, standalone=True), audit

def image_label(tag, data):
    image = Image.open(BytesIO(data))
    original = np.array(image)
    edited = image.copy()
    draw = ImageDraw.Draw(edited)
    font_path = r'C:\Windows\Fonts\times.ttf'
    if tag == 'part1':
        box = (0, 33, image.width, 55)
        text = 'Atmosphere–ocean–ice–land coupled model parameters: 0–20 TU; carbon-cycle parameters: 0–500 TU'
        font = ImageFont.truetype(font_path, 15)
        assert draw.textlength(text, font=font) < image.width - 20
        draw.rectangle((box[0], box[1], box[2] - 1, box[3] - 1), fill='white')
        x = (image.width - draw.textlength(text, font=font)) / 2
        draw.text((x, 34), text, font=font, fill='black')
    else:
        # 第一项图例保留原基线、色块和字号，向左利用空白容纳较长名称。
        text = 'Atmosphere–ocean–ice–land coupled model parameters'
        font = ImageFont.truetype(font_path, 66)
        x = round(2172 - draw.textlength(text, font=font))
        assert x > 160
        swatch = image.crop((1412, 195, 1492, 242))
        box = (x - 140, 180, 2195, 275)
        draw.rectangle((box[0], box[1], box[2] - 1, box[3] - 1), fill='white')
        draw.text((x, 182), text, font=font, fill='black')
        edited.paste(swatch, (x - 134, 195))
    changed = np.any(original != np.array(edited), axis=2)
    allowed = np.zeros(changed.shape, dtype=bool)
    allowed[box[1]:box[3], box[0]:box[2]] = True
    assert not np.any(changed & ~allowed), '图中文字区域外像素发生变化'
    assert edited.size == image.size
    output = BytesIO()
    pnginfo = PngImagePlugin.PngInfo()
    for key, value in image.info.items():
        if isinstance(value, str):
            pnginfo.add_text(key, value)
    options = {'pnginfo': pnginfo}
    if 'dpi' in image.info:
        options['dpi'] = image.info['dpi']
    edited.save(output, format='PNG', **options)
    edited.save(WORK / (tag + '_label_revised.png'), **options)
    edited.crop((0, 0, image.width, 90 if tag == 'part1' else 450)).save(WORK / (tag + '_label_revised_top.png'))
    return output.getvalue(), {'region': box, 'new_text': text, 'font': 'Times New Roman',
                              'font_size_px': font.size, 'size_px': image.size,
                              'outside_label_pixels_unchanged': True}

def stage():
    record = {'sources': {}, 'documents': {}}
    for tag, source in SOURCES.items():
        record['sources'][tag] = {'path': str(source), 'sha256': sha(source)}
        shutil.copy2(source, WORK / ('source_' + tag + '.docx'))
        with ZipFile(source) as zin:
            xml, edits = edit_xml(zin.read('word/document.xml'))
            media = 'word/media/image5.png'
            label, image_audit = image_label(tag, zin.read(media))
            target = WORK / (tag + '_revised.docx')
            with ZipFile(target, 'w') as zout:
                for info in zin.infolist():
                    content = xml if info.filename == 'word/document.xml' else label if info.filename == media else zin.read(info.filename)
                    zout.writestr(info, content)
                zout.comment = zin.comment
        with ZipFile(source) as za, ZipFile(target) as zb:
            assert za.namelist() == zb.namelist()
            differences = [n for n in za.namelist() if za.read(n) != zb.read(n)]
            assert sorted(differences) == sorted(['word/document.xml', media])
        record['documents'][tag] = {'paragraphs_changed': len(edits),
            'phrase_replacements': sum(len(e['replacements']) for e in edits),
            'edits': edits, 'image_edit': image_audit, 'zip_members_changed': differences,
            'format_and_equations_unchanged': True, 'sha256': sha(target)}
        print(tag, len(edits), 'paragraphs;', record['documents'][tag]['phrase_replacements'], 'phrases')
    record['other_docx_before'] = {str(p): sha(p) for p in BASE.rglob('*.docx')
        if p not in SOURCES.values() and not p.name.startswith('~$')}
    (WORK / 'audit.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')

def deliver():
    audit = json.loads((WORK / 'audit.json').read_text(encoding='utf-8'))
    for tag, source in SOURCES.items():
        assert sha(source) == audit['sources'][tag]['sha256'], '底稿已有新保存，停止覆盖'
    assert not PART2_PAIR.exists(), 'Part2配套3.0已存在，避免覆盖用户新文件'
    backup = BASE / ('备份_water-cycle术语统一前_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    backup.mkdir()
    outputs = {}
    for tag, source in SOURCES.items():
        shutil.copy2(source, backup / (tag + '_修改前.docx'))
        try:
            shutil.copy2(WORK / (tag + '_revised.docx'), source)
            outputs[tag] = str(source)
        except PermissionError:
            alternate = source.with_name(source.stem + '_术语统一版.docx')
            shutil.copy2(WORK / (tag + '_revised.docx'), alternate)
            outputs[tag] = str(alternate)
    shutil.copy2(WORK / 'part2_revised.docx', PART2_PAIR)
    outputs['part2_pair'] = str(PART2_PAIR)
    for p, expected in audit['other_docx_before'].items():
        assert sha(p) == expected, '不在修改范围的文档发生变化：' + p
    for key, p in outputs.items():
        tag = 'part2' if key.startswith('part2') else 'part1'
        assert sha(p) == audit['documents'][tag]['sha256']
    result = {'outputs': outputs, 'backup': str(backup), 'render_verified': True}
    (WORK / 'delivery.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    {'stage': stage, 'deliver': deliver}[sys.argv[1]]()
