from pathlib import Path
import hashlib
B=Path(__file__).resolve().parent
failed=[];count=0
for line in (B/'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
    digest,relative=line.split('  ',1)
    p=B/relative
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:failed.append(relative)
    count+=1
if failed:raise SystemExit('FAILED: '+', '.join(failed))
print('OK:',count,'files match the archived checksums.')
