#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
cd build
gfortran -O3 -ffree-line-length-none ../01_current_model/RKmethod.f90 ../01_current_model/MCPE42_new.f90 ../01_current_model/exp21_new.f90 -o exp21_new
echo "Built exp21_new. No estimation experiment has been started."
