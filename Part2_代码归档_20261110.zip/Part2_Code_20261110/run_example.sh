#!/usr/bin/env bash
# Run only when you intend to start a full experiment. No job is submitted by this script.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CASE="${1:-$ROOT/new_runs/MCPE30_v6_seed0}"
if [ -e "$CASE" ]; then echo "Refusing to reuse an existing result directory: $CASE" >&2; exit 1; fi
mkdir -p "$CASE"
cd "$CASE"
unset MCPE_ORDER
export MCPE_SCHEME=30 MCPE_VARIANT=6 MCPE_SEED=0 MCPE_ENTRY_ARM=sync
export MCPE_FREQ=1,4,20 MCPE_PARAM_CHANNELS=x123_w_TL
export MCPE_STEPS=15000000 MCPE_EVAL=9000000 MCPE_EVAL_END=10000000
export MCPE_SAVE_PARAM_MEAN=1 MCPE_PSD=1 MCPE_PSD_START=10000000
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
"$ROOT/build/exp21_new"
