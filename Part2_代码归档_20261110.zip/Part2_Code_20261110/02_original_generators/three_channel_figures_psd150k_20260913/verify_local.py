from pathlib import Path
import hashlib,json,sys
import numpy as np
from PIL import Image,ImageOps,ImageDraw
B=Path(__file__).resolve().parent
QA=B/'visual_qa';QA.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def previews(group):
    paths=sorted((B/'figures'/group).glob('*.png'))
    for p in paths:
        im=Image.open(p).convert('RGB');assert im.width>=3000 and im.height>=1500
        im.thumbnail((1400,1500));im.save(QA/p.name)
    return len(paths)
def parameter_check():
    d=B/'figures/parameter_means';m=json.loads((d/'validation.json').read_text())
    cfg=json.loads((B/'baseline_config.json').read_text());z=np.load(d/'plot_source_arrays.npz')
    assert m['seeds']==10 and len(m['figures'])==15
    np.testing.assert_array_equal(z['parameter_time_TU'],np.arange(0,100001,100))
    results={}
    for n in range(6,21):
        name=f'parameter_mean_MCPE{n}_8obs.png';info=m['figures'][name]
        assert sha(d/name)==info['sha256']
        assert {p['name'] for p in info['parameters']}=={p['name'] for p in cfg['scheme_parameters'][str(n)]}
        assert len(info['parameters'])==n and info['normalized_by_truth'] and not info['temporal_smoothing']
        a=z[f'M{n}_parameter_seed_means'];t=z[f'M{n}_parameter_truth']
        assert a.shape==(10,1001,45) and t.shape==(45,) and np.isfinite(a).all()
        values={}
        for p in info['parameters']:
            j=p['row45']-1;assert t[j]!=0
            y=a[:,:,j].mean(0)/t[j];assert np.isfinite(y).all()
            values[p['name']]={'initial':float(y[0]),'final':float(y[-1]),'entry_TU':p['entry_TU']}
        results[str(n)]=values
    assert previews('parameter_means')==15
    (QA/'parameter_validation.json').write_text(json.dumps({'status':'PASS','schemes':results},indent=2))
def spectra_check():
    d=B/'figures/power_spectra';m=json.loads((d/'validation.json').read_text());p=json.loads((d/'plot_data.json').read_text())
    assert m['runs']==50 and m['window_TU']==[100000,150000] and m['all_seeds_retained']
    methods=['CTL','CDA8','MCPE12','MCPE14','MCPE16'];rows={};hashes=set()
    expected={'x2':500001,'w':50001,'eta':50001,'TL':50001,'Catm':50001,'Cocean':5001,'ALK':5001}
    for method in methods:
        rows[method]=[]
        for seed in range(10):
            r=B/f'run_audits/{method}/seed{seed}';a=json.loads((r/'audit.json').read_text());hashes.add(a['truth_sha256'])
            s=json.loads((r/'spectra_audit.json').read_text());assert s['window_TU']==[100000,150000] and s['member_index']==0
            for v,num in expected.items():assert s['variables'][v]['samples']==num
            rows[method].append(dict(np.load(r/'spectra.npz')))
    assert len(hashes)==1
    for v in expected:
        for factor in [1,4,8]:
            q=p[v][str(factor)];k=f'{v}_{factor}';f=np.array(q['frequency']);truth=np.array(q['Truth'])
            assert np.all(np.diff(f)>0) and np.isfinite(truth).all()
            if v in ['Cocean','ALK']:assert len(f)==8
            for method in methods:
                for z in rows[method]:
                    np.testing.assert_array_equal(f,z[k+'_frequency']);np.testing.assert_array_equal(truth,z[k+'_truth'])
                np.testing.assert_allclose(q[method],np.stack([z[k+'_member1'] for z in rows[method]]).mean(0),rtol=1e-14,atol=0)
    assert len(m['images'])==9
    for name,h in m['images'].items():assert sha(d/name)==h
    assert previews('power_spectra')==9
    (QA/'spectra_validation.json').write_text(json.dumps({'status':'PASS','runs':50,'window_TU':[100000,150000],'samples_per_seed':expected,'all_averages_recomputed':True},indent=2))
def delivery_check():
    items=json.loads((B/'delivery.json').read_text());assert len(items)==42
    for q in items:assert sha(Path(q['path']))==q['sha256'] and Path(q['path']).suffix=='.png'
    assert len(set(q['path'] for q in items))==42
    (QA/'delivery_validation.json').write_text(json.dumps({'status':'PASS','images':42},indent=2))
if __name__=='__main__':
    action=sys.argv[1]
    if action in ['parameters','all']:parameter_check()
    if action in ['spectra','all']:spectra_check()
    if action in ['delivery','all']:delivery_check()
    print(action,'PASS')
