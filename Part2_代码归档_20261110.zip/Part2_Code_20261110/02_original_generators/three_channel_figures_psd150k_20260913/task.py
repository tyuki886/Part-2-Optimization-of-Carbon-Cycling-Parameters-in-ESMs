from pathlib import Path
import os,sys,json,hashlib
import numpy as np
import audit_base as audit
from checked_exec import checked
B=Path(__file__).resolve().parent
METHODS=['CTL','CDA8','MCPE12','MCPE14','MCPE16']
def mode(method):return (22,0) if method=='CTL' else ((22,3) if method=='CDA8' else (int(method[4:]),6))
def source(method,seed):
    if method=='CTL':return B.parent/'three_channel_complete578_20260913/runs'/f'{300+seed:03d}'
    if method=='CDA8':return B.parent/'three_channel_full22_20260912/runs'/f'CDA8{seed}'
    return B.parent/'three_channel_sweep6_20_20260912/runs'/f'M{int(method[4:]):02d}_s{seed}'
def run(method,seed,d,steps=15000000,start=10000000,psd_start=10000000,reference=False):
    d.mkdir(parents=True,exist_ok=False)
    n,v=mode(method)
    env={k:v for k,v in os.environ.items() if not k.startswith('MCPE_')}
    env.update(MCPE_SCHEME=str(n),MCPE_VARIANT=str(v),MCPE_SEED=str(seed),MCPE_FREQ='1,4,20',
       MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS=str(steps),MCPE_EVAL=str(start),MCPE_EVAL_END=str(steps),
       MCPE_SAVE_PARAM_MEAN='1',MCPE_CHECKPOINT='checkpoint.txt',MCPE_PSD='0' if reference else '1',
       MCPE_PSD_START=str(psd_start),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    try:
        receipt=checked(B/('exp21_reference' if reference else 'exp21_psd'),d,env,'run')
        report=audit.validate(d,n,v,steps,start,steps)
        old=source(method,seed)
        assert (d/'initial_parameters.txt').read_bytes()==(old/'initial_parameters.txt').read_bytes()
        h=np.loadtxt(d/'parameter_mean.txt');oh=np.loadtxt(old/'parameter_mean.txt')
        np.testing.assert_array_equal(h[:1001],oh)
        if not reference:
            assert (d/'rmse_prefix_90000_100000.txt').read_bytes()==(old/f'rmse_M{n:02d}_v{v:02d}.txt').read_bytes()
            path=d/'spectral_member1.bin';count=(steps-psd_start)//10+1
            assert path.stat().st_size==count*15*8
            arr=np.memmap(path,dtype='<f8',mode='r',shape=(count,15))
            assert np.isfinite(arr).all()
            np.testing.assert_allclose(arr[:,0],np.arange(psd_start,steps+1,10)/100,atol=1e-10,rtol=0)
            report['spectral_rows']=count
            report['spectral_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            report['truth_sha256']=hashlib.sha256(np.ascontiguousarray(arr[:,1:8]).tobytes()).hexdigest()
            report['prefix_RMSE_exact_match']=True
        if v>=4:
            schedule=np.loadtxt(d/'schedule.txt',dtype=np.int64)
            assert (schedule[:,2]==steps+1).all()
            p=audit.CFG['scheme_parameters'][str(n)]
            np.testing.assert_array_equal(schedule[:,0],[x['row45'] for x in p])
            np.testing.assert_array_equal(schedule[:,1],[x['entry_TU']*100 for x in p])
            if steps>10000000:
                u=np.loadtxt(d/'parameter_updates.txt',dtype=np.int64).reshape(45,8,5)
                for x in p:assert (u[x['row45']-1,:,4]>10000000).any()
        report.update(method=method,seed=seed,execution=receipt,prefix_parameter_history_exact_match=True)
        (d/'audit.json').write_text(json.dumps(report,indent=2));(d/'MODEL_READY').touch()
        if not reference and steps==15000000:
            from spectra import analyze
            analyze(d)
        (d/'READY').touch();print('READY',method,seed,steps,flush=True)
    except Exception as e:(d/'FAILED').write_text(repr(e));raise
def preflight():
    run('MCPE16',0,B/'preflight/reference',10000000,9000000,9950000,True)
    run('MCPE16',0,B/'preflight/diagnostic',10000000,9000000,9950000)
    for f in ['checkpoint.txt','rmse_M16_v06.txt','parameter_mean.txt','initial_parameters.txt','final_parameters.txt','parameter_updates.txt','audit_scalars.txt']:
        assert (B/'preflight/reference'/f).read_bytes()==(B/'preflight/diagnostic'/f).read_bytes(),f
    from spectra import selftest
    selftest()
    (B/'PREFLIGHT_PASS').write_text('Full 100000TU reference/diagnostic replay byte identical; original run prefix preserved; PSD selftest passed.\n')
if __name__=='__main__':
    if sys.argv[1]=='preflight':preflight()
    else:
        assert (B/'PREFLIGHT_PASS').exists();i=int(sys.argv[1]);assert 0<=i<50
        run(METHODS[i//10],i%10,B/'runs'/METHODS[i//10]/f'seed{i%10}')
