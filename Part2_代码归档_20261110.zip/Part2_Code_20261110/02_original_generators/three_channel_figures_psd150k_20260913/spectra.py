from pathlib import Path
import sys
for dep in ['twin_work_3x3/python_deps','power_combined/python_deps']:
    sys.path.insert(0,str(Path(__file__).resolve().parent.parent/dep))
import json,hashlib
import numpy as np
from scipy import signal
import plot_corrected as plot
B=Path(__file__).resolve().parent
FACTORS=[1,4,8]
def psd(x,cfg,factor):
    x=np.asarray(x,dtype=float);x=x-x.mean()
    n=len(x) if cfg['nperseg']=='full' else cfg['nperseg']*factor
    window='boxcar' if cfg['nperseg']=='full' else 'hann'
    assert n<=len(x)
    f,p=signal.welch(x,fs=cfg['fs'],window=window,nperseg=n,noverlap=n//2,nfft=n,detrend='constant',return_onesided=True,scaling='density',average='mean')
    return f*cfg['mult'],p/cfg['mult']
def selftest():
    cfg,_=plot.original_config(B)
    rng=np.random.RandomState(20260913)
    for name,c in cfg.items():
        x=rng.normal(size=max(10000,8193))
        f,p=psd(x,c,1)
        n=len(x) if c['nperseg']=='full' else c['nperseg'];win='boxcar' if c['nperseg']=='full' else 'hann'
        a,b=signal.welch(x-x.mean(),fs=c['fs'],window=win,nperseg=n,scaling='spectrum')
        w=signal.get_window(win,n);enbw=c['fs']*(w*w).sum()/w.sum()**2
        np.testing.assert_allclose(f,a*c['mult'],atol=0,rtol=0)
        np.testing.assert_allclose(p*c['mult']*enbw,b,rtol=1e-12,atol=1e-15)
        integ=lambda y,x:np.sum((y[1:]+y[:-1])*.5*np.diff(x))
        np.testing.assert_allclose(integ(p,f),integ(p*c['mult'],f/c['mult']),rtol=1e-12)
    print('PSD_SELFTEST_PASS',flush=True)
def analyze(d):
    cfg,xlim=plot.original_config(B)
    a=np.memmap(d/'spectral_member1.bin',dtype='<f8',mode='r',shape=(500001,15))
    arrays={};meta={'window_TU':[100000,150000],'member_index':0,'factors':FACTORS,'variables':{}}
    for j,var in enumerate(plot.VARIABLES):
        c=cfg[var];stride=int(round(10/c['fs']))
        data=a[::stride];n=len(data)
        assert n==int(50000*c['fs'])+1
        assert np.isfinite(data).all()
        meta['variables'][var]={'samples':n,'sample_interval_TU':1/c['fs'],'truth_sha256':hashlib.sha256(np.ascontiguousarray(data[:,1+j]).tobytes()).hexdigest()}
        for factor in FACTORS:
            f,t=psd(data[:,1+j],c,factor);g,m=psd(data[:,8+j],c,factor)
            np.testing.assert_array_equal(f,g)
            mask=(f>=xlim[0])&(f<=xlim[1])
            for label,value in [('frequency',f[mask]),('truth',t[mask]),('member1',m[mask])]:
                assert np.isfinite(value).all() and (value>=0).all()
                arrays[f'{var}_{factor}_{label}']=value
            if c['nperseg']=='full':assert mask.sum()==8
    np.savez_compressed(d/'spectra.npz',**arrays)
    (d/'spectra_audit.json').write_text(json.dumps(meta,indent=2))
def postprocess():
    from task import METHODS
    from matplotlib.lines import Line2D
    from matplotlib import font_manager
    import matplotlib.pyplot as plt
    from plot_ten_seed_contrast import STYLES
    cfg,xlim=plot.original_config(B);font_manager.fontManager.addfont(str(B/'times.ttf'));plot.configure_font(B)
    rows={};audits=[];truth=None;freqs={}
    for method in METHODS:
        rows[method]=[]
        for seed in range(10):
            d=B/'runs'/method/f'seed{seed}'
            assert (d/'READY').exists() and not (d/'FAILED').exists()
            z=dict(np.load(d/'spectra.npz'));rows[method].append(z)
            audit=json.loads((d/'audit.json').read_text());audits.append(audit)
            if truth is None:truth={k:z[k] for k in z if k.endswith('_truth')};truth_hash=audit['truth_sha256']
            assert audit['truth_sha256']==truth_hash
            for k,x in truth.items():np.testing.assert_array_equal(z[k],x)
            for k,x in z.items():
                if k.endswith('_frequency'):
                    if k in freqs:np.testing.assert_array_equal(freqs[k],x)
                    else:freqs[k]=x
    data={}
    for var in plot.VARIABLES:
        data[var]={}
        for factor in FACTORS:
            key=f'{var}_{factor}'
            data[var][str(factor)]={'frequency':freqs[key+'_frequency'].tolist(),'Truth':truth[key+'_truth'].tolist()}
            for method in METHODS:
                data[var][str(factor)][method]=np.mean([z[key+'_member1'] for z in rows[method]],axis=0).tolist()
    limits={var:1.10*max(max(q[m]) for q in data[var].values() for m in ['Truth']+METHODS) for var in plot.VARIABLES}
    out=B/'figures/power_spectra';out.mkdir(parents=True,exist_ok=True);images={}
    for n in [12,14,16]:
        labels=['Truth','CTL','CDA8',f'MCPE{n}']
        for factor in FACTORS:
            fig,axes=plot.seven_panel(f'Power spectra: CTL, Truth, CDA8 and MCPE{n}',
               '100000–150000 TU | Mean PSD over 10 seeds | Fixed member 1',
               f'Welch segment length: {factor}x | State assimilation and parameter estimation continue')
            handles=[Line2D([],[],lw=1.5,markersize=5,markerfacecolor='white',**STYLES[m]) for m in labels]
            plot.shared_legend(fig,handles,labels)
            for var,ax in axes.items():
                d=data[var][str(factor)];f=np.asarray(d['frequency'])
                for i,m in enumerate(labels):
                    y=np.asarray(d[m]);stride=max(7,len(f)//9)
                    line,=ax.plot(f,y,lw=1.5,markersize=4.7,markerfacecolor='white',markeredgewidth=.9,markevery=list(range(i%stride,len(f),stride)),**STYLES[m])
                    np.testing.assert_array_equal(line.get_xdata(),f);np.testing.assert_array_equal(line.get_ydata(),y)
                assert len(ax.lines)==4
                ax.set_xlim(*xlim);ax.set_ylim(0,limits[var]);plot.axis_style(ax,var,cfg[var]['xlab'],'PSD',spectrum=True)
                ax.set_title(var+' | full record' if cfg[var]['nperseg']=='full' else f"{var} | segment = {cfg[var]['nperseg']*factor/cfg[var]['fs']:g} TU",fontsize=12)
            fig.text(.5,.032,'PSD per displayed frequency unit; no time-series or member averaging.',ha='center',fontsize=9.3)
            fig.text(.5,.016,'Cocean and ALK: full-record spectra, 8 displayed frequency bins in all settings.',ha='center',fontsize=9.3)
            name=f'power_spectra_MCPE{n}_vs_CTL_Truth_CDA8_{factor}x.png';fig.savefig(out/name,dpi=300);plt.close(fig)
            images[name]=hashlib.sha256((out/name).read_bytes()).hexdigest()
    (out/'plot_data.json').write_text(json.dumps(data))
    (out/'validation.json').write_text(json.dumps({'runs':50,'all_seeds_retained':True,'truth_all_runs_identical':True,'window_TU':[100000,150000],'member_index':0,'images':images,'run_audits':audits},indent=2))
    (B/'PSD_PLOTS_READY').write_text('9 PNGs: 3 methods x 1/4/8x Welch checks; all 50 runs validated.\n')
if __name__=='__main__':
    try:postprocess()
    except Exception as e:(B/'POST_FAILED').write_text(repr(e));raise
