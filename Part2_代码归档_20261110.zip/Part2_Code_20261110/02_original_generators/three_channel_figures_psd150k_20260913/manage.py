from pathlib import Path
import getpass,json,hashlib,time,sys,shutil
import paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/'+B.name
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
DEPS='/public/home/hou/wyh/MCPE26.0/twin_work_3x3/python_deps:/public/home/hou/wyh/MCPE26.0/power_combined/python_deps'
DEST=Path('D:/SRDP/论文大作！/MCPE26.0/9.2/三通道MCPE6-20全图_谱100000-150000TU_20260913')
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
def cmd(s):
    _,o,e=c.exec_command(s,timeout=180);a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);return a
def pbs(name,action):
    return f'''#!/bin/bash
#PBS -N {name}
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=01:00:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH={R}:{DEPS}
{PY} {action}
'''
def status():
    return json.loads(cmd(f'''cd {R} && {PY} -c 'from pathlib import Path;import json;p=Path(".");print(json.dumps(dict(preflight=(p/"PREFLIGHT_PASS").exists(),production=(p/"production_job.txt").exists(),ready=len(list(p.glob("runs/*/*/READY"))),failed=[str(f) for f in p.glob("**/FAILED")],post=(p/"post_job.txt").exists(),complete=(p/"PSD_PLOTS_READY").exists(),parameters=(p/"PARAMETER_PLOTS_READY").exists(),post_failed=(p/"POST_FAILED").read_text() if (p/"POST_FAILED").exists() else None)))' '''))
def collect():
    delivery=[]
    with c.open_sftp() as ftp:
        for group in ['parameter_means','power_spectra']:
            local=B/'figures'/group;local.mkdir(parents=True,exist_ok=True)
            for name in ftp.listdir(R+'/figures/'+group):
                if name.endswith(('.png','.json','.npz')):
                    ftp.get(R+'/figures/'+group+'/'+name,str(local/name))
            meta=json.loads((local/'validation.json').read_text())
            for p in local.glob('*.png'):
                expected=meta['images'][p.name] if group=='power_spectra' else meta['figures'][p.name]['sha256']
                assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
                dest=DEST/group/p.name;dest.parent.mkdir(parents=True,exist_ok=True)
                if dest.exists():assert dest.read_bytes()==p.read_bytes()
                else:shutil.copyfile(p,dest)
                delivery.append({'path':str(dest),'sha256':expected})
        for name in ['PREFLIGHT_PASS','PARAMETER_PLOTS_READY','PSD_PLOTS_READY','preflight_job.txt','production_job.txt','post_job.txt','parameter_job.txt']:
            ftp.get(R+'/'+name,str(B/name))
    old=B.parent/'three_channel_complete578_20260913'
    meta=json.loads((old/'post_validation.json').read_text())
    for p in (old/'figures').glob('*.png'):
        if not p.name.startswith(('rmse_','rate_')):continue
        sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==meta['images'][p.name]['sha256']
        dest=DEST/('RMSE' if p.name.startswith('rmse_') else 'correction_rates')/p.name;dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert dest.read_bytes()==p.read_bytes()
        else:shutil.copyfile(p,dest)
        delivery.append({'path':str(dest),'sha256':sha})
    assert len(delivery)==42
    (B/'delivery.json').write_text(json.dumps(delivery,ensure_ascii=False,indent=2))
    print('DOWNLOADED',len(delivery),str(DEST),flush=True)
try:
    action=sys.argv[1]
    if action=='deploy':
        cmd(f'test ! -e {R} && mkdir -p {R}/logs')
        m=json.loads((B/'manifest.json').read_text())
        with c.open_sftp() as ftp:
            for name,h in m.items():
                assert hashlib.sha256((B/name).read_bytes()).hexdigest()==h
                ftp.put(str(B/name),R+'/'+name)
            ftp.put(str(B/'manifest.json'),R+'/manifest.json')
            for file,name,run in [('preflight.pbs','TriPSDCheck','task.py preflight'),('run.pbs','TriPSD150','task.py "${PBS_ARRAYID:?}"'),('post.pbs','TriPSDPlot','spectra.py'),('parameters.pbs','TriParamPlots','plot_parameters.py')]:
                with ftp.open(R+'/'+file,'w') as f:f.write(pbs(name,run))
        print(cmd(f'''set -eu
cd {R}
{PY} -c 'import pathlib,json,hashlib;m=json.load(open("manifest.json"));assert all(hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest()==h for n,h in m.items());print("HASH_PASS")'
gfortran -O3 -ffree-line-length-none -c RKmethod.f90
gfortran -O3 -ffree-line-length-none -c MCPE42_new.f90
gfortran -O3 -ffree-line-length-none exp21_reference.f90 MCPE42_new.o RKmethod.o -o exp21_reference
gfortran -O3 -ffree-line-length-none exp21_psd.f90 MCPE42_new.o RKmethod.o -o exp21_psd
{PY} -m py_compile task.py spectra.py plot_parameters.py
cd logs
qsub ../preflight.pbs > ../preflight_job.txt
qsub ../parameters.pbs > ../parameter_job.txt
cat ../preflight_job.txt ../parameter_job.txt
'''),flush=True)
    elif action=='status':print(json.dumps(status()),flush=True)
    elif action=='collect':
        s=status();assert s['complete'] and s['parameters'] and not s['failed'] and not s['post_failed'];collect()
    elif action=='finish':
        prior=None
        for _ in range(180):
            s=status()
            if s!=prior:print(json.dumps(s),flush=True);prior=s
            if s['failed'] or s['post_failed']:raise RuntimeError(s)
            if s['preflight'] and not s['production']:
                print('PRODUCTION_JOB',cmd(f'cd {R}/logs && qsub -t 0-49%10 ../run.pbs > ../production_job.txt && cat ../production_job.txt'),flush=True)
            if s['ready']==50 and not s['post']:
                print('POST_JOB',cmd(f'cd {R}/logs && qsub ../post.pbs > ../post_job.txt && cat ../post_job.txt'),flush=True)
            if s['complete'] and s['parameters']:collect();break
            time.sleep(20)
        else:print('WAIT_WINDOW_ENDED; inspect before restarting',flush=True)
    else:raise ValueError(action)
finally:c.close()
