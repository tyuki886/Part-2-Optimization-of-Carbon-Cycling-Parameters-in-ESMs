from pathlib import Path
import shutil,hashlib,json
B=Path(__file__).resolve().parent
SRC=B.parent/'three_channel_complete578_20260913'
for f in ['RKmethod.f90','MCPE42_new.f90','audit_base.py','baseline_config.json','checked_exec.py','times.ttf']:
    shutil.copyfile(SRC/f,B/f)
s=(SRC/'exp21_new.f90').read_text(encoding='utf-8')
def replace(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
replace("        call assign_component_mask(r,no,w); cv=1._dp", "        en2=ts+1_8 ! continue parameter estimation through the requested endpoint\n        call assign_component_mask(r,no,w); cv=1._dp")
replace("        if(ts/=10000000_8.or.es/=9000000_8.or.ee/=10000000_8)error stop 'WRONG_PRODUCTION_WINDOW'", "        if(.not.((ts==10000000_8.and.es==9000000_8.and.ee==10000000_8).or. &\n          (ts==15000000_8.and.es==10000000_8.and.ee==15000000_8)))error stop 'WRONG_PRODUCTION_WINDOW'")
replace('        logical::save_mean','''        logical::save_mean,save_psd
        integer,parameter::psd_idx(7)=[2,4,5,7,8,9,10]
        integer(kind=8)::psd_start,prefix_count
        real(kind=dp)::prefix_mse(10)
        character(40)::psd_env
        integer::psd_st''')
replace('        mse2=0._dp; cr2=0_8','''        save_psd=.false.;psd_start=10000000_8
        call get_environment_variable('MCPE_PSD',psd_env,status=psd_st)
        if(psd_st==0)save_psd=trim(psd_env)=='1'
        call get_environment_variable('MCPE_PSD_START',psd_env,status=psd_st)
        if(psd_st==0)read(psd_env,*)psd_start
        if(save_psd)open(97,file='spectral_member1.bin',access='stream',form='unformatted',status='replace')
        prefix_mse=0._dp;prefix_count=0_8
        mse2=0._dp; cr2=0_8''')
replace('            if(i>rss.and.i<=ree)then','''            if(save_psd.and.i>=psd_start.and.mod(i,10_8)==0_8)then
                write(97)real(i,dp)/100._dp,xt(psd_idx),xe(psd_idx,1)
            endif
            if(i>9000000_8.and.i<=10000000_8)then
                smean=sum(xe,dim=2)/en;prefix_mse=prefix_mse+(smean-xt)**2;prefix_count=prefix_count+1_8
            endif
            if(i>rss.and.i<=ree)then''')
replace('        if(save_mean)close(94)','''        if(save_mean)close(94)
        if(save_psd)close(97)
        if(prefix_count==1000000_8)then
            open(96,file='rmse_prefix_90000_100000.txt',status='replace')
            write(96,'(10F14.7)')sqrt(prefix_mse/real(prefix_count,dp));close(96)
        endif''')
(B/'exp21_psd.f90').write_text(s,encoding='utf-8')
shutil.copyfile(SRC/'exp21_new.f90',B/'exp21_reference.f90')
old=B.parent/'evidence_suite_20260908'
for f in ['plot_corrected.py','plot_ten_seed_contrast.py']:
    shutil.copyfile(old/f,B/f)
shutil.copyfile(B.parent/'assim_psd_corrected_20260907/original_plot_psd_v10v7.py',B/'original_plot_psd_v10v7.py')
# Reuse the exact parameter panel body and layout, expanded to every scheme.
src=(B.parent/'three_channel_sweep6_20_20260912/plot_latest.py').read_text()
block=src[src.index('    for n in [12,14,16]:'):src.index("    assert len(meta['figures'])")]
block=block.replace('for n in [12,14,16]:','for n in range(6,21):')
header='''from pathlib import Path
import json,math,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
BASE=Path(__file__).resolve().parent
B=BASE.parent/'three_channel_sweep6_20_20260912'
OUT=BASE/'figures/parameter_means'
def main():
    OUT.mkdir(parents=True,exist_ok=True)
    cfg=json.loads((B/'baseline_config.json').read_text())
    font_manager.fontManager.addfont(str(BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':11,'axes.unicode_minus':False,'savefig.facecolor':'white'})
    meta={'figures':{},'source':'completed three-channel 8obs runs','seeds':10}
    arrays={}
    def save(fig,name,info):
        fig.canvas.draw()
        fig.savefig(OUT/name,dpi=300)
        meta['figures'][name]={**info,'sha256':hashlib.sha256((OUT/name).read_bytes()).hexdigest()}
        plt.close(fig)
'''
footer='''    assert len(meta['figures'])==15
    np.savez_compressed(OUT/'plot_source_arrays.npz',**arrays)
    (OUT/'validation.json').write_text(json.dumps(meta,indent=2))
    (BASE/'PARAMETER_PLOTS_READY').write_text('15 parameter mean PNGs; all 10 seeds retained.\\n')
if __name__=='__main__':main()
'''
(B/'plot_parameters.py').write_text(header+block+footer)
files=[p for p in B.iterdir() if p.suffix in ['.py','.f90','.json','.ttf'] and p.name!='manifest.json']
(B/'manifest.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
print('Prepared additive PSD recorder, original parameter plotting body and source manifest')
