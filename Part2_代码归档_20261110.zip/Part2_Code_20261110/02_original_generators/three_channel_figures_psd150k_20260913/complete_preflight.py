from pathlib import Path
import json
import audit_base as audit
from spectra import selftest
B=Path(__file__).resolve().parent
for group in ['reference','diagnostic']:
    d=B/'preflight'/group
    assert (d/'READY').exists() and not (d/'FAILED').exists()
    audit.validate(d,16,6,10000000,9000000,10000000)
    assert json.loads((d/'audit.json').read_text())['prefix_parameter_history_exact_match']
for f in ['checkpoint.txt','rmse_M16_v06.txt','parameter_mean.txt','initial_parameters.txt','final_parameters.txt','parameter_updates.txt','audit_scalars.txt']:
    assert (B/'preflight/reference'/f).read_bytes()==(B/'preflight/diagnostic'/f).read_bytes(),f
assert json.loads((B/'preflight/diagnostic/audit.json').read_text())['prefix_RMSE_exact_match']
selftest()
(B/'PREFLIGHT_PASS').write_text('Full 100000TU reference/diagnostic replay byte identical; original run prefix preserved; PSD selftest passed after restoring existing SciPy dependency path.\n')
print('PREFLIGHT_PASS',flush=True)
