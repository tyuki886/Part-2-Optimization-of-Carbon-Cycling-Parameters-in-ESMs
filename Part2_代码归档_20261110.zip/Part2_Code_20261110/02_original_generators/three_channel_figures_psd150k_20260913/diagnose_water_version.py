from pathlib import Path
import json,re
import numpy as np
B=Path(__file__).resolve().parent
P=B.parent
old=json.loads((P/'carbon_second_halving_20260912/C2/experiment_config.json').read_text())
new=json.loads((P/'three_channel_complete578_20260913/baseline_config.json').read_text())
os=json.loads((P/'carbon_second_halving_20260912/summary.json').read_text())
ns=json.loads((P/'three_channel_complete578_20260913/summary.json').read_text())
prior=json.loads((P/'three_channel_sweep6_20_20260912/summary.json').read_text())
water=new['water_parameters']
assert all(old['cycles_TU'][p]==new['cycles_TU'][p] for p in water)
def water_lines(d):
    return re.findall(r'^.*case\((?:2|4|3|1|33|5|42|26|7|32)\); cycles.*$',(d/'MCPE42_new.f90').read_text(),re.M)
assert water_lines(P/'carbon_second_halving_20260912/C2')==water_lines(P/'three_channel_complete578_20260913')
assert all(np.array_equal(ns['RMSE_per_seed'][f'M{n:02d}_v06'],prior['RMSE_per_seed'][str(n)]) for n in range(6,21))
a=np.array(os['RMSE_per_seed']['C2']);b=np.array(ns['RMSE_per_seed']['M16_v06'])
assert a.shape==b.shape==(10,10)
np.testing.assert_allclose(a.mean(0),os['RMSE_mean']['C2'],rtol=1e-14)
np.testing.assert_allclose(b.mean(0),ns['RMSE_mean']['M16_v06'],rtol=1e-14)
metrics=[{'variable':v,'old_C2':float(a[:,i].mean()),'new_three_channel':float(b[:,i].mean()),'change_percent':float((b[:,i].mean()/a[:,i].mean()-1)*100)} for i,v in enumerate(ns['variables'])]
composition=[];entry=[]
for n in [12,14,16]:
    o=next(x for x in old['schemes'] if x['scheme']==f'MCPE{n}')['parameters']
    z=new['scheme_parameters'][str(n)]
    composition.append({'scheme':f'MCPE{n}','old_water':sum(x['name'] in water for x in o),'new_water':sum(x['name'] in water for x in z),'old_carbon':sum(x['name'] not in water for x in o),'new_carbon':sum(x['name'] not in water for x in z)})
    if n==16:
        for x in o:
            if x['name'] in water:
                match=next((q for q in z if q['name']==x['name']),None)
                entry.append({'parameter':x['name'],'old_entry_TU':x['entry_TU'],'new_entry_TU':match['entry_TU'] if match else 'Not estimated'})
cycles=[{'parameter':p,'x123_TU':new['cycles_TU'][p]['x2'],'w_TU':new['cycles_TU'][p]['w'],'TL_TU':new['cycles_TU'][p]['TL']} for p in water]
result={'water_cycles_equal_C2':True,'water_Fortran_equal_C2':True,'all_15_current_8obs_results_exactly_reused':True,'comparison_window_TU':[90000,100000],'RMSE_MCPE16':metrics,'composition':composition,'MCPE16_entries':entry,'current_cycles':cycles,'caveat':'Compared with C2, not W/WC. Composition, entry order, initialization and ALK channel settings changed together; no isolated causal attribution.'}
(B/'water_version_diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
payload={'schemaVersion':1,'items':[
 {'id':'water-cycles-and-schemes','title':'水循环周期相同，但同名方案组成与入场时间改变','queries':[
  {'id':'cycle-source','source':{'label':'C2与三通道参数配置','files':['C2 experiment_config.json','三通道 baseline_config.json','C2 MCPE42_new.f90','三通道 MCPE42_new.f90'],'caveats':['本次水循环周期等于C2版的B基准周期，不等于此前W/WC减半试验的周期。']},'summary':'十个水循环参数的周期配置与对应Fortran赋值语句一致。','columns':['parameter','x123_TU','w_TU','TL_TU'],'rows':cycles},
  {'id':'composition-source','source':{'label':'旧C2与新三组轮流名单','files':['C2 experiment_config.json','三通道 baseline_config.json']},'columns':['scheme','old_water','new_water','old_carbon','new_carbon'],'rows':composition},
  {'id':'entry-source','source':{'label':'MCPE16实际入场表','files':['C2 experiment_config.json','三通道 baseline_config.json']},'columns':['parameter','old_entry_TU','new_entry_TU'],'rows':entry}]},
 {'id':'rmse-change','title':'MCPE16水循环状态RMSE变大，但不能单独归因于周期','queries':[
  {'id':'rmse-source','reportingPeriod':'90000–100000 TU','source':{'label':'MCPE16/8obs十seed结果','files':['C2 summary.json','三通道578obs summary.json','三通道sweep summary.json'],'filters':['方案：MCPE16','观测：8obs','全部10个seed'],'caveats':['参数名单、入场顺序、初始化及ALK通道设置同时改变，当前对比不能分离每项变化的因果贡献。']},'summary':'已从两版逐seed RMSE重新计算平均值；本轮三通道全部15个8obs结果与上次三通道扫描完全相同，并非延长谱窗口后重新计算的RMSE。','columns':['variable','old_C2','new_three_channel','change_percent'],'rows':metrics,'methods':[{'language':'calculation','code':'每版RMSE = 10个seed各自RMSE的算术平均；变化率 = (新三通道RMSE / 旧C2 RMSE - 1) × 100%。'}]}]}]}
(B/'water_version_sources.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
