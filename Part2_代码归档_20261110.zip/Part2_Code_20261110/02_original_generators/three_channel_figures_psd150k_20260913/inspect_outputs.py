from pathlib import Path
import getpass,json,sys
import paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/'+B.name
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
try:
    if sys.argv[1]=='status':
        _,o,e=c.exec_command('cd '+R+' && qstat -u hou && find preflight -maxdepth 3 -type f -name checkpoint.txt -exec tail -n 1 {} \\; && tail -n 12 logs/TriPSDCheck.o*',timeout=60)
        print(o.read().decode());print(e.read().decode())
    else:
        with c.open_sftp() as f:
            for group in ['parameter_means','power_spectra']:
                try:names=f.listdir(R+'/figures/'+group)
                except FileNotFoundError:continue
                target=B/'figures'/group;target.mkdir(parents=True,exist_ok=True)
                for name in names:
                    if name.endswith(('.png','.json','.npz')):f.get(R+'/figures/'+group+'/'+name,str(target/name))
            count=0
            for method in ['CTL','CDA8','MCPE12','MCPE14','MCPE16']:
                for seed in range(10):
                    remote=R+f'/runs/{method}/seed{seed}'
                    try:f.stat(remote+'/READY')
                    except FileNotFoundError:continue
                    target=B/f'run_audits/{method}/seed{seed}';target.mkdir(parents=True,exist_ok=True)
                    for name in ['spectra.npz','spectra_audit.json','audit.json']:
                        f.get(remote+'/'+name,str(target/name))
                    count+=1
            print('Downloaded completed spectra:',count)
finally:c.close()
