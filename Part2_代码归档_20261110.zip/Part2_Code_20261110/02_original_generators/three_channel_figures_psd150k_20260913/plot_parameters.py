from pathlib import Path
import json,math,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
BASE=Path(__file__).resolve().parent
B=BASE.parent/'three_channel_sweep6_20_20260912'
OUT=BASE/'figures/parameter_means'
def main():
    OUT.mkdir(parents=True,exist_ok=True)
    cfg=json.loads((B/'baseline_config.json').read_text())
    font_manager.fontManager.addfont(str(BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':11,'axes.unicode_minus':False,'savefig.facecolor':'white'})
    meta={'figures':{},'source':'completed three-channel 8obs runs','seeds':10}
    arrays={}
    def save(fig,name,info):
        fig.canvas.draw()
        fig.savefig(OUT/name,dpi=300)
        meta['figures'][name]={**info,'sha256':hashlib.sha256((OUT/name).read_bytes()).hexdigest()}
        plt.close(fig)
    for n in range(6,21):
        params=cfg['scheme_parameters'][str(n)]
        # Preserve water-blue/carbon-red and group water first, without changing actual entry marks.
        display=[p for p in params if p['name'] in cfg['water_parameters']]+[p for p in params if p['name'] not in cfg['water_parameters']]
        hs=[];truth=None
        for seed in range(10):
            d=B/'runs'/f'M{n:02d}_s{seed}'
            h=np.loadtxt(d/'parameter_mean.txt');init=np.loadtxt(d/'initial_parameters.txt')
            final=np.loadtxt(d/'final_parameters.txt')
            assert h.shape==(1001,91) and np.isfinite(h).all()
            np.testing.assert_array_equal(h[:,0],np.arange(0,100001,100))
            np.testing.assert_allclose(h[0,1:46],init[:,2],rtol=1e-14)
            np.testing.assert_allclose(h[-1,1:46],final[:,2],rtol=1e-14)
            if truth is None:truth=init[:,1]
            else:np.testing.assert_array_equal(truth,init[:,1])
            hs.append(h[:,1:46])
        hs=np.array(hs);mean=hs.mean(0);t=h[:,0]
        arrays[f'M{n}_parameter_seed_means']=hs
        arrays[f'M{n}_parameter_truth']=truth
        arrays['parameter_time_TU']=t
        fig,axes=plt.subplots(math.ceil(n/4),4,figsize=(16,3.2*math.ceil(n/4)),squeeze=False)
        for ax,p in zip(axes.flat,display):
            i=p['row45']-1;assert truth[i]!=0
            ax.plot(t,mean[:,i]/truth[i],color='#2166AC' if p['name'] in cfg['water_parameters'] else '#B2182B',lw=1.3,label='Ensemble mean / truth')
            ax.axhline(1,color='black',ls='--',lw=1,label='Truth')
            ax.axvline(p['entry_TU'],color='#777777',ls=':',lw=1,label='Parameter entry')
            ax.set(title=p['name'],xlabel='Time (TU)',ylabel='Normalized parameter mean',xlim=(0,100000))
            ax.set_xticks([0,20000,40000,60000,80000,100000]);ax.tick_params(axis='x',labelsize=8)
            ax.grid(alpha=.2)
        for ax in list(axes.flat)[n:]:ax.set_visible(False)
        handles,labels=axes.flat[0].get_legend_handles_labels()
        fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.955),ncol=3,frameon=False)
        fig.suptitle(f'MCPE{n} parameter mean (8obs; mean of 10 seeds)',fontsize=16,y=.985)
        fig.text(.5,.015,'20 members per seed | Recorded every 100 TU | No temporal smoothing',ha='center',fontsize=10)
        fig.tight_layout(rect=(0,.035,1,.91))
        save(fig,f'parameter_mean_MCPE{n}_8obs.png',{'type':'parameter_mean','scheme':n,'parameters':display,'sample_interval_TU':100,'normalized_by_truth':True,'temporal_smoothing':False})
    assert len(meta['figures'])==15
    np.savez_compressed(OUT/'plot_source_arrays.npz',**arrays)
    (OUT/'validation.json').write_text(json.dumps(meta,indent=2))
    (BASE/'PARAMETER_PLOTS_READY').write_text('15 parameter mean PNGs; all 10 seeds retained.\n')
if __name__=='__main__':main()
