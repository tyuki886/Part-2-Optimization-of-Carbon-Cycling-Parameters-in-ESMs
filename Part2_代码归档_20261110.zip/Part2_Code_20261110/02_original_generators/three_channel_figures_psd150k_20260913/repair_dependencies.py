from pathlib import Path
import getpass,json,hashlib
import paramiko
B=Path(__file__).resolve().parent;R='/public/home/hou/wyh/MCPE26.0/'+B.name
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
try:
    with c.open_sftp() as f:
        try:f.stat(R+'/production_job.txt')
        except FileNotFoundError:pass
        else:raise RuntimeError('Production already submitted; do not mutate running source.')
        original=json.loads(f.open(R+'/manifest.json').read())
        (B/'manifest_initial.json').write_text(json.dumps(original,indent=2))
        for name in ['spectra.py','manage.py','complete_preflight.py']:
            f.put(str(B/name),R+'/'+name)
            original[name]=hashlib.sha256((B/name).read_bytes()).hexdigest()
        (B/'manifest.json').write_text(json.dumps(original,indent=2));f.put(str(B/'manifest.json'),R+'/manifest.json')
        for name in ['run.pbs','post.pbs','preflight.pbs','parameters.pbs']:
            text=f.open(R+'/'+name).read().decode().replace('python_deps\n','python_deps:/public/home/hou/wyh/MCPE26.0/power_combined/python_deps\n')
            with f.open(R+'/'+name,'w') as h:h.write(text)
        pbs=text.replace('TriParamPlots','TriPSDResume').replace('plot_parameters.py','complete_preflight.py')
        with f.open(R+'/resume_preflight.pbs','w') as h:h.write(pbs)
    _,o,e=c.exec_command('cd '+R+'/logs && qsub ../resume_preflight.pbs > ../resume_preflight_job.txt && cat ../resume_preflight_job.txt',timeout=60)
    print(o.read().decode());print(e.read().decode());assert o.channel.recv_exit_status()==0
finally:c.close()
