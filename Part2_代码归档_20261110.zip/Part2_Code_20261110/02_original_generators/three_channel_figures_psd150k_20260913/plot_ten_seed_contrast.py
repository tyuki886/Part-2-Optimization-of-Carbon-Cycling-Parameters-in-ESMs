"""10seed平均谱；固定成员1，不做成员平均；高对比英文PNG，旧图不覆盖。

绘图契约：比较同窗口各方案的频谱形状，七面板线图左4右3。
数据：60组已验收结果，每组七变量各一个成员的已计算谱。
每变量47/77/16/77/77/8/8点；慢变量8点是现有窗口分辨率，不插值。
调色：五分类色根与黑灰基准，另配不同线型、空心标记和错位标记点。
输出：本地可复算缓存、300dpi PNG；最终PNG目检后单独复制到论文目录。
"""
from pathlib import Path
import getpass,json,sys,hashlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
import plot_corrected as s

BASE=Path(__file__).resolve().parent
WORK=BASE/'ten_seed_contrast_20260910'
METHODS=['CTL','CDA8','MCPE12','MCPE13','MCPE14','MCPE16']
STYLES={
 'Truth':dict(color='#111111',ls='-',marker=None),
 'CTL':dict(color='#777777',ls=(0,(6,3)),marker=None),
 'CDA8':dict(color='#0072B2',ls=(0,(1,1.8)),marker='x'),
 'MCPE12':dict(color='#D64000',ls='-',marker='o'),
 'MCPE13':dict(color='#B88900',ls=(0,(7,2,1,2)),marker='D'),
 'MCPE14':dict(color='#00804A',ls=(0,(5,2)),marker='s'),
 'MCPE16':dict(color='#8A2DA0',ls=(0,(3,1.5,1,1.5)),marker='^'),
}

def download():
    import paramiko
    remote = """
import sys,json,hashlib
from pathlib import Path
base=Path('/public/home/hou/wyh/MCPE26.0/evidence_suite_20260908')
sys.path.insert(0,str(base.parent/'twin_work_3x3/python_deps'))
sys.path.insert(0,str(base.parent/'power_combined/python_deps'))
import numpy as np
methods=['CTL','CDA8','MCPE12','MCPE13','MCPE14','MCPE16']
variables=['x2','w','eta','TL','Catm','Cocean','ALK']
out={'methods':methods,'seeds':list(range(10)),'window_TU':[50000,100000],'member_array_index':0,'runs':{}}
for method in methods:
    out['runs'][method]=[]
    for seed in range(10):
        folder=base/'runs'/method/f'seed{seed}'
        assert (folder/'EXTRA_READY').exists()
        a=json.loads((folder/'audit.json').read_text())
        assert a['label']==method and a['seed']==seed and not a['smoke']
        assert a['window_TU']==[50000,100000]
        z=np.load(folder/'analysis.npz',allow_pickle=False)
        row={'seed':seed,'source':str(folder/'analysis.npz'),
             'source_sha256':hashlib.sha256((folder/'analysis.npz').read_bytes()).hexdigest(),'variables':{}}
        for var in variables:
            f=z['member_f_'+var];p=z['member_powers_'+var]
            assert p.shape==(20,len(f)) and np.isfinite(p).all() and (p>=0).all()
            row['variables'][var]={'frequency':f.tolist(),'power':p[0].tolist(),'truth':z['legacy_truth_'+var].tolist()}
        out['runs'][method].append(row)
print(json.dumps(out))
"""
    c=paramiko.SSHClient();c.load_system_host_keys()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),
              timeout=25,look_for_keys=False,allow_agent=False)
    try:
        command="/public/home/hou/miniconda3/envs/yuki/bin/python - <<'PY'\n"+remote+"\nPY"
        _,stdout,stderr=c.exec_command(command,timeout=180)
        result=stdout.read();error=stderr.read().decode()
        assert stdout.channel.recv_exit_status()==0,error
        data=json.loads(result)
        assert len(data['runs'])==6 and all(len(x)==10 for x in data['runs'].values())
        WORK.mkdir(exist_ok=True)
        (WORK/'source_spectra.json').write_text(json.dumps(data),encoding='utf8')
        print('60 validated spectra groups downloaded',flush=True)
    finally:c.close()

def plot():
    data=json.loads((WORK/'source_spectra.json').read_text())
    assert data['seeds']==list(range(10)) and data['member_array_index']==0
    s.configure_font(BASE)
    cfg,xlim=s.original_config(BASE)
    fig,axes=s.seven_panel('Power spectra averaged over 10 seeds',
       '50000–100000 TU | Member 1 fixed within each seed',
       'Spectrum calculated separately for each seed, then averaged; original Welch configuration')
    labels=['Truth']+METHODS
    handles=[Line2D([],[],lw=1.5,markersize=5,markerfacecolor='white',
                    markeredgewidth=1, label=m,**STYLES[m]) for m in labels]
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.52,.912),
               ncol=7,frameon=False,fontsize=11,handlelength=3.5,columnspacing=1.3)
    result={}
    for var,ax in axes.items():
        first=data['runs']['CTL'][0]['variables'][var]
        f=np.array(first['frequency']);truth=np.array(first['truth'])
        values={}
        for method in METHODS:
            stack=[]
            for seed,row in enumerate(data['runs'][method]):
                assert row['seed']==seed
                v=row['variables'][var]
                np.testing.assert_array_equal(v['frequency'],f)
                np.testing.assert_array_equal(v['truth'],truth)
                stack.append(v['power'])
            stack=np.array(stack)
            assert stack.shape==(10,len(f)) and np.isfinite(stack).all()
            values[method]=stack.mean(axis=0)
            np.testing.assert_allclose(values[method],sum(stack)/10,rtol=1e-14)
        values={'Truth':truth,**values}
        for j,method in enumerate(labels):
            # 错开标记位置，不移动任何数据点。慢变量每个方法标一个真实频率点。
            stride=max(7,len(f)//9)
            indices=list(range((j-2)%stride,len(f),stride))
            line,=ax.plot(f,values[method],lw=1.5,markersize=5.2,
                markerfacecolor='white',markeredgewidth=1.15,
                markevery=indices,zorder=2+j*.01,**STYLES[method])
            np.testing.assert_array_equal(line.get_xdata(),f)
            np.testing.assert_array_equal(line.get_ydata(),values[method])
        ax.set_xlim(*xlim)
        ax.set_ylim(0,max(float(v.max()) for v in values.values())*1.10)
        s.axis_style(ax,var,cfg[var]['xlab'],'Power spectrum',spectrum=True)
        result[var]={'frequency':f.tolist(),**{m:v.tolist() for m,v in values.items()}}
    fig.text(.5,.032,'Seeds 0–9; no averaging of time series or ensemble members. Colors and line styles identify schemes.',
             ha='center',fontsize=9.5)
    fig.text(.5,.016,'Cocean and ALK: eight frequency bins in the displayed range; no interpolation or additional smoothing.',
             ha='center',fontsize=9.3)
    out=WORK/'power_spectra_10seeds_member1_high_contrast.png'
    fig.savefig(out,dpi=300,facecolor='white');plt.close(fig)
    with Image.open(out) as im:
        assert im.size==(4200,4050) and abs(im.info['dpi'][0]-300)<1
        im.thumbnail((1600,1700));im.convert('RGB').save(WORK/'preview.jpg',quality=90)
    (WORK/'plot_data.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    (WORK/'plot_audit.json').write_text(json.dumps({
        'window_TU':[50000,100000],'seeds':list(range(10)),
        'member_array_index':0,'aggregation':'mean of 10 separately calculated member-1 power spectra',
        'time_series_averaging':False,'member_averaging':False,'welch_unchanged':True,
        'styles':STYLES,'source_sha256':hashlib.sha256((WORK/'source_spectra.json').read_bytes()).hexdigest(),
        'png_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
        'limitations':'Cocean/ALK only eight displayed bins; overlap retained, no shifts or smoothing'
    },indent=2),encoding='utf8')
    print('PNG_READY',out,flush=True)

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='download':download()
    else:plot()
