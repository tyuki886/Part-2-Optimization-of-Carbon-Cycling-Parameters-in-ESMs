from pathlib import Path
import json,shutil,hashlib
B=Path(__file__).resolve().parent
D=Path('D:/SRDP/论文大作！/MCPE26.0/9.2/三通道MCPE6-20全图_谱100000-150000TU_20260913')
old=B.parent/'three_channel_complete578_20260913'
m=json.loads((old/'post_validation.json').read_text())
items=[]
for p in (old/'figures').glob('*.png'):
    if p.name.startswith(('rmse_','rate_')):items.append((p,'RMSE' if p.name.startswith('rmse_') else 'correction_rates',m['images'][p.name]['sha256']))
meta=json.loads((B/'figures/parameter_means/validation.json').read_text())
for name,q in meta['figures'].items():items.append((B/'figures/parameter_means'/name,'parameter_means',q['sha256']))
assert len(items)==33
receipts=[]
for source,group,h in items:
    assert hashlib.sha256(source.read_bytes()).hexdigest()==h
    target=D/group/source.name;target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==source.read_bytes()
    else:shutil.copyfile(source,target)
    assert hashlib.sha256(target.read_bytes()).hexdigest()==h
    receipts.append({'path':str(target),'sha256':h})
(B/'delivery_partial.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2))
print('33 verified PNG delivered:',D)
