from pathlib import Path
import getpass,json,hashlib,time,sys
import paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/three_channel_complete578_20260913'
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
DEPS='/public/home/hou/wyh/MCPE26.0/twin_work_3x3/python_deps'
DEST=Path('D:/SRDP/论文大作！/MCPE26.0/9.2/三通道完整578obs_原格式_20260913')
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
def cmd(s):
    _,o,e=c.exec_command(s,timeout=180);a=o.read().decode();b=e.read().decode()
    assert o.channel.recv_exit_status()==0,(a,b)
    return a
def pbs(name,action):
    return f'''#!/bin/bash
#PBS -N {name}
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=01:00:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH={R}:{DEPS}
{PY} {action}
'''
try:
    if sys.argv[1]=='deploy':
        cmd(f'test ! -e {R} && mkdir -p {R}/logs')
        manifest=json.loads((B/'manifest.json').read_text())
        with c.open_sftp() as ftp:
            for name,h in manifest.items():
                assert hashlib.sha256((B/name).read_bytes()).hexdigest()==h
                ftp.put(str(B/name),R+'/'+name)
            ftp.put(str(B/'manifest.json'),R+'/manifest.json')
            for file,name,action in [('preflight.pbs','Tri578Check','task.py preflight'),('run.pbs','Tri578Run','task.py "${PBS_ARRAYID:?}"'),('post.pbs','Tri578Plot','postprocess.py')]:
                with ftp.open(R+'/'+file,'w') as f:f.write(pbs(name,action))
        print(cmd(f'''set -eu
cd {R}
{PY} -c 'import pathlib,json,hashlib;m=json.load(open("manifest.json"));assert all(hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest()==h for n,h in m.items());print("HASH_PASS")'
gfortran -O3 -ffree-line-length-none -c RKmethod.f90
gfortran -O3 -ffree-line-length-none -c MCPE42_new.f90
gfortran -O3 -ffree-line-length-none exp21_new.f90 MCPE42_new.o RKmethod.o -o exp21_new
gfortran -O0 -fcheck=all -ffree-line-length-none test_config.f90 MCPE42_new.o RKmethod.o -o test_config
{PY} -m py_compile task.py postprocess.py
cd logs
qsub ../preflight.pbs > ../preflight_job.txt
cat ../preflight_job.txt
'''),flush=True)
    elif sys.argv[1]=='finish':
        previous=None
        for _ in range(240):
            s=json.loads(cmd(f'''cd {R} && {PY} -c 'from pathlib import Path;import json;p=Path(".");print(json.dumps(dict(preflight=(p/"PREFLIGHT_PASS").exists(),production=(p/"production_job.txt").exists(),ready=len(list(p.glob("runs/*/READY"))),failed=[str(f) for f in p.glob("*/*/FAILED")],post=(p/"post_job.txt").exists(),complete=(p/"FIGURES_READY").exists(),post_failed=(p/"POST_FAILED").read_text() if (p/"POST_FAILED").exists() else None)))' '''))
            if s!=previous:print(json.dumps(s),flush=True);previous=s
            if s['failed'] or s['post_failed']:raise RuntimeError(s)
            if s['preflight'] and not s['production']:
                print('PRODUCTION_JOB',cmd(f'cd {R}/logs && qsub -t 0-329%10 ../run.pbs > ../production_job.txt && cat ../production_job.txt'),flush=True)
            if s['ready']==330 and not s['post']:
                print('POST_JOB',cmd(f'cd {R}/logs && qsub ../post.pbs > ../post_job.txt && cat ../post_job.txt'),flush=True)
            if s['complete']:
                with c.open_sftp() as ftp:
                    for name in ['summary.json','post_validation.json','FIGURES_READY','PREFLIGHT_PASS','preflight_job.txt','production_job.txt','post_job.txt']:
                        ftp.get(R+'/'+name,str(B/name))
                    meta=json.loads((B/'post_validation.json').read_text())
                    local=B/'figures';local.mkdir(exist_ok=True);DEST.mkdir(parents=True,exist_ok=True)
                    for name,info in meta['images'].items():
                        ftp.get(R+'/figures/'+name,str(local/name))
                        assert hashlib.sha256((local/name).read_bytes()).hexdigest()==info['sha256']
                        target=DEST/name
                        if target.exists():assert target.read_bytes()==(local/name).read_bytes()
                        else:target.write_bytes((local/name).read_bytes())
                print('COMPLETE',len(meta['images']),str(DEST),flush=True);break
            time.sleep(20)
        else:print('WAIT_WINDOW_ENDED; inspect before resubmitting',flush=True)
    else:raise ValueError(sys.argv[1])
finally:c.close()
