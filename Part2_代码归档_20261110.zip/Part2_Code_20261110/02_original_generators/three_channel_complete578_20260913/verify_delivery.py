"""Independent local numeric, delivery-hash and image-integrity checks."""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image,ImageOps,ImageDraw
B=Path(__file__).resolve().parent
D=Path('D:/SRDP/论文大作！/MCPE26.0/9.2/三通道完整578obs_原格式_20260913')
T=B.parent/'mcpe_entry2000_eval90k_100k/production'
s=json.loads((B/'summary.json').read_text())
v=json.loads((B/'post_validation.json').read_text())
assert v['runs_validated']==490 and v['new_runs']==330 and v['all_seeds_retained']
assert v['reused_S8_exact_match'] and len(v['render_bound_values_checked'])==18
assert len(s['RMSE_per_seed'])==49
for k,x in s['RMSE_per_seed'].items():
    a=np.asarray(x)
    assert a.shape==(10,10) and np.isfinite(a).all() and (a>=0).all()
    np.testing.assert_allclose(a.mean(0),s['RMSE_mean'][k],rtol=0,atol=1e-14)
for name,h in v['template_sha256'].items():
    assert hashlib.sha256((B/name).read_bytes()).hexdigest()==h
    assert (B/name).read_bytes()==(T/name).read_bytes()
names=[f'rmse_three_channel_578_MCPE{n}.png' for n in range(6,21)]
names += [f'rate_three_channel_578_MCPE7-20_{n}obs.png' for n in [5,7,8]]
names += [f'parameter_mean_MCPE{n}_8obs.png' for n in [12,14,16]]
assert set(names)==set(v['images'])
qa=B/'visual_qa';qa.mkdir(exist_ok=True)
for name in names:
    p=B/'figures'/name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==v['images'][name]['sha256']
    assert p.read_bytes()==(D/name).read_bytes()
    with Image.open(p) as im:im.verify()
for start in range(0,21,3):
    thumbs=[]
    for name in names[start:start+3]:
        with Image.open(B/'figures'/name) as im:
            t=ImageOps.contain(im.convert('RGB'),(1680,1350))
        card=Image.new('RGB',(1680,t.height+30),'white')
        card.paste(t,((1680-t.width)//2,30))
        ImageDraw.Draw(card).text((10,8),name,fill='black')
        thumbs.append(card)
    out=Image.new('RGB',(1680,sum(x.height for x in thumbs)),'white');y=0
    for t in thumbs:out.paste(t,(0,y));y+=t.height
    out.save(qa/f'contact_{start//3+1:02d}.png')
result={'numeric_checks':'PASS','files':21,'matched_seed_runs':490,'original_templates_byte_identical':True,'delivery_hashes':'PASS','visual_review':'PENDING'}
(qa/'local_validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
print('VARIABLES',s['variables'])
for k in ['M22_v00','M22_v01','M22_v02','M22_v03','M12_v04','M12_v05','M12_v06','M14_v06','M16_v06']:
    print(k,np.round(s['RMSE_mean'][k],8))
