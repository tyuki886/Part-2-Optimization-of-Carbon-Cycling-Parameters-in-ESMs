program test_config
use MCPE42
implicit none
integer,allocatable::r(:)
integer(kind=8),allocatable::s(:),e(:)
integer(kind=8)::c(8)
real(kind=dp),allocatable::w(:,:)
integer::i,j
call configure_parameter_channels()
r=scheme_est_rows(6)
if(size(r)/=6)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,6
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,6
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(6,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(7)
if(size(r)/=7)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,7
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,7
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(7,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(8)
if(size(r)/=8)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,8
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,8
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(8,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(9)
if(size(r)/=9)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,9
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,9
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(9,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(10)
if(size(r)/=10)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,10
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,10
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(10,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(11)
if(size(r)/=11)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,11
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,11
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(11,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(12)
if(size(r)/=12)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,12
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,12
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(12,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(13)
if(size(r)/=13)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,13
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,13
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(13,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(14)
if(size(r)/=14)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33,15]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,14
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,14
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(14,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(15)
if(size(r)/=15)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33,15,36]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,15
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,15
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(15,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLES"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(16)
if(size(r)/=16)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33,15,36,5]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,16
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,16
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(16,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLES"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(5,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(16,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(17)
if(size(r)/=17)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33,15,36,5,12]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,17
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,17
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(17,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLES"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(5,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(16,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(12,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,4000_8,5000_8,200000_8]))error stop "CYCLES"
if(any(w(17,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(18)
if(size(r)/=18)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33,15,36,5,12,38]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,18
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,18
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(18,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLES"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(5,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(16,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(12,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,4000_8,5000_8,200000_8]))error stop "CYCLES"
if(any(w(17,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(38,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,2500_8,4000_8,100000_8]))error stop "CYCLES"
if(any(w(18,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(19)
if(size(r)/=19)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33,15,36,5,12,38,42]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,19
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,19
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(19,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLES"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(5,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(16,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(12,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,4000_8,5000_8,200000_8]))error stop "CYCLES"
if(any(w(17,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(38,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,2500_8,4000_8,100000_8]))error stop "CYCLES"
if(any(w(18,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(42,c)
if(any(c/=[500_8,500_8,500_8,1600_8,1000_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(19,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(20)
if(size(r)/=20)error stop "SIZE"
if(any(r/=[2,39,40,4,35,16,3,10,17,1,9,37,33,15,36,5,12,38,42,26]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,20
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,20
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(20,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLES"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(5,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(16,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(12,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,4000_8,5000_8,200000_8]))error stop "CYCLES"
if(any(w(17,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(38,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,2500_8,4000_8,100000_8]))error stop "CYCLES"
if(any(w(18,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(42,c)
if(any(c/=[500_8,500_8,500_8,1600_8,1000_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(19,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(26,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(20,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
r=scheme_est_rows(22)
if(size(r)/=22)error stop "SIZE"
if(any(r/=[2,4,3,1,33,5,42,26,7,32,39,35,10,16,9,17,15,37,12,38,40,36]))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,22
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,22
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
allocate(w(22,8))
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(5,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(42,c)
if(any(c/=[500_8,500_8,500_8,1600_8,1000_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(26,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(7,c)
if(any(c/=[800_8,800_8,800_8,1600_8,1000_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(32,c)
if(any(c/=[800_8,800_8,800_8,1000_8,1000_8,0_8,0_8,0_8]))error stop "CYCLES"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLES"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLES"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLES"
if(any(w(16,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLES"
if(any(w(17,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLES"
if(any(w(18,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(12,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,4000_8,5000_8,200000_8]))error stop "CYCLES"
if(any(w(19,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(38,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,2500_8,4000_8,100000_8]))error stop "CYCLES"
if(any(w(20,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLES"
if(any(w(21,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLES"
if(any(w(22,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK"
deallocate(w)
print *, "CONFIG_TEST_PASS"
end program
