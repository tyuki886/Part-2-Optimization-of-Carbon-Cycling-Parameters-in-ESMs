"""Enable missing observation variants, preserving existing S8 byte-replay behavior."""
from pathlib import Path
import json,hashlib,re
B=Path(__file__).resolve().parent
OLD=B.parent/'three_channel_sweep6_20_20260912'
TPL=B.parent/'mcpe_entry2000_eval90k_100k/production'
def save(name,data):
    if isinstance(data,str):data=data.encode('utf-8')
    p=B/name
    if p.exists():assert p.read_bytes()==data,name
    else:p.write_bytes(data)
for name in ['RKmethod.f90','MCPE42_new.f90','audit_base.py','checked_exec.py','test_config.f90','baseline_config.json']:
    save(name,(OLD/name).read_bytes())
t=(OLD/'exp21_new.f90').read_text(encoding='utf-8')
before="    if(.not.((n>=6.and.n<=20.and.v==6).or.(n==22.and.(v==3.or.v==6))))error stop 'INVALID_SWEEP_MODE'"
after="    if(.not.((n>=6.and.n<=20.and.v>=4.and.v<=6).or.(n==22.and.v>=0.and.v<=3)))error stop 'INVALID_COMPLETE_MODE'"
assert t.count(before)==1;t=t.replace(before,after)
before='        else if(v==4)then\n            r=scheme_est_rows_5obs(n)'
after='        else if(v==4)then\n            r=scheme_est_rows(n) ! keep global entry slots; absent observation channels have zero updates'
assert t.count(before)==1;t=t.replace(before,after)
save('exp21_new.f90',t)
assert t.replace(after,before).replace("    if(.not.((n>=6.and.n<=20.and.v>=4.and.v<=6).or.(n==22.and.v>=0.and.v<=3)))error stop 'INVALID_COMPLETE_MODE'", "    if(.not.((n>=6.and.n<=20.and.v==6).or.(n==22.and.(v==3.or.v==6))))error stop 'INVALID_SWEEP_MODE'")==(OLD/'exp21_new.f90').read_text(encoding='utf-8')
for name in ['plot_c80_15figs.py','plot_corr_c79.py','times.ttf']:save(name,(TPL/name).read_bytes())
files=['RKmethod.f90','MCPE42_new.f90','exp21_new.f90','audit_base.py','checked_exec.py','test_config.f90','baseline_config.json','task.py','postprocess.py','plot_c80_15figs.py','plot_corr_c79.py','times.ttf']
save('manifest.json',json.dumps({n:hashlib.sha256((B/n).read_bytes()).hexdigest() for n in files},indent=2))
print('PREPARED 330 new runs; same initialization, slots and periods as completed S8')
