"""Restore the exact original seven-bar templates using all 490 matched runs."""
from pathlib import Path
import json,hashlib,os,runpy,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image
import audit_base as audit
from task import B,OLD,REF,task
TAG='three_channel_578'
OUT=B/'figures'
def main():
    assert (B/'PREFLIGHT_PASS').exists()
    OUT.mkdir(exist_ok=True)
    original=json.loads((OLD/'summary.json').read_text())
    runs=[];values={};receipts=[]
    for i in range(330):
        n,v,s=task(i);runs.append((B/'runs'/f'{i:03d}',n,v,s))
    for n in range(6,21):
        for s in range(10):runs.append((OLD/'runs'/f'M{n:02d}_s{s}',n,6,s))
    for s in range(10):runs.append((REF/'runs'/f'CDA8{s}',22,3,s))
    assert len(runs)==490
    for d,n,v,s in runs:
        assert (d/'READY').exists() and not (d/'FAILED').exists()
        a=audit.validate(d,n,v,10000000,9000000,10000000)
        assert (d/'initial_parameters.txt').read_bytes()==(REF/'runs'/f'CDA8{s}'/'initial_parameters.txt').read_bytes()
        x=np.array(a['rmse']);values[n,v,s]=x
        if v==6:np.testing.assert_array_equal(x,original['RMSE_per_seed'][str(n)][s])
        if v==3:np.testing.assert_array_equal(x,original['CDA8_per_seed'][s])
        source=d/f'rmse_M{n:02d}_v{v:02d}.txt'
        if v==0:target=B/'results/ctl'/f'seed{s}/rmse_M10_v00.txt'
        elif v<4:target=B/'results/CDA'/f'seed{s}/rmse_M20_v{v:02d}.txt'
        else:target=B/'results'/f'S{n}'/f'seed{s}'/source.name
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==source.read_bytes()
        else:shutil.copyfile(source,target)
        receipts.append({'scheme':n,'variant':v,'seed':s,'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
    font_manager.fontManager.addfont(str(B/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','axes.unicode_minus':False})
    os.environ.update(MCPE_RESULTS_DIR=str(B/'results'),MCPE_FIGURES_DIR=str(OUT),MCPE_TAG=TAG,
        MCPE_SKIP_SUMMARY='1',MCPE_RMSE_TITLE_TEMPLATE='MCPE{ns} RMSE',
        MCPE_CORR_TITLE_TEMPLATE='RMSE correction rate vs MCPE6 ({obs}obs)')
    # Capture figure bindings at save time; original layout code remains byte-identical.
    oldsave=plt.Figure.savefig;render_checks=[]
    def checked_save(fig,path,*args,**kwargs):
        name=Path(path).name
        if name.startswith('rmse_'):
            n=int(name.split('MCPE')[1].split('.')[0])
            assert len(fig.axes)==10
            for j,ax in enumerate(fig.axes):
                expected=[np.mean([values[22,v,s][j] for s in range(10)]) for v in range(4)]
                expected += [np.mean([values[n,v,s][j] for s in range(10)]) for v in [4,5,6]]
                assert len(ax.patches)==7
                np.testing.assert_allclose([p.get_height() for p in ax.patches],expected,rtol=0,atol=1e-14)
                assert [t.get_text() for t in ax.get_xticklabels()]==['CTL','CDA5','CDA7','CDA8','MCPE-5obs','MCPE-7obs','MCPE-8obs']
            render_checks.append(name)
        elif name.startswith('rate_'):
            obs=int(name.split('_')[-1].split('obs')[0]);v={5:4,7:5,8:6}[obs]
            fig.canvas.draw();renderer=fig.canvas.get_renderer()
            for j,ax in enumerate(fig.axes):
                expected=[np.mean([100*(values[6,v,s][j]-values[n,v,s][j])/values[6,v,s][j] for s in range(10)]) for n in range(7,21)]
                np.testing.assert_allclose([p.get_height() for p in ax.patches],expected,rtol=1e-12,atol=1e-10)
                boxes=[t.get_window_extent(renderer) for t in ax.get_xticklabels()]
                assert min(b.x0-a.x1 for a,b in zip(boxes,boxes[1:]))>0
            render_checks.append(name)
        return oldsave(fig,path,*args,**kwargs)
    plt.Figure.savefig=checked_save
    try:
        try:runpy.run_path(str(B/'plot_c80_15figs.py'))
        except SystemExit as e:
            if e.code not in (None,0):raise
        result=runpy.run_path(str(B/'plot_corr_c79.py'))
        expected=np.array([[[[100*(values[6,v,s][j]-values[n,v,s][j])/values[6,v,s][j] for s in range(10)] for j in range(10)] for n in range(7,21)] for v in [4,5,6]])
        np.testing.assert_allclose(result['corr'],expected,rtol=1e-12,atol=1e-10)
    finally:plt.Figure.savefig=oldsave;plt.close('all')
    assert len(render_checks)==18
    priorfig=json.loads((OLD/'figures_8obs/figure_validation.json').read_text())
    for n in [12,14,16]:
        name=f'parameter_mean_MCPE{n}_8obs.png';source=OLD/'figures_8obs'/name
        assert hashlib.sha256(source.read_bytes()).hexdigest()==priorfig['figures'][name]['sha256']
        shutil.copyfile(source,OUT/name)
    images={}
    for p in OUT.glob('*.png'):
        with Image.open(p) as im:im.verify()
        with Image.open(p) as im:
            assert im.width>=3800 and im.height>=2300
            images[p.name]={'size':list(im.size),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    assert len(images)==21
    summary={'variables':original['variables'],'RMSE_per_seed':{},'RMSE_mean':{},
      'window_TU':[90000,100000],'native_points_per_seed':1000000,'seeds':10,
      'new_runs':330,'reused_runs':160,'variant_map':{'0':'CTL','1':'CDA5','2':'CDA7','3':'CDA8','4':'MCPE5obs','5':'MCPE7obs','6':'MCPE8obs'},
      'selection_policy':'Same global three-channel entry slots for every variant; missing observation channels cannot update parameters; 22-parameter initialization unchanged.',
      'correction_definition':'Mean of per-seed (MCPE6-RMSE)/MCPE6*100 for each observation system'}
    for n,v,s in values:
        key=f'M{n:02d}_v{v:02d}'
        if key not in summary['RMSE_per_seed']:
            a=np.array([values[n,v,k] for k in range(10)])
            summary['RMSE_per_seed'][key]=a.tolist();summary['RMSE_mean'][key]=a.mean(0).tolist()
    (B/'summary.json').write_text(json.dumps(summary,indent=2))
    (B/'post_validation.json').write_text(json.dumps({'runs_validated':490,'new_runs':330,'all_seeds_retained':True,
      'reused_S8_exact_match':True,'render_bound_values_checked':render_checks,'images':images,'receipts':receipts,
      'template_sha256':{name:hashlib.sha256((B/name).read_bytes()).hexdigest() for name in ['plot_c80_15figs.py','plot_corr_c79.py']},
      'visual_QA':'pending'},indent=2))
    (B/'FIGURES_READY').write_text('21 PNGs; 490 runs validated; original templates retained.\n')
if __name__=='__main__':
    try:main()
    except Exception as e:(B/'POST_FAILED').write_text(repr(e));raise
