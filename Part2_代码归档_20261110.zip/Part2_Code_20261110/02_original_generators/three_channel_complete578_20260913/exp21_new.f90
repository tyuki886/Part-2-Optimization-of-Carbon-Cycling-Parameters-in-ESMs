program exp21
    use MCPE42; implicit none
    integer :: v,n,st,nr,no
    integer,allocatable :: r(:),oi(:),br(:),nr2(:)
    real(kind=dp),allocatable :: ov2(:),of(:),w(:,:),cv(:)
    integer(kind=8),allocatable :: cc(:,:),st2(:),en2(:)
    integer(kind=8) :: ts,es,ee
    character(32) :: val,stem; character(64) :: lb
    logical :: diag          ! MCPE_DIAG=1 开启参数估计诊断日志（diag.txt）
    integer :: st5; character(16) :: dv
    logical :: paper_order   ! MCPE_ORDER=paper/paper10 触发 C-36A/B 分量均衡结构（v=4 专用）
    logical :: paper10       ! MCPE_ORDER=paper10 → C-36B 10 参数队列（标准 3000 TU 入场）
    logical :: c37           ! MCPE_ORDER=c37 → C-37 MCPE8 起步主序列（4 物理同时 + 顺次 3000TU）
    logical :: c39           ! MCPE_ORDER=c39 → C-39 1000TU 周期 + 1000TU 顺次入场 + 50000TU 总长（用户钦定）
    integer :: st6
    integer :: diag_cnt, infl_skip
    diag=.false.; call get_environment_variable('MCPE_DIAG',dv,status=st5)
    if(st5==0)diag=trim(dv)=='1'
    diag_cnt=0; infl_skip=0
    if(diag)then
        open(78,file='diag.txt',status='replace'); close(78)
    endif
    call get_environment_variable('MCPE_SCHEME',val,status=st)
    if(st/=0)error stop 'S'; read(val,*) n
    call get_environment_variable('MCPE_VARIANT',val,status=st)
    if(st/=0)error stop 'V'; read(val,*) v
    paper_order=.false.; paper10=.false.; c37=.false.; c39=.false.; call get_environment_variable('MCPE_ORDER',val,status=st6)   ! C-36A/B, C-37, C-39
    if(st6==0.and.trim(val)=='paper')paper_order=.true.
    if(st6==0.and.trim(val)=='paper10')then; paper_order=.true.; paper10=.true.; endif
    if(st6==0.and.trim(val)=='c37')c37=.true.
    if(st6==0.and.trim(val)=='c39')c39=.true.
    if(paper_order.or.paper10.or.c37.or.c39)error stop 'LEGACY_ORDER_DISABLED'
    if(.not.((n>=6.and.n<=20.and.v>=4.and.v<=6).or.(n==22.and.v>=0.and.v<=3)))error stop 'INVALID_COMPLETE_MODE'
    if(v>=4)call configure_parameter_channels()
    call set_obs_freq_from_env()   ! C-24: 碳观测频率可由 MCPE_FREQ 覆盖（16 组扫描）
    call scheme_config(n,ts,es,ee)
    call get_environment_variable('MCPE_STEPS',val,status=st)
    if(st==0)read(val,*) ts
    call get_environment_variable('MCPE_EVAL',val,status=st)
    if(st==0)read(val,*) es
    call get_environment_variable('MCPE_EVAL_END',val,status=st)   ! C-25: 评估窗口终点可覆盖（默认 150k）
    if(st==0)read(val,*) ee
    call get_environment_variable('MCPE_SMOKE',dv,status=st5)
    if(st5/=0.or.trim(dv)/='1')then
        if(ts/=10000000_8.or.es/=9000000_8.or.ee/=10000000_8)error stop 'WRONG_PRODUCTION_WINDOW'
    endif
    if(es<0_8.or.es>=ee.or.ee>ts)error stop 'INVALID_RMSE_WINDOW'
    br=all_active_rows(); nr2=top22  ! C-21: 5% noise only on top20, unified across CTL/CDA/MCPE
    select case(n)
    case(6:22); write(stem,'("rmse_M",I2.2,"_v",I2.2,".txt")') n,v
    case default; error stop 'Bad scheme'
    end select
    select case(v)
    case(0); lb='CTL'
        call r21(trim(lb),trim(stem),br2=br,nr3=nr2,tsp=ts,rs=es,re=ee)
    case(1:3); no=merge(5,merge(7,8,v==2),v==1); allocate(oi(no),ov2(no),of(no))
        ! C-38 (2026-08-09): 恢复 CDA5/7/8（x1/x3 观测回归；C-37 去 x1/x3 后 CDA x3 失控=9.76）
        if(v==1)then;lb='CDA5';oi=obs5_idx;ov2=obs5_var;of=obs5_freq;endif
        if(v==2)then;lb='CDA7';oi=obs7_idx;ov2=obs7_var;of=obs7_freq;endif
        if(v==3)then;lb='CDA8';oi=obs8_idx;ov2=obs8_var;of=obs8_freq;endif
        call r21(trim(lb),trim(stem),oi,ov2,of,br2=br,nr3=nr2,tsp=ts,rs=es,re=ee,ae=ee+1_8)
    case(4:6); no=merge(5,merge(7,8,v==5),v==4); allocate(oi(no),ov2(no),of(no))
        ! C-38 (2026-08-09): MCPE 恢复 5/7/8obs；MCPE8 起步入场结构（c37）保留
        if(v==4)then;oi=obs5_idx;ov2=obs5_var;of=obs5_freq;endif
        if(v==5)then;oi=obs7_idx;ov2=obs7_var;of=obs7_freq;endif
        if(v==6)then;oi=obs8_idx;ov2=obs8_var;of=obs8_freq;endif
        ! C-37/C-38: MCPE_ORDER=c37 时用 MCPE8 起步主序列（4 物理同时 + 顺次 3000TU）
        ! C-36A/B: MCPE_ORDER=paper/paper10 时 3obs 改用分量均衡参数集（C-36 遗留分支）
        if(c37)then
            if(v==4)then; r=c37_rows_5obs(n); else; r=c37_rows(n); endif
            write(stem,'("rmse_C38_v",I2.2,".txt")') v
        else if(c39)then
            ! C-39 (2026-08-10): 用户钦定——周期 1000TU、入场 20000+1000k（第20个39000）、总长 50000TU。
            ! 5obs 只估物理（scheme_est_rows_5obs，C-29 版口径）；7/8obs 物理+碳各半（scheme_est_rows）
            if(v==4)then; r=scheme_est_rows_5obs(n); else; r=scheme_est_rows(n); endif
            write(stem,'("rmse_C39_v",I2.2,".txt")') v
        else if(v==4.and.paper_order)then
            if(paper10)then
                r=paper_rows_10(); write(stem,'("rmse_C36B_v",I2.2,".txt")') v
            else
                r=paper_rows(); write(stem,'("rmse_C36A_v",I2.2,".txt")') v
            endif
        else if(v==4)then
            r=scheme_est_rows(n) ! keep global entry slots; absent observation channels have zero updates
        else
            r=scheme_est_rows(n)
        endif
        nr=size(r)
        allocate(cc(nr,no),st2(nr),en2(nr),w(nr,no),cv(nr))
        nr2=top22
        call fill_canonical_table(r,no,cc)
        if(c37)then
            call c37_starts_ends(r,st2,en2)      ! C-37：4 物理同时入场 + 之后每 3000 TU 顺次
        else if(c39)then
            call c39_starts_ends(r,st2,en2)      ! C-39：每 1000 TU 一个入场（20000 起），ends=50000 TU
        else if(paper_order.and..not.paper10)then
            call paper_starts_ends(st2,en2)      ! C-36A：论文延迟 0/0/0/0/200/400 TU
        else
            call scheme_starts_ends(r,st2,en2)   ! C-36B 及标准方案：每 3000 TU 一个
        endif
        call assign_component_mask(r,no,w); cv=1._dp
        if(v==4)lb='MCPE-S5'; if(v==5)lb='MCPE-S7'; if(v==6)lb='MCPE-S8'
        call r21(trim(lb),trim(stem),oi,ov2,of,r,cc,st2,en2,w,cv,br2=br,nr3=nr2,tsp=ts,rs=es,re=ee,ae=ee+1_8)
    end select

contains
    subroutine r21(sn,rf,oi2,ov3,of2,er,ct2,se,ee3,lw,cf2,br2,tsp,res,rs,re,ae,nr3)
        use RKmethod; use MCPE42, only: n_all, is_physical, phys_rows
        character(*),intent(in)::sn,rf
        integer,intent(in),optional::oi2(:),er(:),br2(:),nr3(:)
        real(kind=dp),intent(in),optional::ov3(:),of2(:),lw(:,:),cf2(:)
        integer(kind=8),intent(in),optional::ct2(:,:),se(:),ee3(:)
        integer(kind=8),intent(in),optional::tsp,res,rs,re,ae
        integer,parameter::ns=10,en=20; integer(kind=8),parameter::sa=1000000_8,stp=100_8  ! C-29: 同化 10000 TU 起（起转 0-10000 纯自由跑）
        real(kind=dp)::cfv(8)
        real(kind=dp)::xt(ns),xe(ns,en),pt(n_all),pe(n_all,en),isd(n_all),rmse(ns),mse2(ns),nf,gv
        real(kind=dp)::smean(ns),eobs(en),oinc(en),oval,cn(8),sw; logical::pu(n_all),bi,hn
        integer,parameter::ci(8)=[1,2,3,4,7,8,9,10]
        integer(kind=8)::i,cr2,run_steps,rss,ree,ae2; integer::no2,ne2,io2,row2,m,j,k,vi,ni
        real(kind=dp)::pold(en),dd,maxrel,scal,c26bar,c27bar,c28bar,brtruth,brmean
        real(kind=dp)::initial_parameter_mean(n_all)
        character(512)::checkpoint_path
        integer::checkpoint_status,checkpoint_unit
        integer(kind=8),allocatable::lastup(:,:)
        integer(kind=8)::updates(45,8),first_updates(45,8),final_updates(45,8),state_updates(8)
        logical::save_mean
        character(16)::mean_env
        integer::mean_st
        real(kind=dp)::param_std(45),param_mean_now(45)
        logical::trc,traj,btraj,ex; character(8)::tv; integer::st4
        trc=.false.; call get_environment_variable('MCPE_TRACE',tv,status=st4)
        if(st4==0)trc=trim(tv)=='1'
        traj=.false.; call get_environment_variable('MCPE_ALK_TRAJECTORY',tv,status=st4)
        if(st4==0)traj=trim(tv)=='1'
        btraj=.false.; call get_environment_variable('MCPE_BCAL_TRAJECTORY',tv,status=st4)
        if(st4==0)btraj=trim(tv)=='1'
        if(trc)then
            inquire(file=trim(rf)//'.tr',exist=ex)
            if(ex)then; open(79,file=trim(rf)//'.tr',status='old'); close(79,status='delete'); endif
        endif


        updates=0_8; first_updates=-1_8; final_updates=-1_8; state_updates=0_8
        rollback_events=0_8
        save_mean=.false.
        call get_environment_variable('MCPE_SAVE_PARAM_MEAN',mean_env,status=mean_st)
        if(mean_st==0)save_mean=trim(mean_env)=='1'
        no2=0; ne2=0; if(present(oi2))no2=size(oi2); if(present(er))ne2=size(er)
        ! C-24: cf 噪声周期自动与观测频率同步（oi2/of2 驱动，消除手动同步）
        cfv=[.04_dp,.04_dp,.04_dp,.20_dp,.20_dp,0.08_dp,5._dp,10._dp]
        do k=1,size(ci); do io2=1,no2
            if(oi2(io2)==ci(k))cfv(k)=of2(io2)
        enddo; enddo
        if(ne2>0.and.no2>0)allocate(lastup(ne2,no2))
        run_steps=15000000_8; if(present(tsp))run_steps=tsp
        rss=14000000_8; ree=15000000_8; if(present(rs))rss=rs; if(present(re))ree=re
        ae2=run_steps+1_8; if(present(ae))ae2=ae
        call seed2(); call reset_all_46(); call get_standard_params45(pt)
        xt=0._dp; xt(2)=1._dp; call update_sea_ice(xt)
        do m=1,en
            call reset_all_46(); call get_standard_params45(pe(:,m))
            do j=1,n_all
                bi=.false.; if(present(br2))bi=any(br2==j)
                if(bi)then; hn=.false.; if(present(nr3))hn=any(nr3==j); nf=0._dp; if(hn)nf=0.05_dp
                    gv=random_gaussian(); pe(j,m)=pt(j)*1.10_dp*(1._dp+nf*gv)
                else; pe(j,m)=pt(j); endif
            enddo; xe(:,m)=xt
        enddo; call clamp45(pe)
        initial_parameter_mean=sum(pe,dim=2)/real(en,dp)
        param_std=sqrt(sum((pe-spread(initial_parameter_mean,2,en))**2,dim=2)/real(en,dp))
        open(93,file='initial_parameters.txt',status='replace')
        do j=1,n_all
            write(93,'(I4,3ES25.17E3)')j,pt(j),initial_parameter_mean(j),param_std(j)
        enddo
        close(93)
        if(save_mean)then
            open(94,file='parameter_mean.txt',status='replace')
            write(94,'(F12.3,90ES25.17E3)')0._dp,initial_parameter_mean,param_std
        endif
        open(93,file='schedule.txt',status='replace')
        do k=1,ne2
            write(93,'(*(I12,1X))')er(k),se(k),ee3(k),ct2(k,:)
        enddo
        close(93)
        isd=0._dp
        if(ne2>0)then
            do k=1,ne2; row2=er(k); isd(row2)=sqrt(sum((pe(row2,:)-sum(pe(row2,:))/en)**2)/en); enddo
            if(no2>0)then; do k=1,ne2; lastup(k,:)=se(k); enddo; endif  ! 复查文档 §7: 入场后首个完整周期才更新
        endif
        mse2=0._dp; cr2=0_8
        ! Optional diagnostic trajectory: 10000--11000 TU at the native 0.01-TU step.
        ! The feature is opt-in so normal C80 production output is unchanged.
        if(traj)open(91,file=trim(rf)//'.alktraj',status='replace')
        ! Optional Bcal diagnostic: 10400--10500 TU at the native 0.01-TU step.
        if(btraj)open(92,file=trim(rf)//'.bcaltraj',status='replace')
        do i=1,run_steps
            call reset_all_46(); call adv_true_state(xt,i,10)
            do m=1,en
                call reset_all_46(); call set_member_params45(pe(:,m)); call adv_true_state(xe(:,m),i,10)
            enddo
            if(no2>0.and.i>=sa.and.i<ae2)then
                cn=0._dp; do k=1,size(ci); if(mod(i,nint(cfv(k)*real(stp,kind=dp),kind=8))==0_8)cn(k)=random_gaussian(); enddo; pu=.false.
                do io2=1,no2
                    if(mod(i,nint(of2(io2)*real(stp,kind=dp),kind=8))/=0_8)cycle; vi=oi2(io2); ni=0
                    do k=1,size(ci); if(ci(k)==vi)ni=k; enddo
                    oval=xt(vi)+sqrt(ov3(io2))*cn(ni); eobs=xe(vi,:)
                    state_updates(io2)=state_updates(io2)+1_8
                    call obs_increment(eobs,en,oval,ov3(io2),oinc)
                    ! C-20: x1,x2,x3 cross-update (1.0 EAKF regression); w/TL/Catm/Cocean/ALK self-only
                    do j=1,ns; sw=0._dp; if(vi==j)sw=1._dp
                        if(vi<=3.and.j<=3.and.vi/=j)sw=1._dp
                        if(sw>0._dp) call update_from_obs_inc(eobs,oinc,xe(j,:),en,sw)
                    enddo
                    if(ne2>0)then; do k=1,ne2; row2=er(k)
                        if(i<se(k).or.i>=ee3(k))cycle
                        if(ct2(k,io2)<=0_8)cycle; if(lw(k,io2)<=0._dp)cycle
                        ! 复查文档 §7/§8: 相对周期事件计时器（达到理论周期后的首个观测时刻更新并重置）
                        if(i-lastup(k,io2)>=ct2(k,io2))then
                            do m=1,en; pold(m)=pe(row2,m); enddo
                            call update_from_obs_inc(eobs,oinc,pe(row2,:),en,cf2(k)*lw(k,io2))
                            if(diag)call diag_update(i,row2,pold,pe(row2,:))
                            ! 复查文档 §10.1: 整组统一限幅 1%（保持 EAKF 成员增量比例，防一步推飞）
                            maxrel=0._dp
                            do m=1,en
                                dd=abs((pe(row2,m)-pold(m))/max(abs(pold(m)),1.0e-30_dp))
                                if(dd>maxrel)maxrel=dd
                            enddo
                            if(maxrel>0.01_dp)then
                                scal=0.01_dp/maxrel
                                do m=1,en; pe(row2,m)=pold(m)+scal*(pe(row2,m)-pold(m)); enddo
                            endif
                            updates(row2,io2)=updates(row2,io2)+1_8
                            if(first_updates(row2,io2)<0_8)first_updates(row2,io2)=i
                            final_updates(row2,io2)=i
                            lastup(k,io2)=i; pu(row2)=.true.
                        endif
                    enddo; endif
                enddo
                call enforce_bounds(xe,pe)
                if(ne2>0)then
                    diag_cnt=diag_cnt+1
                    do k=1,ne2; row2=er(k)
                        if(pu(row2))then
                            if(diag)then
                                call diag_inflate(pe,row2,en,isd(row2),i,infl_skip)
                            else
                                call inflate_parameter(pe,row2,en,isd(row2))
                            endif
                        endif
                    enddo
                    if(diag.and.mod(diag_cnt,100)==0)call diag_clamp(pe,er,ne2,i,0)
                    call clamp45(pe)
                    if(diag.and.mod(diag_cnt,100)==0)call diag_clamp(pe,er,ne2,i,1)
                endif
            endif
            if(mod(i,10000_8)==0_8.or.i==run_steps)then
                ! Finite test compatible with gfortran 4.8; no fast-math flags.
                if(.not.all(abs(xt)<=huge(1._dp)).or..not.all(abs(xe)<=huge(1._dp)).or. &
                   .not.all(abs(pe)<=huge(1._dp)))error stop 'NONFINITE_MODEL_STATE'
                if(save_mean)then
                    param_mean_now=sum(pe,dim=2)/real(en,dp)
                    param_std=sqrt(sum((pe-spread(param_mean_now,2,en))**2,dim=2)/real(en,dp))
                    write(94,'(F12.3,90ES25.17E3)')real(i,dp)/100._dp,param_mean_now,param_std
                endif
            endif
            if(i>rss.and.i<=ree)then
                smean=sum(xe,dim=2)/en; mse2=mse2+(smean-xt)**2; cr2=cr2+1_8
            endif
            if(traj.and.i>=1000000_8.and.i<=1100000_8)then
                smean=sum(xe,dim=2)/en
                write(91,'(F12.3,1X,2ES16.8)') dble(i)/100.0_dp, xt(10), smean(10)
            endif
            if(btraj.and.i>=1040000_8.and.i<=1050000_8)then
                smean=sum(xe,dim=2)/en
                c26bar=sum(pe(14,:))/en; c27bar=sum(pe(40,:))/en; c28bar=sum(pe(15,:))/en
                brtruth=xt(10)-0.5_dp*xt(9)+1.0_dp
                brmean=smean(10)-c27bar*smean(9)+c28bar
                write(92,'(F12.3,1X,4(ES16.8,1X))') dble(i)/100.0_dp, &
                    0.00009_dp*xt(9)*max(brtruth,0._dp), c26bar*smean(9)*max(brmean,0._dp), &
                    brtruth, brmean
            endif
            if(trc.and.mod(i,5000_8)==0_8)then
                smean=sum(xe,dim=2)/en
                open(79,file=trim(rf)//'.tr',status='unknown',position='append')
                write(79,'(I10,1X)',advance='no') i
                do k=1,ne2; write(79,'(ES17.9,1X)',advance='no') sum(pe(er(k),:))/dble(en); enddo
                write(79,'(10ES14.5)',advance='no') abs(smean-xt)
                write(79,'(10ES14.5)') sqrt(sum((xe-spread(smean,2,en))**2,dim=2)/dble(en))
                close(79)
            endif
        enddo
        call get_environment_variable('MCPE_CHECKPOINT',checkpoint_path,status=checkpoint_status)
        if(checkpoint_status==0.and.len_trim(checkpoint_path)>0)then
            open(newunit=checkpoint_unit,file=trim(checkpoint_path),status='replace',action='write')
            write(checkpoint_unit,*)run_steps,ns,n_all,en
            write(checkpoint_unit,'(*(ES25.17E3,1X))')xt
            write(checkpoint_unit,'(*(ES25.17E3,1X))')pt
            write(checkpoint_unit,'(*(ES25.17E3,1X))')initial_parameter_mean
            do m=1,en
                write(checkpoint_unit,'(*(ES25.17E3,1X))')pe(:,m)
            enddo
            do m=1,en
                write(checkpoint_unit,'(*(ES25.17E3,1X))')xe(:,m)
            enddo
            close(checkpoint_unit)
        endif
        if(save_mean)close(94)
        open(93,file='audit_scalars.txt',status='replace')
        write(93,*)run_steps,rss,ree,cr2,rollback_events
        write(93,*)state_updates
        close(93)
        open(93,file='parameter_updates.txt',status='replace')
        do j=1,n_all
            do io2=1,8
                write(93,'(2I5,3I14)')j,io2,updates(j,io2),first_updates(j,io2),final_updates(j,io2)
            enddo
        enddo
        close(93)
        param_mean_now=sum(pe,dim=2)/real(en,dp)
        param_std=sqrt(sum((pe-spread(param_mean_now,2,en))**2,dim=2)/real(en,dp))
        open(93,file='final_parameters.txt',status='replace')
        do j=1,n_all
            write(93,'(I4,3ES25.17E3)')j,pt(j),param_mean_now(j),param_std(j)
        enddo
        close(93)
        if(cr2/=ree-rss)error stop 'WRONG_RMSE_SAMPLE_COUNT'
        if(traj)close(91)
        if(btraj)close(92)
        rmse=sqrt(mse2/real(cr2,kind=dp)); open(77,file=rf,status='replace'); write(77,'(10F14.7)')rmse; close(77)
        write(*,'(A,1X,10F12.6)')trim(sn),rmse
    end subroutine

    subroutine seed2(); integer::sz,st3,id,j; integer,allocatable::a(:); character(64)::val2
        id=1; call get_environment_variable('MCPE_SEED',val2,status=st3); if(st3==0)read(val2,*)id
        call random_seed(size=sz); allocate(a(sz)); do j=1,sz; a(j)=id+j*37; enddo; call random_seed(put=a)
    end subroutine

    ! 复查文档 §10.2: 海冰重算前逐成员恢复各自参数
    subroutine enforce_bounds(x,p); real(kind=dp),intent(inout)::x(10,20),p(n_all,20); integer::m
        do m=1,20
            call reset_all_46(); call set_member_params45(p(:,m)); call update_sea_ice(x(:,m))
        enddo
    end subroutine

    ! ===== 参数估计诊断日志（MCPE_DIAG=1 时输出到 diag.txt）=====
    subroutine diag_open()
        open(78,file='diag.txt',status='unknown',position='append')
    end subroutine
    subroutine diag_close()
        close(78)
    end subroutine

    ! UPD 行：参数周期更新后、1% 限幅前的 raw posterior（限幅前原始增量）
    subroutine diag_update(i,row2,pold,pnew)
        integer(kind=8),intent(in)::i; integer,intent(in)::row2
        real(kind=dp),intent(in)::pold(20),pnew(20)
        real(kind=dp)::ome,omew,dme,maxrel
        integer::m
        ome=sum(pold)/dble(20); omew=sum(pnew)/dble(20); dme=omew-ome
        maxrel=0._dp
        do m=1,20
            maxrel=max(maxrel,abs((pnew(m)-pold(m))/max(abs(pold(m)),1.0e-30_dp)))
        enddo
        call diag_open()
        write(78,'(A,1X,I11,1X,A,I2,1X,2ES15.7,1X,ES13.5,1X,ES13.5)') &
            'UPD',i,'P',row2,ome,omew,dme,maxrel
        call diag_close()
    end subroutine

    ! INFL 行：inflation 前后 mean/std + alpha（alpha=1.0 表示调用但未触发阈值）
    ! 触发（alpha>1）全记录；未触发每 100 次采样 1 条（infl_skip 计数）
    subroutine diag_inflate(p,idx,n,init_std,i,sk)
        real(kind=dp),intent(inout)::p(:,:); integer,intent(in)::idx,n
        real(kind=dp),intent(in)::init_std; integer(kind=8),intent(in)::i
        integer,intent(inout)::sk
        real(kind=dp)::mb,sb,ma,sa,alpha,a0=1.0e-3_dp,maxa=2.0_dp
        mb=sum(p(idx,:))/dble(n)
        sb=sqrt(sum((p(idx,:)-mb)**2)/dble(n))
        if(sb<init_std*0.5_dp)then
            alpha=1.0_dp+a0*init_std/max(sb,1.0e-12_dp); alpha=min(alpha,maxa)
        else
            alpha=1.0_dp
        endif
        call inflate_parameter(p,idx,n,init_std)
        ma=sum(p(idx,:))/dble(n)
        sa=sqrt(sum((p(idx,:)-ma)**2)/dble(n))
        if(alpha>1.0_dp)then
            call diag_open()
            write(78,'(A,1X,I11,1X,A,I2,1X,5ES15.7)') 'INFL',i,'P',idx,mb,sb,alpha,ma,sa
            call diag_close()
        else
            sk=sk+1
            if(mod(sk,100)==1)then
                call diag_open()
                write(78,'(A,1X,I11,1X,A,I2,1X,5ES15.7)') 'INFL',i,'P',idx,mb,sb,alpha,ma,sa
                call diag_close()
            endif
        endif
    end subroutine

    ! RAW/CLM 行：clamp45 前（raw posterior）与后（clamped）的 min/mean/max + clipping 成员数
    subroutine diag_clamp(p,rows,nr,i,mode)
        real(kind=dp),intent(in)::p(:,:); integer,intent(in)::rows(:),nr,mode
        integer(kind=8),intent(in)::i
        real(kind=dp)::lo(45),hi(45),mn,me,mx; integer::k,row,nc
        lo=[0.01_dp,1._dp,0.5_dp,0.01_dp,0.1_dp,1e-6_dp,0.01_dp,0.001_dp,0.001_dp,1e-6_dp,&
            1e-8_dp,1e-6_dp,1e-6_dp,1e-8_dp,0.1_dp,0.01_dp,0.01_dp,0.01_dp,0.1_dp,1._dp,&
            0.1_dp,1._dp,1._dp,0.1_dp,0.001_dp,0.001_dp,0.1_dp,0.01_dp,0.01_dp,0.01_dp,&
            1._dp,0.001_dp,0.001_dp,0.001_dp,0.001_dp,1e-6_dp,0.001_dp,0.001_dp,0.001_dp,0.01_dp,&
            10._dp,0.01_dp,0.1_dp,1._dp,0.1_dp]
        hi=[100._dp,100._dp,10._dp,10._dp,10._dp,1._dp,1._dp,1._dp,1._dp,1._dp,&
            0.1_dp,1._dp,0.1_dp,1._dp,100._dp,10._dp,10._dp,10._dp,10._dp,100._dp,&
            10._dp,100._dp,50._dp,10._dp,0.1_dp,0.1_dp,10._dp,1._dp,1._dp,1._dp,&
            100._dp,0.1_dp,1._dp,1._dp,1._dp,0.1_dp,0.1_dp,0.1_dp,0.1_dp,1._dp,&
            1000._dp,1._dp,10._dp,100._dp,10._dp]
        call diag_open()
        do k=1,nr; row=rows(k)
            mn=minval(p(row,:)); me=sum(p(row,:))/dble(20); mx=maxval(p(row,:))
            if(mode==1)then
                nc=count(p(row,:)<lo(row).or.p(row,:)>hi(row))
                write(78,'(A,1X,I11,1X,A,I2,1X,3ES15.7,1X,I3)') 'CLM',i,'P',row,mn,me,mx,nc
            else
                write(78,'(A,1X,I11,1X,A,I2,1X,3ES15.7)') 'RAW',i,'P',row,mn,me,mx
            endif
        enddo
        call diag_close()
    end subroutine

    subroutine clamp45(p); use MCPE42, only: n_all; real(kind=dp),intent(inout)::p(n_all,20)
        real(kind=dp)::lo(45),hi(45); integer::j,m
        lo=[0.01_dp,1._dp,0.5_dp,0.01_dp,0.1_dp,1e-6_dp,0.01_dp,0.001_dp,0.001_dp,1e-6_dp,&
            1e-8_dp,1e-6_dp,1e-6_dp,1e-8_dp,0.1_dp,0.01_dp,0.01_dp,0.01_dp,0.1_dp,1._dp,&
            0.1_dp,1._dp,1._dp,0.1_dp,0.001_dp,0.001_dp,0.1_dp,0.01_dp,0.01_dp,0.01_dp,&
            1._dp,0.001_dp,0.001_dp,0.001_dp,0.001_dp,1e-6_dp,0.001_dp,0.001_dp,0.001_dp,0.01_dp,&
            10._dp,0.01_dp,0.1_dp,1._dp,0.1_dp]
        hi=[100._dp,100._dp,10._dp,10._dp,10._dp,1._dp,1._dp,1._dp,1._dp,1._dp,&
            0.1_dp,1._dp,0.1_dp,1._dp,100._dp,10._dp,10._dp,10._dp,10._dp,100._dp,&
            10._dp,100._dp,50._dp,10._dp,0.1_dp,0.1_dp,10._dp,1._dp,1._dp,1._dp,&
            100._dp,0.1_dp,1._dp,1._dp,1._dp,0.1_dp,0.1_dp,0.1_dp,0.1_dp,1._dp,&
            1000._dp,1._dp,10._dp,100._dp,10._dp]
        do m=1,20; do j=1,n_all
            if(p(j,m)<lo(j))p(j,m)=lo(j); if(p(j,m)>hi(j))p(j,m)=hi(j)
        enddo; enddo
    end subroutine
end program exp21
