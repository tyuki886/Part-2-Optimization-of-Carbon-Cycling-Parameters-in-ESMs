from pathlib import Path
from PIL import Image,ImageOps
B=Path(__file__).resolve().parent
for n in [12,14,16]:
    with Image.open(B/'figures'/f'parameter_mean_MCPE{n}_8obs.png') as im:
        ImageOps.contain(im.convert('RGB'),(1400,1400)).save(B/'visual_qa'/f'parameter_{n}.png')
