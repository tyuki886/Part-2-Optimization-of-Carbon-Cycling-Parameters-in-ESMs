"""Missing 5/7obs and matched CTL/CDA5/CDA7; no filtering of seeds."""
from pathlib import Path
import os,sys,json
import numpy as np
import audit_base as audit
from checked_exec import checked
B=Path(__file__).resolve().parent
OLD=B.parent/'three_channel_sweep6_20_20260912'
REF=B.parent/'three_channel_full22_20260912'
def task(i):
    assert 0<=i<330
    if i<300:return 6+i//20,4+(i//10)%2,i%10
    return 22,(i-300)//10,i%10
def run(d,n,v,seed,steps=10000000,start=9000000,end=10000000):
    d.mkdir(parents=True,exist_ok=False)
    env={k:v for k,v in os.environ.items() if not k.startswith('MCPE_')}
    env.update(MCPE_SCHEME=str(n),MCPE_VARIANT=str(v),MCPE_SEED=str(seed),MCPE_FREQ='1,4,20',
      MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS=str(steps),MCPE_EVAL=str(start),MCPE_EVAL_END=str(end),
      MCPE_SAVE_PARAM_MEAN='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    if steps!=10000000:env.update(MCPE_SMOKE='1',MCPE_CHECKPOINT='checkpoint.txt')
    try:
        execution=checked(B/'exp21_new',d,env,'run')
        a=audit.validate(d,n,v,steps,start,end)
        assert (d/'initial_parameters.txt').read_bytes()==(REF/'runs'/f'CDA8{seed}'/'initial_parameters.txt').read_bytes()
        init=np.loadtxt(d/'initial_parameters.txt');final=np.loadtxt(d/'final_parameters.txt')
        names,counts,first,last,state=audit.expected(n,v,steps)
        idle=~counts.any(1)
        np.testing.assert_array_equal(init[idle],final[idle])
        if v>=4:
            no={4:5,5:7,6:8}[v]
            expected=np.array([[p['row45'],p['entry_TU']*100,10000001]+[audit.CFG['cycles_TU'][p['name']].get(o,0)*100 for o in audit.OBS[:no]] for p in audit.CFG['scheme_parameters'][str(n)]])
            np.testing.assert_array_equal(np.loadtxt(d/'schedule.txt',dtype=np.int64),expected)
        a.update(seed=seed,execution=execution,inactive_parameters_unchanged=True)
        (d/'audit.json').write_text(json.dumps(a,indent=2));(d/'READY').touch()
        print('READY',n,v,seed,steps,flush=True)
    except Exception as e:(d/'FAILED').write_text(repr(e));raise
def preflight():
    env=os.environ.copy();env['MCPE_PARAM_CHANNELS']='x123_w_TL'
    checked(B/'test_config',B,env,'config')
    assert 'CONFIG_TEST_PASS' in (B/'config.log').read_text()
    # Full-duration exact S8 replay proves enabling other modes did not alter the model.
    for n,v,old in [(12,6,OLD/'runs/M12_s0'),(22,3,REF/'runs/CDA80')]:
        d=B/'preflight'/f'replay_{n}_{v}';run(d,n,v,0)
        for f in [f'rmse_M{n:02d}_v{v:02d}.txt','initial_parameters.txt','final_parameters.txt','parameter_mean.txt','parameter_updates.txt']:
            assert (d/f).read_bytes()==(old/f).read_bytes(),f
    # Compare full state checkpoints before entry for each same-observation CDA/MCPE pair.
    for v in [4,5]:
        for n,vv,label in [(20,v,'mcpe'),(22,v-3,'cda')]:
            run(B/'preflight'/f'{label}_{v}',n,vv,0,1999900,1999000,1999900)
        assert (B/'preflight'/f'mcpe_{v}/checkpoint.txt').read_bytes()==(B/'preflight'/f'cda_{v}/checkpoint.txt').read_bytes()
        for n in [6,20]:
            steps=(20000+2000*(n-1)+2020)*100
            run(B/'preflight'/f'entry_{n}_{v}',n,v,0,steps,steps-2000,steps)
    run(B/'preflight/ctl',22,0,0,3000,1000,3000)
    (B/'PREFLIGHT_PASS').write_text('Exact S8+CDA8 replay; all configs; matched pre-entry states; new-channel update counts; inactive parameters constant.\n')
if __name__=='__main__':
    if sys.argv[1]=='preflight':preflight()
    else:
        assert (B/'PREFLIGHT_PASS').exists();i=int(sys.argv[1]);n,v,s=task(i)
        run(B/'runs'/f'{i:03d}',n,v,s)
