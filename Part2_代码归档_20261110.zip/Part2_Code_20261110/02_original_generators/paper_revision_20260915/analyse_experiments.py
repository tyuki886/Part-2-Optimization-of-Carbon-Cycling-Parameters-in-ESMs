from pathlib import Path
import json,hashlib,sys
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent;O=B/'analysis';O.mkdir(exist_ok=True)
V=['x2','w','eta','TL','Catm','Cocean','ALK'];cols=[1,3,4,6,7,8,9]
mult=np.array([10/12,10,100,10,10,10000,10000]);segments=[1024,20480,40960,20480,20480,None,None]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def spec(y,j):
 if segments[j] is None:f,p=signal.periodogram(y,fs=10,window='boxcar',detrend='constant',scaling='density')
 else:f,p=signal.welch(y,fs=10,nperseg=segments[j],noverlap=segments[j]//2,window='hann',detrend='constant',scaling='density')
 f=f*mult[j];p=p/mult[j];take=f<=1.5
 return f[take],p[take]
def metric(x,t):
 mx=x.mean();mt=t.mean();vx=x.var();vt=t.var();cov=np.mean((x-mx)*(t-mt));bias=(mx-mt)**2;amp=(np.sqrt(vx)-np.sqrt(vt))**2;corr=2*(np.sqrt(vx*vt)-cov)
 mse=np.mean((x-t)**2);assert np.isclose(mse,bias+amp+corr,rtol=1e-8,atol=1e-10)
 return [float(q) for q in [np.sqrt(mse),mx-mt,np.sqrt(vx/vt),cov/np.sqrt(vx*vt),bias,amp,corr]]
def spectral_error(p,q,f):
 sel=(f>0)&(f<=1.5);p=p[sel];q=q[sel]
 return [float(np.sum(np.abs(p-q))/np.sum(q)),float(np.sum(p)/np.sum(q)),float(np.mean(np.abs(np.log10(np.maximum(p,1e-30)/np.maximum(q,1e-30)))))]
def feedback():
 receipts=[];powers={};means=np.empty((7,10,10));variance=np.empty_like(means)
 for arm in range(7):
  for seed in range(10):
   d=B/'feedback'/f'arm{arm}_seed{seed}';assert (d/'receipt.json').exists(),str(d)
   assert (d/'states.bin').stat().st_size==1000000*10*8
   assert sha(d/'checkpoint.bin')==sha(B/'feedback'/f'arm0_seed{seed}'/'checkpoint.bin')
   a=np.memmap(d/'states.bin',dtype='<f8',mode='r',shape=(1000000,10));assert np.isfinite(a).all()
   m=np.loadtxt(d/'moments.txt',skiprows=1);means[arm,seed]=m[0];variance[arm,seed]=m[1]
   for j,col in enumerate(cols):
    f,p=spec(a[:,col],j);k=f'{arm}_{j}'
    if k not in powers:powers[k]=[]
    powers[k].append(p);powers[f'f{j}']=f
   if arm==6:
    off=np.memmap(B/'feedback'/f'arm1_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(1000000,10));assert np.array_equal(a[:,:7],off[:,:7]),'Seven-state reduction differs'
   receipts.append(json.loads((d/'receipt.json').read_text()))
   print('feedback',arm,seed,flush=True)
 np.savez_compressed(O/'feedback_spectra.npz',**{k:np.array(v) for k,v in powers.items()})
 rng=np.random.default_rng(20260915);ix=rng.integers(0,10,(19999,10));records=[]
 for arm in range(1,7):
  for j,col in enumerate(cols[:4]):
   delta=100*(variance[arm,:,col]/variance[0,:,col]-1);ci=np.percentile(delta[ix].mean(1),[2.5,97.5]);records.append(dict(arm=arm,variable=V[j],mean_percent_variance_change=float(delta.mean()),ci95=ci.tolist(),seed_values=delta.tolist()))
 (O/'feedback_results.json').write_text(json.dumps({'all_seeds':list(range(10)),'window_TU':[50000,150000],'native_moments_dt':.01,'PSD_dt':.1,'seven_state_reduction_exact':True,'checkpoints_identical':True,'means':means.tolist(),'variances':variance.tolist(),'records':records,'receipts':receipts},indent=2))
def matched():
 powers={};records=[];native=[]
 for arm in range(4):
  for seed in range(10):
   d=B/'matched'/f'arm{arm}_seed{seed}';assert (d/'receipt.json').exists(),str(d)
   if arm>1:assert sha(d/'branch_checkpoint.bin')==sha(B/'matched'/f'arm1_seed{seed}'/'branch_checkpoint.bin')
   a=np.memmap(d/'matched_states.bin',dtype='<f8',mode='r',shape=(500000,36));assert np.isfinite(a).all();assert np.allclose(a[[0,-1],0],[100000.1,150000])
   m=np.loadtxt(d/'matched_moments.txt',skiprows=1);native.append(dict(arm=arm,seed=seed,moments=m.tolist()))
   for j,col in enumerate(cols):
    t=a[:,1+j];f,pt=spec(t,j);key=f'truth_{j}';powers.setdefault(key,[])
    if arm==0:powers[key].append(pt)
    else:
     base=np.memmap(B/'matched'/f'arm0_seed{seed}'/'matched_states.bin',dtype='<f8',mode='r',shape=(500000,36));assert np.array_equal(t,base[:,1+j])
    powers[f'f{j}']=f
    for label,start in [('member',8),('mean',15),('forecast_member',22),('forecast_mean',29)]:
     x=a[:,start+j];f,p=spec(x,j);powers.setdefault(f'{arm}_{label}_{j}',[]).append(p)
     vals=metric(x,t);err=spectral_error(p,pt,f)
     record=dict(arm=arm,seed=seed,variable=V[j],sample=label,rmse=vals[0],bias=vals[1],sd_ratio=vals[2],correlation=vals[3],bias2=vals[4],amplitude_mismatch=vals[5],correlation_mismatch=vals[6],spectral_L1_relative=err[0],displayed_power_ratio=err[1],mean_absolute_log10_spectral_ratio=err[2])
     if label in ['mean','member']:record['native_rmse']=float(np.sqrt(m[col,5 if label=='mean' else 9]))
     records.append(record)
   print('matched',arm,seed,flush=True)
 np.savez_compressed(O/'matched_spectra.npz',**{k:np.array(v) for k,v in powers.items()})
 (O/'matched_results.json').write_text(json.dumps({'window_TU':[100000,150000],'PSD_dt':.1,'native_dt':.01,'all_seeds':list(range(10)),'metric_labels':['rmse','bias','sd_ratio','correlation','bias2','amplitude_mismatch','correlation_mismatch'],'records':records,'native':native,'checkpoint_match':True,'truth_match':True,'replay_verified':True},indent=2))
if __name__=='__main__':
 if len(sys.argv)<2 or sys.argv[1]=='feedback':feedback()
 if len(sys.argv)<2 or sys.argv[1]=='matched':matched()
