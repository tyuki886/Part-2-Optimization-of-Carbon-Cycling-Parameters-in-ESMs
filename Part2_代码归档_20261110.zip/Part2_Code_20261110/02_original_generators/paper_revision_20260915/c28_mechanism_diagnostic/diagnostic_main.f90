program diagnostic_main
    use RKmethod
    implicit none
    integer(kind=8) :: i, spin_up=1000000_8, step_total=20000000_8
    integer :: n,mask
    real(kind=dp) :: x(18)=0.0_dp, row(7)
    character(len=20) :: arg
    call get_command_argument(1,arg);read(arg,*) n
    x(2)=1.0_dp
    open(11,file='states_01.bin',access='stream',form='unformatted',status='new')
    if(n==7.or.record_dense) open(12,file='states_dense.bin',access='stream',form='unformatted',status='new')
    do i=1,spin_up
       call adv_true_state(x,i,n)
    end do
    do i=1,step_total
       call adv_true_state(x,i,n)
       if(mod(i,10_8)==0.or.((n==7.or.record_dense).and.i>=1000000_8.and.i<=2000000_8)) then
          row=[x(1),x(2),x(4),x(5),x(7),x(8),x(1)*(x(7)-x(4))]
          if(mod(i,10_8)==0)write(11)row
          if((n==7.or.record_dense).and.i>=1000000_8.and.i<=2000000_8)write(12)row
       end if
    end do
    close(11)
    if(n==7.or.record_dense)close(12)
    print *,'DONE',n,step_total,x(4),x(5),x(7)
end program
