program identity_check
 use RKmethod
 implicit none
 real(dp) :: x7(18)=0.0_dp,x10(18)=0.0_dp,diffspin=0.0_dp,diffpost=0.0_dp
 integer(kind=8) :: i
 x7(2)=1.0_dp;x10(2)=1.0_dp
 do i=1,1000000_8
  call adv_true_state(x7,i,7);call adv_true_state(x10,i,10)
  diffspin=max(diffspin,maxval(abs(x7(1:7)-x10(1:7))))
 end do
 do i=1,20000000_8
  call adv_true_state(x7,i,7);call adv_true_state(x10,i,10)
  diffpost=max(diffpost,maxval(abs(x7(1:7)-x10(1:7))))
 end do
 open(21,file='identity_check.json',status='new')
 write(21,'(A,ES24.16,A,ES24.16,A)') '{"all_seven_max_diff_spinup":',diffspin,',"all_seven_max_diff_postspinup":',diffpost,',"postspinup_steps":20000000}'
 close(21)
 if(diffpost/=0.0_dp.or.diffspin/=0.0_dp)stop 1
end program
