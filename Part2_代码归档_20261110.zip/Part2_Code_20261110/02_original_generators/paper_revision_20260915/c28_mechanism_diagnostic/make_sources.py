from pathlib import Path
import json
B=Path(__file__).resolve().parent
r=json.loads((B/'diagnostic_results.json').read_text());z=json.loads((B/'mean_split_results.json').read_text());identity=json.loads((B/'identity_check.json').read_text())
base=r['block_means']['M3']['TL_band']
items=[]
items.append({'id':'tl-mechanism','title':'TL低频下降：c24通道与均值分离','queries':[{'id':'c24-interventions','source':{'label':'c28=1受控反馈实验','files':['diagnostic_results.json','mean_split_results.json'],'filters':['TL频带为0–0.5 Year⁻¹','c28真值为1'],'caveats':['20个连续窗口不是20个独立seed，未提供独立初值置信区间。','原窗口方程贡献分解不是20窗口平均贡献。']},'reportingPeriod':'起转后0–200000 TU的20个10000-TU窗口','rows':[{'配置':name,'低频功率':v['TL_band'],'相对无c24变化百分比':100*(v['TL_band']/base-1)} for name,v in [('无c24',r['block_means']['M3']),('完整c24',r['block_means']['M7']),('仅均值',z['mean_c24']['means']),('仅固定参考异常',z['anomaly_c24']['means'])]],'columns':['配置','低频功率','相对无c24变化百分比']} ]})
items.append({'id':'eta-robustness','title':'η低频差异的窗口敏感性','queries':[{'id':'eta-windows','source':{'label':'η时间窗口检查','files':['diagnostic_results.json'],'filters':['η低频带为0–0.2 Decade⁻¹'],'caveats':['首频点随分段长度变化，不能把不同分段的首点视为同一个物理周期。']},'reportingPeriod':'原窗口为起转后10000–20000 TU；20窗口覆盖0–200000 TU','rows':[{'指标':key,'原窗口比值':r['summary'][key]['first_original_window_ratio'],'20窗口均值之比':r['summary'][key]['twenty_window_mean_ratio']} for key in ['eta_first_bin','eta_band']],'columns':['指标','原窗口比值','20窗口均值之比']} ]})
items.append({'id':'feedback-identity','title':'关闭反馈后的七变量逐步等价性','queries':[{'id':'identity','source':{'label':'全部七个状态逐积分步对照','files':['identity_check.json'],'caveats':['本次验证不追溯性证明旧实验的初始化与数据来源正确。']},'reportingPeriod':'10000 TU起转及后续200000 TU，dt=0.01 TU','rows':[identity],'columns':['all_seven_max_diff_spinup','all_seven_max_diff_postspinup','postspinup_steps']} ]})
(B/'sources_receipt.json').write_text(json.dumps({'schemaVersion':1,'items':items},ensure_ascii=False),encoding='utf-8')
