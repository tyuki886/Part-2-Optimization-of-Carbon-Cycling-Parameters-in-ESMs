from pathlib import Path
import json,numpy as np
from scipy.signal import welch
B=Path(__file__).resolve().parent
trap=getattr(np,'trapezoid',np.trapz)
def band(y):
 f,p=welch(y,fs=10,nperseg=5120,noverlap=2560,window='hann',detrend='constant',scaling='density');f=f*10;p=p/10
 m=(f>0)&(f<.5)
 return float(trap(np.r_[p[0],p[m],np.interp(.5,f,p)],np.r_[0,f[m],.5]))
r=json.loads((B/'diagnostic_results.json').read_text());out={}
for tag in ['mean_c24','anomaly_c24']:
 a=np.memmap(B/tag/'states_01.bin',dtype='<f8',mode='r',shape=(2000000,7));assert np.isfinite(a).all()
 rows=[{'TL_band':band(a[i*100000:(i+1)*100000,4]),'TL_mean':float(a[i*100000:(i+1)*100000,4].mean()),'TL_variance':float(a[i*100000:(i+1)*100000,4].var())} for i in range(20)]
 means={k:float(np.mean([x[k] for x in rows])) for k in rows[0]}
 out[tag]={'blocks':rows,'means':means,'intervention':json.loads((B/tag/'intervention.json').read_text()),'first_window_TL_band':band(a[99999:200000,4]),'ratio_to_M3_no_c24':means['TL_band']/r['block_means']['M3']['TL_band']}
(B/'mean_split_results.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:{n:v[n] for n in ['means','intervention','ratio_to_M3_no_c24']} for k,v in out.items()},indent=2))
