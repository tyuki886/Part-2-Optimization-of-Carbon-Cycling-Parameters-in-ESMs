"""Spectrum robustness, factorial interventions and closed co-spectral accounting."""
from pathlib import Path
import numpy as np,json,math,hashlib
from scipy.signal import welch,get_window
B=Path(__file__).resolve().parent
tags=['seven']+['M'+str(i) for i in range(8)]
data={k:np.memmap(B/k/'states_01.bin',dtype='<f8',mode='r',shape=(2000000,7)) for k in tags}
trap=getattr(np,'trapezoid',np.trapz)
def integral(f,p,lo,hi):
 m=(f>lo)&(f<hi);ff=np.r_[lo,f[m],hi];pp=np.r_[np.interp(lo,f,p),p[m],np.interp(hi,f,p)];return float(trap(pp,ff))
def spectrum(y,dt,seg,mult):
 f,p=welch(y,fs=1/dt,window='hann',nperseg=round(seg/dt),noverlap=round(seg/dt)//2,detrend='constant',scaling='density')
 return f*mult,p/mult
def metrics(a,dt=.1):
 out={}
 for v,j,seg,mult,hi in [('TL',4,512,10,.5),('eta',3,1024,100,.2)]:
  f,p=spectrum(a[:,j],dt,seg,mult);out[v+'_band']=integral(f,p,0,hi);out[v+'_first_bin']=float(p[1]);out[v+'_variance']=float(np.var(a[:,j]));out[v+'_mean']=float(np.mean(a[:,j]))
 return out
blocks={k:[metrics(a[i*100000:(i+1)*100000]) for i in range(20)] for k,a in data.items()}
first={k:metrics(a[99999:200000]) for k,a in data.items()}
means={k:{m:float(np.mean([r[m] for r in rr])) for m in rr[0]} for k,rr in blocks.items()}
summary={}
for metric in means['seven']:
 b=np.array([r[metric] for r in blocks['seven']]);n=np.array([r[metric] for r in blocks['M7']]);ratio=n/b
 summary[metric]={'first_original_window_ratio':first['M7'][metric]/first['seven'][metric],'twenty_window_mean_ratio':means['M7'][metric]/means['seven'][metric],'window_ratio_min':float(ratio.min()),'window_ratio_max':float(ratio.max()),'windows_10_above_7':int((n>b).sum()),'window_count':20}
equivalence={'all_feedback_off_vs_seven_water_max_abs':float(np.max(np.abs(data['M0'][:,:5]-data['seven'][:,:5]))),'water_equal':bool(np.array_equal(data['M0'][:,:5],data['seven'][:,:5]))}
# Reproduce archived corrected-run samples exactly before relying on budgets.
old=B.parent/'c28_corrected_comparison'
for tag,m in [('seven',7),('M7',10)]:
 for name,cols in [(f'wTL_{m}var.txt',[2,4]),('eta_7var.txt' if m==7 else 'etaCatm_10var.txt',[3] if m==7 else [3,5])]:
  p=old/('run'+str(m))/name
  if not p.exists():continue
  z=np.loadtxt(p);idx=np.round(z[:,0]*10).astype(int)-1
  pred=np.asarray(data[tag][idx[:,None],np.array(cols)[None,:]])
  equivalence[tag+'_'+name+'_maxabs']=float(np.max(np.abs(pred-z[:,1:])))
# Bit 0: c16 -> x2; bit 1: c17 -> w; bit 2: c24 -> TL.
shapley={}
for period,vals in [('first_window',first),('twenty_window_mean',means)]:
 shapley[period]={}
 for metric in ['TL_band','eta_band','eta_first_bin']:
  contrib=[]
  for bit in range(3):
   s=0.
   for mask in range(8):
    if mask&(1<<bit):continue
    n=bin(mask).count('1');weight=math.factorial(n)*math.factorial(2-n)/6
    s+=weight*(vals['M'+str(mask|(1<<bit))][metric]-vals['M'+str(mask)][metric])
   contrib.append(s)
  delta=vals['M7'][metric]-vals['M0'][metric];assert abs(sum(contrib)-delta)<1e-9
  shapley[period][metric]={'all_on_minus_off':delta,'by_channel':dict(zip(['c16_to_x2','c17_to_w','c24_to_TL'],contrib)),'baseline_all_off':vals['M0'][metric]}
# Segment and sampling sensitivity. All comparisons use the same original time window.
sensitivity=[];spectra={}
for tag in ['seven','M7']:
 dense=np.memmap(B/tag/'states_dense.bin',dtype='<f8',mode='r',shape=(1000001,7))
 assert np.array_equal(dense[::10],data[tag][99999:200000])
 for v,j,mult,hi,segs in [('TL',4,10,.5,[256,512,1024,2048]),('eta',3,100,.2,[512,1024,2048,4096])]:
  for seg in segs:
   for stride in [1,10,100]:
    dt=.01*stride;f,p=spectrum(dense[::stride,j],dt,seg,mult)
    sensitivity.append({'model':tag,'variable':v,'segment_TU':seg,'sample_TU':dt,'band_power':integral(f,p,0,hi),'first_bin':float(p[1]),'first_frequency':float(f[1])})
    if seg==(512 if v=='TL' else 1024) and stride==1:
     mask=f<=1.5;spectra[tag+'_'+v]={'frequency':f[mask].tolist(),'PSD':p[mask].tolist()}
# First-window accounting with model input terms and exact Hann derivative correction.
# This is a frequency-domain balance, not an independent proof of causal attribution.
budgets={}
for tag in ['seven','M7']:
 dense=np.memmap(B/tag/'states_dense.bin',dtype='<f8',mode='r',shape=(1000001,7));dt=.01;t=10000+np.arange(len(dense))*dt
 budgets[tag]={}
 for v,j,M,lam,seg,mult,hi in [('TL',4,2,.4,512,10,.5),('eta',3,100,1,1024,100,.2)]:
  if v=='TL':
   terms=np.column_stack([.5*dense[:,1],-.05*dense[:,6],.025*dense[:,5] if tag=='M7' else np.zeros(len(dense)),np.cos(2*np.pi*t/10)])
   names=['atmosphere_c12x2','land_ocean_exchange','carbon_direct_c24','seasonal'];const=5.
  else:
   terms=np.column_stack([dense[:,2],.001*dense[:,2]*dense[:,3]]);names=['linear_w_driver','nonlinear_w_eta'];const=0.
  n=round(seg/dt);w=get_window('hann',n);wp=(np.pi/(n*dt))*np.sin(2*np.pi*np.arange(n)/n);f=np.fft.rfftfreq(n,dt);den=lam+2j*np.pi*f*M
  scale=np.full(len(f),2*dt/np.sum(w*w));scale[[0,-1]]*=.5
  parts=[];totals=[];closures=[]
  for start in range(0,len(dense)-n+1,n//2):
   y=np.asarray(dense[start:start+n,j]);q=terms[start:start+n];yc=y-y.mean();qm=q.mean(0)
   Y=np.fft.rfft(w*yc);Z=np.fft.rfft(w[:,None]*(q-qm),axis=0)/den[:,None]
   e=float(qm.sum()+const-lam*y.mean())
   corr=(M*np.fft.rfft(wp*yc)+e*np.fft.rfft(w))/den
   resid=Y-Z.sum(1)-corr
   values=np.column_stack([Z,corr,resid]);parts.append(np.real(Y.conj()[:,None]*values)*scale[:,None]);totals.append(np.abs(Y)**2*scale);closures.append(np.abs(resid)**2*scale)
  pp=np.mean(parts,axis=0)/mult;total=np.mean(totals,axis=0)/mult;ff=f*mult
  result={name:integral(ff,pp[:,i],0,hi) for i,name in enumerate(names+['window_and_mean_correction','numerical_residual'])}
  measured=integral(ff,total,0,hi);assert abs(sum(result.values())-measured)<1e-8
  result['total_band_power']=measured;result['residual_power_fraction']=integral(ff,np.mean(closures,axis=0)/mult,0,hi)/measured
  budgets[tag][v]=result
result={'definition':{'TL_band_year_inv':[0,.5],'eta_band_decade_inv':[0,.2],'first_window_postspinup_TU':[10000,20000],'blocks':'20 consecutive nonoverlapping 10000-TU windows; not independent seeds','channels':'c16->x2, c17->w, c24->TL; all c28=1','factorial':'all 8 on/off combinations; Shapley allocation includes interactions, not a unique physical partition'},'equivalence':equivalence,'summary':summary,'first_window':first,'block_means':means,'blocks':blocks,'shapley':shapley,'sampling_segment_sensitivity':sensitivity,'first_window_budgets':budgets,'spectra':spectra}
(B/'diagnostic_results.json').write_text(json.dumps(result,indent=2))
print('EQUIVALENCE',equivalence,flush=True)
print('SUMMARY',summary,flush=True)
print('BUDGETS',budgets,flush=True)
