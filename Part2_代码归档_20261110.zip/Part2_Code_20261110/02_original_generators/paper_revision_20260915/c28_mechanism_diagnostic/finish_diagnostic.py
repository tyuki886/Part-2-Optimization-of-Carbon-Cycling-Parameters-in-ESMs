"""Deliver reviewed scientific PNGs and inspectable quantitative notes."""
from pathlib import Path
import json,shutil,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
B=Path(__file__).resolve().parent
D=Path(r'D:\SRDP\论文大作！\MCPE26.0\最终成图\c28谱差异原因诊断_20260915');D.mkdir(exist_ok=True,parents=True)
r=json.loads((B/'diagnostic_results.json').read_text());z=json.loads((B/'mean_split_results.json').read_text())
plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'axes.titlesize':12})
def save(fig,name):
 fig.savefig(D/name,dpi=300,bbox_inches='tight',pad_inches=.1);plt.close(fig)
 with Image.open(D/name) as im:im.thumbnail((1500,1000));im.convert('RGB').save(B/name.replace('.png','_preview.jpg'))
fig,ax=plt.subplots(1,2,figsize=(12.6,4.7),gridspec_kw={'width_ratios':[1.15,1]})
labels=['Seven-variable','No c24\n(c16 + c17)','Full 10VCC','Mean-only\nc24','Anomaly-only\nc24']
vals=[r['block_means']['seven']['TL_band'],r['block_means']['M3']['TL_band'],r['block_means']['M7']['TL_band'],z['mean_c24']['means']['TL_band'],z['anomaly_c24']['means']['TL_band']]
blocks=[r['blocks']['seven'],r['blocks']['M3'],r['blocks']['M7'],z['mean_c24']['blocks'],z['anomaly_c24']['blocks']]
colors=['#426E98','#868686','#B53B50','#CC8131','#3E8074']
ax[0].bar(range(5),vals,color=colors,width=.65,zorder=2)
for i,rr in enumerate(blocks):
 ax[0].scatter(i+np.linspace(-.19,.19,20),[a['TL_band'] for a in rr],s=12,color='#383838',alpha=.5,zorder=3)
 ax[0].text(i,.08,f'{vals[i]:.3f}',ha='center',va='bottom',color='white',fontweight='bold')
ax[0].set_xticks(range(5),labels,fontsize=9)
ax[0].set(ylabel='Integrated PSD (0-0.5 Year$^{-1}$)',title='(a) TL: 20-window mean and individual windows',ylim=(0,None));ax[0].grid(axis='y',alpha=.2,zorder=0)
a=r['first_window_budgets']['seven']['TL'];b=r['first_window_budgets']['M7']['TL'];loss=a['total_band_power']-b['total_band_power']
keys=['atmosphere_c12x2','land_ocean_exchange','carbon_direct_c24','seasonal','window_and_mean_correction','numerical_residual']
names=['Atmospheric driving','Land-ocean exchange','Direct carbon term','Seasonal forcing','Window correction','Numerical residual']
percent=[100*(a[k]-b[k])/loss for k in keys]
ax[1].barh(names,percent,color=['#426E98']*3+['#868686']*3);ax[1].invert_yaxis();ax[1].axvline(0,color='black',lw=.7)
for i,v in enumerate(percent):ax[1].text(max(v,0)+1,i,f'{v:.1f}%',va='center',fontsize=10)
ax[1].set(xlabel='Contribution to the original-window power reduction (%)',title='(b) TL: original-window spectral accounting',xlim=(-5,90));ax[1].grid(axis='x',alpha=.2)
fig.tight_layout(w_pad=2);save(fig,'TL_low_frequency_mechanism.png')
fig,ax=plt.subplots(1,2,figsize=(12,4.2))
for aa,key,title in [(ax[0],'eta_first_bin','(a) Eta: first nonzero spectral bin'),(ax[1],'eta_band','(b) Eta: integrated low-frequency power')]:
 p=np.array([v[key] for v in r['blocks']['M7']]);q=np.array([v[key] for v in r['blocks']['seven']]);ratio=p/q
 aa.plot(np.arange(1,21),ratio,'o-',color='#426E98',lw=1.1,ms=4,label='Individual 10000-TU windows');aa.axhline(1,color='black',ls='--',lw=1,label='Equal power')
 aa.axhline(p.mean()/q.mean(),color='#B53B50',lw=1,label='Ratio of window means')
 aa.set(title=title,xlabel='Consecutive 10000-TU window',ylabel='10VCC / seven-variable',xlim=(.6,20.4),ylim=(0,2.15));aa.set_xticks([1,5,10,15,20]);aa.grid(alpha=.2)
fig.legend(*ax[0].get_legend_handles_labels(),loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,1.03),fontsize=10)
fig.tight_layout(rect=(0,0,1,.93));save(fig,'eta_peak_window_robustness.png')
notes=['# c28=1后的η与TL功率差异：定量诊断', '',
'## 核心结论', '',
'1. 本次所有碳反馈关闭后，独立作业25742进一步核查全部七个水循环变量：起转100万步及随后2000万积分步中，每一步的最大差值均为0。',
'2. η原窗口最低非零谱点的18.5%增高不具有跨窗口稳定性。20个10000-TU窗口的该谱点平均值反而低3.53%；低频带积分功率平均只高1.02%，20个窗口中正好10个较高、10个较低。不足以认定新增碳循环造成稳健的η低频增强或共振。',
'3. TL低频功率降低更稳健。0–0.5 Year⁻¹低频带在原窗口降低16.43%，20窗口平均降低9.09%，18/20窗口降低。c24通道是主要控制通道；其他反馈并非完全无影响。',
'4. c24的均值/异常分离支持：主要作用来自平均碳驱动改变陆面及非线性耦合系统的平均态/波动状态，而非碳异常直接吸收功率。不能称该正向驱动项本身是阻尼项，也不能称方差是守恒能量。', '',
'## 1. 模型、时间与对照', '',
'作业25740完成9组：七变量与3个碳反馈通道开关的8种组合；作业25741完成2组c24均值/异常分离。全部采用c28=1、原AWI修正版RK4、dt=0.01 TU、各自从原初值起转10000 TU、随后运行200000 TU。没有修改正式CDA/MCPE实验。', '',
'三个反馈开关是c16 Catm→x2、Sm c17 Catm→w、Slm c24 Catm→TL。关闭碳反馈时，碳变量仍继续积分，但没有反向影响水循环。开关在起转和后续积分均保持对应设置。', '',
'保存x1、x2、w、η、TL、Catm及x1(TL−w)，每0.1 TU输出；两个基线的原谱窗口另外每0.01 TU输出。新基线与上一轮c28=1轨迹的重合采样差别不超过5.33×10⁻¹⁵，属于旧文本输出的舍入精度。', '',
'原谱窗口为起转后[10000,20000] TU，即从初始积分计[20000,30000] TU。稳健性检查使用起转后(0,200000] TU的20个相邻、互不重叠10000-TU窗口。它们不是20个独立seed，不把窗口比例当正式显著性检验。', '',
'TL低频带预先定义为0–0.5 Year⁻¹（排除2年以下变化）；η低频带为0–0.2 Decade⁻¹（50年以上）。谱均去均值；Hann、50%重叠；TL分段512 TU，η分段1024 TU。积分采用PSD，不把最大峰值与带积分功率混同。', '',
'## 2. 全部反馈关闭：退化关系核查', '',
'M0与七变量200万保存时刻的x1、x2、w、η、TL最大绝对差=0；这直接验证本次代码与初始化下的退化关系。旧关闭反馈实验是否使用了不同初始化或不同基线，仍应独立查其原执行记录，不能因为这次通过就追溯性认证所有旧实验。', '',
'## 3. η：主要是有限窗口/谱估计的非稳健表现', '',
'原窗口第一非零频点比值=1.18514，而20窗口均值比值=0.96473。各窗口该比值约0.495–1.987，仅9/20窗口高于七变量。低频带积分功率原窗口比值=1.30006，20窗口均值比值=1.01017，窗口比值约0.562–1.773。', '',
'η分段1024 TU时，第一个非零频点为0.09765625 Decade⁻¹。改变分段后首频点也改变，因此不能把不同分段的“首点高度”当同一个物理周期比较。原窗口低频带积分比值在分段512、1024、2048、4096 TU时分别约1.161、1.300、1.093、1.072。最长段只有少量Welch子段，估计不确定性更大。', '',
'每0.01、0.1、1 TU采样的η结果非常接近，支持不是保存点过少造成此次18.5%首点差异。TL低频带每0.01与0.1 TU采样也几乎一致；1 TU采样有小幅差异，但不改变降低方向。', '',
'η原窗口方程收支主要由线性w驱动贡献：七变量0.06205、新模型0.08577；wη项为0.001239、0.001629。该结果解释这一窗口功率从何传入，不证明跨窗口存在持续增强。', '',
'## 4. TL：通道开关定位c24', '',
'下表为20窗口低频带积分功率均值，各配置保持其他设置相同。', '',
'| 配置 | TL低频功率 | 相对七变量 |', '|---|---:|---:|']
for name,tag in [('七变量','seven'),('全部碳反馈关闭','M0'),('仅c16→x2','M1'),('仅c17→w','M2'),('c16+c17，关闭c24','M3'),('仅c24→TL','M4'),('完整十变量','M7')]:
 v=r['block_means'][tag]['TL_band'];notes.append(f'| {name} | {v:.6f} | {(v/r["block_means"]["seven"]["TL_band"]-1)*100:+.2f}% |')
notes+=['', '无论另外两条通道怎样组合，打开c24后TL低频功率都降低：四种背景分别下降11.51%、11.90%、9.48%、10.12%。这比仅比较七/十变量更直接地定位了c24通道。', '',
'全8配置的Shapley分配（将交互效应按所有入场顺序分摊）给出TL低频净变化−0.26749：c24通道−0.31910、c16通道+0.00906、c17通道+0.04255。此分配是指定干预集合上的统计归因，不是唯一的能量收支分割。', '',
'## 5. c24均值与波动分离', '',
'以完整十变量起转后20万TU的Catm均值5.720128作为固定参考。保持c16、c17动态，分别将TL的碳项替换为Slm c24×5.720128、或Slm c24×(Catm−5.720128)。后者是相对于固定参考的异常项，不强制该干预分支自身的均值严格为零。', '',
'固定均值对应额外陆面方程驱动0.143003，是原Slm=5的2.86%；没有改变陆面显式线性阻尼Old=0.4或热容量Olm=2。', '',
'| c24配置（c16、c17均保留） | TL低频功率 | 相对无c24 | TL平均值 |','|---|---:|---:|---:|']
base=r['block_means']['M3']['TL_band']
for label,m in [('无c24',r['block_means']['M3']),('完整c24',r['block_means']['M7']),('仅固定均值',z['mean_c24']['means']),('仅固定参考异常',z['anomaly_c24']['means'])]:
 notes.append(f'| {label} | {m["TL_band"]:.6f} | {(m["TL_band"]/base-1)*100:+.2f}% | {m["TL_mean"]:.5f} |')
notes+=['', '仅均值即重现完整c24低频下降幅度的大约83%，但两种非线性干预不可简单相加，也不把剩余约17%全部归给某个单独过程。仅异常不再造成可比的下降，支持平均态改变是主要环节。', '',
'## 6. 原图窗口TL方程频率收支', '',
'对Olm TL′+Old TL = c12 x2 − c15 x1(TL−w)+Slm c24 Catm+季节项+Slm进行Hann窗频率分析。每个强迫项经过(Old+iωOlm)⁻¹变换后，与TL做交叉谱实部，得到对TL谱的可加贡献；显式加入Hann窗导数与去均值校正。保留残差，不强制把误差分配给物理项。', '',
'这是沿实际耦合轨迹的频率收支，不是把强迫项视为独立外源的因果分解。贡献可以为负，表示相位关系造成的负交叉谱贡献，不表示负的自功率谱。', '',
'原窗口0–0.5 Year⁻¹积分功率从2.930699降为2.449192，总下降0.481507。', '',
'| 项目 | 对下降量的贡献 | 占下降量 |','|---|---:|---:|']
for name,k in zip(names,keys):notes.append(f'| {name} | {a[k]-b[k]:+.8f} | {100*(a[k]-b[k])/loss:+.3f}% |')
notes+=['', '去掉窗校正后的数值残差功率占信号功率约2×10⁻¹¹，份额表闭合。这说明该窗口的下降主要表现为大气驱动贡献变小（72.5%）和陆海交换贡献改变（23.3%）；碳项的直接负贡献只有3.55%。这些比例仅适用于原窗口，不冒充20窗口平均比例。', '',
'结合c24均值干预，支持的机制链是：碳平均浓度→陆面平均驱动上移→非线性陆面—大气—海洋耦合运行状态改变→大气驱动及陆海交换的低频贡献改变→TL低频方差下降。不能简写为“新增碳项加大阻尼”或“碳循环吸收守恒能量”。', '',
'## 限制与交付', '',
'这些是当前参数、初值和积分实现下的受控模型实验，不是现实气候验证；20个连续窗口不是独立初值集合，尚无独立seed置信区间。η的结果不支持稳定共振增强。TL通道及均值机制有受控干预支持，但细分到每条非线性反馈回路还需额外针对性实验。', '',
'PNG：TL_low_frequency_mechanism.png、eta_peak_window_robustness.png。前者左图灰点为20窗口值，柱为均值；右图为原窗口频率收支。后者分别展示η首频点与低频带积分功率的逐窗口比值，红线为均值之比而不是比值均值。无额外PDF。', '',
'完整原始二进制输出及源码保留在新超算 `/public/home/hou/wyh/MCPE26.0/paper_revision_20260915/c28_mechanism_diagnostic`。本地脚本与回执位于 `'+str(B)+'`。未修改原论文或正式CDA/MCPE数据。']
identity=json.loads((B/'identity_check.json').read_text())
assert identity['all_seven_max_diff_postspinup']==0 and identity['all_seven_max_diff_spinup']==0
notes+=['','补充逐步核验：作业25742比较同一全关闭反馈模块的n=7与n=10，在起转及随后2000万积分步中逐步比较全部七个水循环状态，最大差为0；详见identity_check.json。']
(D/'定量原因诊断.md').write_text('\n'.join(notes)+'\n',encoding='utf-8')
for name in ['diagnostic_results.json','mean_split_results.json','completion.json','mean_split_completion.json','identity_check.json']:shutil.copy2(B/name,D/name)
print('DELIVERED',D)
