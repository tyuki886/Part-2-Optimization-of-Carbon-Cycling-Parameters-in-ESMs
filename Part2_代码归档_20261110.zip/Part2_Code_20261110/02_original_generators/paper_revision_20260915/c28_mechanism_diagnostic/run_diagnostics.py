"""Controlled diagnostic runs, c28=1; no changes to scientific production files."""
from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,re,time,sys
import numpy as np
B=Path(__file__).resolve().parent
source=(B/'RKmethod_reference.f90').read_text()
assert 'c28=1.0_dp' in source
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def checked(cmd,d,trace):
 p=subprocess.run(['/usr/bin/strace','-f','-e','trace=process','-o',str(trace)]+cmd,cwd=d,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 t=trace.read_text();exits=[int(x) for x in re.findall(r'^\d+\s+\+\+\+ exited with (\d+) \+\+\+',t,re.M)]
 good=p.returncode==0 or (p.returncode==255 and 'WEXITSTATUS(s) == 0' in t and 'ECHILD' in t and exits[-1:]==[255] and all(x==0 for x in exits[:-1]))
 if not good:raise RuntimeError((cmd,p.returncode,exits,p.stdout.decode(errors='replace')))
 return p.stdout.decode(errors='replace')
def run(tag):
 start=time.time();d=B/tag;d.mkdir(exist_ok=False)
 mask=int(tag[1:]) if tag.startswith('M') else (7 if tag in ['mean_c24','anomaly_c24'] else 0)
 s=source
 if not mask&1:s=s.replace('if(n>=9) ds(2)=ds(2)+c16*s(8)','! diagnostic: carbon feedback to x2 disabled')
 if not mask&2:s=s.replace('sm*(1.0+c17*s(8))','sm')
 if not mask&4:s=s.replace('slm*(1.0+c24*s(8))','slm')
 if tag in ['mean_c24','anomaly_c24']:
  reference=float(np.memmap(B/'M7/states_01.bin',dtype='<f8',mode='r',shape=(2000000,7))[:,5].mean())
  val=format(reference,'.17g')+'_dp'
  s=s.replace('slm*(1.0+c24*s(8))','slm*(1.0+c24*'+(val if tag=='mean_c24' else '(s(8)-'+val+')')+')')
  (d/'intervention.json').write_text(json.dumps({'type':tag,'reference_Catm':reference,'reference_source':'M7 full 0.1-TU trajectory, postspinup (0,200000] TU','other_feedbacks':'c16 and c17 remain dynamic'},indent=2))
 s=s.replace('contains','logical, parameter :: record_dense='+('.true.' if tag=='M7' else '.false.')+'\ncontains',1)
 (d/'RKmethod.f90').write_text(s)
 checked(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90',str(B/'diagnostic_main.f90'),'-o','diagnostic'],d,d/'compile.trace')
 log=checked([str(d/'diagnostic'),'7' if tag=='seven' else '10'],d,d/'run.trace');(d/'run.log').write_text(log)
 a=np.memmap(d/'states_01.bin',dtype='<f8',mode='r',shape=(2000000,7));assert np.isfinite(a).all()
 if tag in ['M7','seven']:
  z=np.memmap(d/'states_dense.bin',dtype='<f8',mode='r',shape=(1000001,7));assert np.isfinite(z).all()
 receipt={'tag':tag,'mask':mask,'c28':1,'postspinup_TU':200000,'spinup_TU':10000,'dt_TU':.01,'saved_TU':.1,'source_sha256':sha(d/'RKmethod.f90'),'binary_sha256':sha(d/'diagnostic'),'seconds':time.time()-start,'data':{p.name:sha(p) for p in d.glob('*.bin')}}
 (d/'receipt.json').write_text(json.dumps(receipt,indent=2));print('DONE',tag,round(time.time()-start,1),flush=True);return receipt
extra='--mean-split' in sys.argv
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:r=list(pool.map(run,['mean_c24','anomaly_c24'] if extra else ['seven']+['M'+str(i) for i in range(8)]))
(B/('mean_split_completion.json' if extra else 'completion.json')).write_text(json.dumps(r,indent=2))
if not extra:subprocess.run(['/public/home/hou/miniconda3/envs/yuki/bin/python',str(B/'analyze_diagnostics.py')],cwd=B,check=True)
