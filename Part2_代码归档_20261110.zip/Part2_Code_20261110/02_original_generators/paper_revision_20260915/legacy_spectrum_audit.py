from pathlib import Path
import ast,json
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image
B=Path(__file__).parent;D=B.parent/'awi_power_combined';O=B/'figures'
font_manager.fontManager.addfont(str(B.parent/'saturation_remeasure_20260911/times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10})
tree=ast.parse((D/'plot_psd_v10v7.py').read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='CFG');cfg=eval(compile(ast.Expression(node.value),'<cfg>','eval'))
records=[];spectra={}
for v,c in cfg.items():
 for mod in ['7','10']:
  if 'f'+mod not in c:continue
  d=np.loadtxt(D/c['f'+mod]);a=d[(d[:,0]>=c['trange'][0])&(d[:,0]<=c['trange'][1])];dt=np.median(np.diff(a[:,0]));assert np.allclose(np.diff(a[:,0]),1/c['fs'])
  y=a[:,c['col']];ns=len(y) if c['nperseg']=='full' else c['nperseg'];win='boxcar' if c['nperseg']=='full' else 'hann'
  f,p=signal.welch(y,fs=c['fs'],nperseg=ns,window=win,scaling='density');f*=c['mult'];p/=c['mult'];take=f<=1.5;f=f[take];p=p[take];k=np.argmax(p);spectra[v,mod]=(f,p)
  records.append(dict(variable=v,model=mod,range_TU=c['trange'],dt_TU=float(dt),points=len(y),segment_TU=float(ns*dt),variance=float(y.var()),mean=float(y.mean()),peak_frequency=float(f[k]),frequency_resolution=float(f[1]-f[0]),peak_period=float(1/f[k]) if f[k]>0 else None,unit=c['unit'],boundary_peak=bool(k==1 or k==len(f)-1),arbitrary_legacy_factor=c['scale']))
fig=plt.figure(figsize=(13.2,9.3));left=fig.add_gridspec(4,1,left=.075,right=.48,top=.89,bottom=.075,hspace=.62);right=fig.add_gridspec(3,1,left=.59,right=.985,top=.89,bottom=.075,hspace=.5)
for v,letter,gs in [('x2','a',left[0]),('w','c',left[1]),('eta','e',left[2]),('TL','g',left[3]),('Catm','b',right[0]),('Cocean','d',right[1]),('ALK','f',right[2])]:
 ax=fig.add_subplot(gs);c=cfg[v]
 for mod,color,label in [('7','#24578D','Seven-variable'),('10','#B52D43','10VCC')]:
  if (v,mod) in spectra:ax.plot(*spectra[v,mod],color=color,lw=1.2,label=label)
 ax.set_title(f'({letter}) '+('η' if v=='eta' else v),pad=3);ax.set_xlabel('Frequency ('+c['unit']+'$^{-1}$)');ax.set_ylabel('PSD');ax.set_xlim(0,1.5);ax.set_ylim(bottom=0);ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,3));ax.grid(alpha=.2)
fig.suptitle('Power spectra of the seven-variable and 10VCC models',fontsize=16,y=.98)
from matplotlib.lines import Line2D
fig.legend(handles=[Line2D([],[],color='#24578D',label='Seven-variable'),Line2D([],[],color='#B52D43',label='10VCC')],loc='upper center',bbox_to_anchor=(.5,.955),ncol=2,frameon=False)
fig.savefig(O/'model_comparison_PSD_correct_units.png',dpi=300,bbox_inches='tight');plt.close(fig)
with Image.open(O/'model_comparison_PSD_correct_units.png') as im:im.thumbnail((1500,1100));im.convert('RGB').save(O/'model_comparison_PSD_correct_units_preview.jpg')
(B/'legacy_spectral_audit.json').write_text(json.dumps(records,indent=2))
for v in ['x2','w','eta','TL']:
 a=[r for r in records if r['variable']==v];print(v,'variance10/7',a[1]['variance']/a[0]['variance'])
