from pathlib import Path
import sys,json,hashlib
import numpy as np
from scipy.optimize import brentq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import font_manager
from PIL import Image
B=Path(__file__).resolve().parent;P=B.parent/'sync_four_groups_20260913';S=B.parent/'saturation_remeasure_20260911';A=B.parent/'alk_top10_saturation_20260912'
O=B/'figures';O.mkdir(exist_ok=True)
sys.path.insert(0,str(S));import fit_display_windows as fit
font_manager.fontManager.addfont(str(S/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'mathtext.fontset':'stix','path.simplify':False,'agg.path.chunksize':10000})
def save(fig,name):
 fig.savefig(O/name,dpi=300,bbox_inches='tight',pad_inches=.12,facecolor='white');plt.close(fig)
 with Image.open(O/name) as im:im.thumbnail((1500,1000));im.convert('RGB').save(O/name.replace('.png','_preview.jpg'),quality=86)
def saturation():
 old=json.loads((S/'final_pair_divisors2000/formal_times.json').read_text())['results']
 fs=json.loads((S/'display_window_fit/fit_results.json').read_text())['results']
 alk=json.loads((A/'results.json').read_text())['results']
 rows=[];raw={};carbon=fit.CARBON+['c27','c17']
 for side,params in enumerate([fit.WATER,carbon]):
  for name in params:
   folder=A/'results'/str(['c27','c17'].index(name)+1) if name in ['c27','c17'] else S/'results'/str((fit.WATER+fit.CARBON).index(name)+1)
   path=folder/f'saturation_{name}.bin';h=hashlib.sha256(path.read_bytes()).hexdigest()
   assert h==json.loads((folder/'audit.json').read_text())['binary_sha256']
   arr=np.fromfile(path,dtype='<f8').reshape(-1,9)
   for j in (range(3) if side==0 else range(3,6)):
    v,T,col=fit.VARS[j],fit.LIMITS[j],fit.COLS[j];d=arr[:round(T/.1)];t=d[:,0];y=d[:,col];raw[name,v]=(t,y)
    if name in ['c27','c17']:
     if v=='ALK':r=dict(next(r for r in alk if r['parameter']==name));f=r['fit']
     else:
      candidates=[fit.fit_one(t,y,m) for m in ['Logistic','Gompertz']];f=min(candidates,key=lambda f:f['SSE'])
      ts=None if not f['success'] or fit.evaluate(T,f)<.95*f['A'] else float(brentq(lambda z:float(fit.evaluate(z,f))-.95*f['A'],0,T))
      r={'parameter':name,'variable':v,'measured_TU':ts,'marker_y':None if ts is None else float(fit.evaluate(ts,f)), 'measurement_basis':'95% of fitted asymptote','fit_caveats':(['parameter_bound_hit'] if f['parameter_bounds_hit'] else [])+(['poor_identifiability'] if f['jacobian_condition']>1e8 else []),'fit':f}
    else:
     r=dict(next(r for r in old if r['parameter']==name and r['variable']==v));f=fit.selected_fit(next(r for r in fs if r['parameter']==name and r['variable']==v));r['fit']=f
    r['source_sha256']=h;r['window_TU']=T;rows.append(r)
    print('SAT',name,v,r['measured_TU'],flush=True)
 (B/'saturation_22_results.json').write_text(json.dumps({'parameters':fit.WATER+carbon,'results':rows},indent=2))
 for fitted in [False,True]:
  fig,axes=plt.subplots(3,6,figsize=(24,11))
  for side,params in enumerate([fit.WATER,carbon]):
   groups=[params[:3],params[3:6],params[6:]] if side==0 else [params[:4],params[4:8],params[8:]]
   for row,group in enumerate(groups):
    for col in range(3):
     j=side*3+col;v=fit.VARS[j];ax=axes[row,j]
     for k,name in enumerate(group):
      r=next(r for r in rows if r['parameter']==name and r['variable']==v);t,y=raw[name,v];ts=r['measured_TU'];color=['#15558C','#CE6600','#227432','#AA2439'][k]
      label=name+(f' ({ts:.1f} TU)' if ts is not None else '')
      line,=ax.plot(np.r_[0,t],np.r_[0,y],color=color,lw=.85,label=label)
      np.testing.assert_array_equal(line.get_ydata()[1:],y)
      if fitted:ax.plot(t,fit.evaluate(t,r['fit']),color=color,ls='--',lw=1.5)
      if ts is not None:ax.plot(ts,r['marker_y'],'o',ms=4,color=color,mec='black',mew=.4)
     ymax=max(max(float(np.max(raw[name,v][1])),float(np.max(fit.evaluate(raw[name,v][0],next(r for r in rows if r['parameter']==name and r['variable']==v)['fit'])))) for name in group)
     ax.set(xlim=(0,fit.LIMITS[j]),ylim=(0,1.07*ymax),xlabel='Time (TU)',ylabel=v,title=f'({chr(97+row*6+j)}) {v}')
     ax.legend(loc='best',fontsize=8.5,framealpha=.9);ax.grid(alpha=.2,ls=':')
  fig.suptitle('Parameter sensitivity responses and saturation-time estimates',fontsize=17,y=.99)
  fig.tight_layout(rect=(0,0,1,.96));save(fig,'saturation_22_with_fit.png' if fitted else 'saturation_22_without_fit.png')
 assert len(rows)==66
 cfg=json.loads((P/'config.json').read_text());lines=['# 22参数响应时间与生产更新周期','', '响应取点是拟合诊断，生产周期为实际设置；二者不等同。未达到窗口阈值记“未达到”，未配置通道记“—”。原始样点0.1 TU，绘图不平滑。','', '|参数|x2取点|w取点|TL取点|Catm取点|Cocean取点|ALK取点|现行周期TU|','|---|---:|---:|---:|---:|---:|---:|---|']
 for name in fit.WATER+carbon:
  vals=[]
  for v in fit.VARS:
   r=next((r for r in rows if r['parameter']==name and r['variable']==v),None)
   vals.append('—' if r is None else ('未达到' if r['measured_TU'] is None else f"{r['measured_TU']:.3f}"))
  lines.append('|'+name+'|'+'|'.join(vals)+'|'+str(cfg['cycles_TU'].get(name,{}))+'|')
 lines+=['','x1/x3沿用x2周期。c27=1500 TU为用户指定值，不属于2000约数。Cocean和ALK仅在观测时刻更新，实际间隔为名义周期向上对齐观测间隔。拟合质量、模型选择与原始来源详见saturation_22_results.json。','']
 (B/'22参数响应时间与实际周期.md').write_text('\n'.join(lines),encoding='utf-8')
def taylor():
 z=np.load(P/'evidence_123_20260913/moments_arrays.npz');keep=[0,1,2,4,5,6,7,8,9];ns=[12,15,18,21,24,27,30];records=[]
 colors=['#111111','#0072B2','#E69F00','#009E73','#CC79A7','#D55E00','#56B4E9','#8C564B'];markers=['h','o','s','^','D','v','P','X']
 for obs,v,cv in [(5,4,1),(7,5,2),(8,6,3)]:
  keys=[f'M22_v{cv}']+[f'M{n}_v{v}' for n in ns];labels=[f'CDA{obs}']+[f'M{n}' for n in ns]
  fig,axes=plt.subplots(1,3,figsize=(15,5.4),subplot_kw={'projection':'polar'})
  for j,(ax,var,col) in enumerate(zip(axes,['Catm','Cocean','ALK'],[7,8,9])):
   stats=[]
   for key,label in zip(keys,labels):
    a=z[key][keep,col,:];vx,vt,cov=a[:,2:5].mean(0);r=cov/np.sqrt(vx*vt);sd=np.sqrt(vx/vt)
    assert r>=0,'Negative correlation cannot be plotted faithfully on requested quadrant'
    stats.append((r,sd));records.append({'obs':obs,'variable':var,'method':label,'correlation':float(r),'SD_ratio':float(sd),'centered_RMSE_normalized':float(np.sqrt((vx+vt-2*cov)/vt))})
   rmax=np.ceil(max(1.4,1.12*max(s[1] for s in stats))*5)/5
   theta=np.linspace(0,np.pi/2,181);tt,rr=np.meshgrid(theta,np.linspace(0,rmax,180));dist=np.sqrt(1+rr**2-2*rr*np.cos(tt))
   cs=ax.contour(tt,rr,dist,levels=np.arange(.25,rmax+1,.25),colors='#BBBBBB',linewidths=.65);ax.clabel(cs,fontsize=8,fmt='%g')
   ax.plot(theta,np.ones_like(theta),color='#777777',ls='--',lw=.8)
   for (r,sd),color,marker in zip(stats,colors,markers):ax.plot(np.arccos(r),sd,marker=marker,color=color,ms=8,ls='',zorder=5)
   ax.plot(0,1,'k*',ms=12,clip_on=False,zorder=8)
   ticks=np.array([1,.99,.95,.9,.8,.6,.4,.2,0]);ax.set_thetagrids(np.degrees(np.arccos(ticks)),[str(x).rstrip('0').rstrip('.') if x!=0 else '0' for x in ticks],fontsize=9)
   ax.set_thetamin(0);ax.set_thetamax(90);ax.set_ylim(0,rmax);ax.set_rlabel_position(0);ax.grid(alpha=.25)
   ax.set_title(f'({chr(97+j)}) {var}',pad=20);ax.set_xlabel('Normalized standard deviation',labelpad=15)
  fig.suptitle(f'Taylor diagrams of state estimates ({obs}obs)',fontsize=17,y=.99)
  handles=[Line2D([],[],marker=m,color=c,ls='',label=l) for m,c,l in zip(markers,colors,labels)]+[Line2D([],[],marker='*',color='black',ls='',label='Truth')]
  fig.legend(handles=handles,ncol=9,loc='upper center',bbox_to_anchor=(.5,.92),frameon=False,fontsize=11)
  fig.subplots_adjust(top=.66,bottom=.12,left=.065,right=.98,wspace=.28)
  save(fig,f'Taylor_{obs}obs_quarter_summary.png')
 (B/'taylor_audit.json').write_text(json.dumps({'retained_seeds':keep,'excluded_seeds':[3],'post_hoc':True,'window_TU':[90000,100000],'pooling':'within-seed centered moments','records':records},indent=2))
if __name__=='__main__':
 if len(sys.argv)==1 or sys.argv[1]=='taylor':taylor()
 if len(sys.argv)==1 or sys.argv[1]=='saturation':saturation()
