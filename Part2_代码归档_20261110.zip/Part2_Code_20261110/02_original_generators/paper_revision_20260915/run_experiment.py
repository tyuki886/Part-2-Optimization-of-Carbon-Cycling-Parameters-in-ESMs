from pathlib import Path
import os,sys,subprocess,json,time,hashlib,re
import array,math
B=Path(__file__).resolve().parent
task=int(sys.argv[1]);start=time.time()
if task<70:
 seed=task%10;arm=task//10;d=B/'feedback'/f'arm{arm}_seed{seed}';d.mkdir(parents=True,exist_ok=False)
 command=[str(B/'feedback_factorial'),str(seed),str(arm)]
 env=os.environ.copy()
else:
 q=task-70;seed=q%10;arm=q//10
 assert arm in range(4)
 d=B/'matched'/f'arm{arm}_seed{seed}';d.mkdir(parents=True,exist_ok=False)
 env={k:v for k,v in os.environ.items() if not k.startswith('MCPE_')}
 env.update(MCPE_SCHEME='22' if arm==0 else '30',MCPE_VARIANT='3' if arm==0 else '6',MCPE_SEED=str(seed),
  MCPE_ENTRY_ARM='sync',MCPE_FREQ='1,4,20',MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS='15000000',
  MCPE_EVAL='9000000',MCPE_EVAL_END='10000000',MCPE_SAVE_PARAM_MEAN='1',MCPE_PSD='1',
  MCPE_PSD_START='10000000',PAPER_ARM=str(max(0,arm-1)),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 command=[str(B/'exp21_matched')]
with (d/'run.log').open('w') as f:
 p=subprocess.run(['/usr/bin/strace','-f','-s','240','-e','trace=process','-o',str(d/'run.trace')]+command,cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
trace=(d/'run.trace').read_text();exits=[int(x) for x in re.findall(r'^\d+\s+\+\+\+ exited with (\d+) \+\+\+',trace,re.M)]
if p.returncode:
 assert p.returncode==255 and exits==[0,255] and 'ECHILD' in trace and 'WEXITSTATUS(s) == 0' in trace,(task,p.returncode,exits)
else:assert exits and all(x==0 for x in exits)
if task>=70:
 assert (d/'matched_states.bin').stat().st_size==500000*36*8
 a=(d/'audit_scalars.txt').read_text().splitlines()[0].split();assert float(a[-1])==0
 with (d/'matched_states.bin').open('rb') as stream:
  while True:
   chunk=stream.read(8*1000000)
   if not chunk:break
   values=array.array('d');values.frombytes(chunk);assert all(map(math.isfinite,values))
 ref=B.parent/'sync_four_groups_20260913/runs/M30_v6'/f'seed{seed}' if arm else B.parent/'three_channel_figures_psd150k_20260913/runs/CDA8'/f'seed{seed}'
 def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
 assert (d/'initial_parameters.txt').read_bytes()==(ref/'initial_parameters.txt').read_bytes()
 if arm<2:assert sha(d/'spectral_member1.bin')==sha(ref/'spectral_member1.bin'),'Replay differs'
 (d/'DONE').write_text('Validated finite trajectories and reference replay where applicable.\n')
(d/'receipt.json').write_text(json.dumps({'task':task,'seed':seed,'arm':arm,'seconds':time.time()-start,'returncode':p.returncode},indent=2))
print('DONE',task,time.time()-start,flush=True)
