program feedback_factorial
 use RKmethod
 implicit none
 real(dp)::x(10),checkpoint(10),means(10),variance(10),delta(10),frozen(10),seven(10)
 integer::seed,arm,u,j
 integer(kind=8)::it,n
 character(30)::arg
 call get_command_argument(1,arg);read(arg,*)seed
 call get_command_argument(2,arg);read(arg,*)arm
 call reset_all_46();rollback_events=0_8
 x=0._dp;x(2)=1._dp+.001_dp*seed;call update_sea_ice(x)
 do it=1,1000000_8
  call adv_true_state(x,it,10)
 enddo
 checkpoint=x
 open(newunit=u,file='checkpoint.bin',access='stream',form='unformatted',status='new');write(u)x;close(u)
 call reset_all_46();paper_fixed_carbon=-1._dp
 select case(arm)
 case(0)
 case(1);c16=0._dp;c17=0._dp;c24=0._dp
 case(2);c16=0._dp
 case(3);c17=0._dp
 case(4);c24=0._dp
 case(5)
  open(newunit=u,file='../../fixed_carbon_means.txt',status='old')
  read(u,*)frozen;close(u);paper_fixed_carbon=frozen(seed+1)
 case(6);c16=0._dp;c17=0._dp;c24=0._dp
 case default;error stop 'bad arm'
 end select
 open(newunit=u,file='states.bin',access='stream',form='unformatted',status='new')
 means=0._dp;variance=0._dp;n=0_8
 do it=1000001_8,15000000_8
  if(arm==6)then
   call adv_true_state(x,it,7)
  else
   call adv_true_state(x,it,10)
  endif
  if(rollback_events/=0_8)error stop 'rollback'
  if(.not.all(abs(x)<=huge(1._dp)))error stop 'nonfinite'
  if(it>5000000_8)then
   n=n+1;delta=x-means;means=means+delta/real(n,dp);variance=variance+delta*(x-means)
   if(mod(it,10_8)==0_8)write(u)x
  endif
 enddo
 close(u)
 open(newunit=u,file='moments.txt',status='new')
 write(u,*)n,rollback_events
 write(u,'(10ES26.17E3)')means
 write(u,'(10ES26.17E3)')variance/real(n,dp)
 close(u)
 open(newunit=u,file='DONE',status='new');write(u,*)seed,arm;close(u)
end program
