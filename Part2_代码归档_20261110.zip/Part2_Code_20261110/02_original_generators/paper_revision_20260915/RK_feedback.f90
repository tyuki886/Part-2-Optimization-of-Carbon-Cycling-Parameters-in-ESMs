module RKmethod
    implicit none
    integer(kind=8) :: rollback_events=0_8
    integer, parameter :: dp = selected_real_kind(15, 307)
    real(dp) :: paper_fixed_carbon=-1._dp
    real(kind=dp) :: PI = 3.141592653589793_dp

    ! 固定常量
    real(kind=dp) :: om = 10.0_dp, gamma_deep = 100.0_dp
    real(kind=dp) :: c3 = 0.01_dp, c4 = 0.01_dp, c5 = 1.0_dp, c7 = 0.1_dp
    real(kind=dp) :: c8 = 0.1_dp, c9 = 0.1_dp, c10 = 10.0_dp
    real(kind=dp) :: c11 = 0.01_dp, c13 = 0.01_dp, c14 = 0.1_dp
    real(kind=dp) :: c16 = 0.1_dp, c17 = 0.001_dp, c19 = 0.01_dp
    real(kind=dp) :: c23 = 0.01_dp, c24 = 0.005_dp, c27 = 0.5_dp, c30 = 1.2_dp
    real(kind=dp) :: sls_cnst = 1.0_dp
    real(kind=dp) :: od_cnst = 1.0_dp
    real(kind=dp) :: lambda = 0.3_dp, olm = 2.0_dp

    ! 可调参数。MCPE17.0 将 c20 纳入估计，并用可识别的组合参数
    ! k_cal = c26 * rrain 代替分别估计 c26 与 rrain。
    real(kind=dp) :: sigma = 9.95_dp, kappa = 28.0_dp, b = 2.666666666666667_dp
    real(kind=dp) :: c1 = 0.1_dp, spd = 10.0_dp, ss = 1.0_dp, sm = 10.0_dp
    real(kind=dp) :: c2 = 1.0_dp, slm = 5.0_dp, old_val = 0.4_dp
    real(kind=dp) :: c15 = 0.05_dp, c12 = 0.5_dp, E_rate = 0.8_dp
    real(kind=dp) :: c18 = 0.1_dp, c21 = 0.001_dp, c29 = 1.0_dp
    real(kind=dp) :: c22 = 0.01_dp, c28 = 1.0_dp, rrain = 0.009_dp  ! C-34: c28 基准定稿 1.0（Bcal 沉积触发阈值）
    real(kind=dp) :: c26 = 0.00009_dp, c25 = 0.0018_dp, c6 = 0.001_dp
    real(kind=dp) :: c20 = 0.01_dp

contains
    subroutine reset_to_standard()
        sigma = 9.95_dp; kappa = 28.0_dp; b = 2.666666666666667_dp; c1 = 0.1_dp
        spd = 10.0_dp; ss = 1.0_dp; sm = 10.0_dp; c2 = 1.0_dp
        slm = 5.0_dp; old_val = 0.4_dp; c15 = 0.05_dp; c12 = 0.5_dp
        E_rate = 0.8_dp; c18 = 0.1_dp; c21 = 0.001_dp; c29 = 1.0_dp; c20 = 0.01_dp
        c22 = 0.01_dp; c28 = 1.0_dp; rrain = 0.009_dp; c26 = 0.00009_dp; c25 = 0.0018_dp  ! C-34: c28=1.0 定稿
        c6 = 0.001_dp; od_cnst = 1.0_dp
    end subroutine

    subroutine adv_true_state(x, it, n_var)
        integer(kind=8), intent(in) :: it
        integer, intent(in) :: n_var
        real(kind=dp), intent(inout) :: x(10)
        real(kind=dp) :: dt=0.01_dp, k1(10), k2(10), k3(10), k4(10), tmp(10), old_x(10)
        old_x = x
        k1 = derivs(x, it, n_var)
        tmp = x + 0.5_dp*dt*k1
        k2 = derivs(tmp, it, n_var)
        tmp = x + 0.5_dp*dt*k2
        k3 = derivs(tmp, it, n_var)
        tmp = x + dt*k3
        k4 = derivs(tmp, it, n_var)
        x = x + (dt/6.0_dp)*(k1 + 2.0_dp*k2 + 2.0_dp*k3 + k4)
        if (any(abs(x(1:7)) > 1.0e3_dp) .or. any(abs(x(8:10)) > 1.0e4_dp)) then
            rollback_events=rollback_events+1_8
            x = old_x
        end if
        call update_sea_ice(x)
    end subroutine

    subroutine update_sea_ice(s)
        real(kind=dp), intent(inout) :: s(10)
        real(kind=dp) :: h_val
        h_val = c8*s(2)**2 + c9*s(4)**2 + c10*s(6)**2
        if (h_val < 10.0_dp) then
            s(6) = 1.0_dp
        elseif (h_val > 50.0_dp) then
            s(6) = 0.0_dp
        else
            s(6) = 0.5_dp * (exp(-(h_val - 10.0_dp)/80.0_dp) + exp(-1.0_dp/max(50.0_dp - h_val, 1.0e-10_dp)))
        end if
    end subroutine

    function derivs(s, it, n) result(ds)
        real(kind=dp), intent(in) :: s(10)
        integer(kind=8), intent(in) :: it
        integer, intent(in) :: n
        real(kind=dp) :: ds(10), pCO2_oc, Bcal
        real(kind=dp) :: safe_spd, safe_ss, safe_sm, safe_slm
        safe_spd = max(spd, 0.1_dp); safe_ss  = max(ss,  0.01_dp)
        safe_sm  = max(sm,  0.01_dp); safe_slm = max(slm, 0.01_dp)
        ds = 0.0_dp
        if (n >= 9) then
            pCO2_oc = max(c29*s(9) - c30*s(10), 0.0_dp)
            Bcal = c26 * s(9) * max(s(10) - c27*s(9) + c28, 0.0_dp)
        else
            pCO2_oc = 0.0_dp; Bcal = 0.0_dp
        end if
        ds(1) = sigma*(s(2)-s(1)) - (lambda + c11*s(7)) + c14*(s(7)-s(4))
        ds(2) = -s(1)*s(3) + (1.0_dp + c1*s(4))*kappa*s(1) - s(2) + c13*kappa*s(7)*s(1)
        if (n >= 9) ds(2) = ds(2) + c16*merge(paper_fixed_carbon,s(8),paper_fixed_carbon>=0._dp)
        ds(3) = s(1)*s(2) - b*s(3)
        ds(4) = (c2*s(2) + c3*s(5) + c4*s(4)*s(5) - od_cnst*s(4) - c7*s(6) + c15*s(1)*(s(7)-s(4)))
        if (n < 9) then
            ds(4) = (ds(4) + safe_sm + safe_ss*cos(2.0_dp*PI*it*0.01_dp/safe_spd))/om
        else
            ds(4) = (ds(4) + safe_sm*(1.0_dp + c17*merge(paper_fixed_carbon,s(8),paper_fixed_carbon>=0._dp)) + safe_ss*cos(2.0_dp*PI*it*0.01_dp/safe_spd))/om
        end if
        ds(5) = (c5*s(4) + c6*s(4)*s(5) - od_cnst*s(5))/gamma_deep
        ds(6) = 0.0_dp
        ds(7) = (c12*s(2) - old_val*s(7) - c15*s(1)*(s(7)-s(4)))
        if (n < 9) then
            ds(7) = (ds(7) + safe_slm + sls_cnst*cos(2.0_dp*PI*it*0.01_dp/safe_spd))/olm
        else
            ds(7) = (ds(7) + safe_slm*(1.0_dp + c24*merge(paper_fixed_carbon,s(8),paper_fixed_carbon>=0._dp)) + sls_cnst*cos(2.0_dp*PI*it*0.01_dp/safe_spd))/olm
        end if
        if (n >= 9) then
            ds(8) = E_rate - c18*(1.0_dp - c19*s(4))*(s(8)-pCO2_oc) - c20*s(8)*s(7) - c21*s(1)*(s(7)-s(4))
            ds(9) = c18*(1.0_dp - c19*s(4))*(s(8)-pCO2_oc) - c22*(1.0_dp - c23*s(4))*s(5) - Bcal
            if (n == 10) ds(10) = c25 - 2.0_dp*Bcal
        end if
    end function

    subroutine obs_increment(ens_obs, ens_size, obs, obs_var, obs_inc)
        integer, intent(in) :: ens_size
        real(kind=dp), intent(in) :: ens_obs(ens_size), obs, obs_var
        real(kind=dp), intent(out) :: obs_inc(ens_size)
        real(kind=dp) :: a, cov, mean_o, new_cov, new_mean
        integer :: ie
        mean_o = sum(ens_obs)/dble(ens_size)
        cov = 0.0_dp
        do ie=1,ens_size
            cov = cov + (ens_obs(ie)-mean_o)**2
        end do
        cov = cov/dble(ens_size)
        if (cov >= 1.0e-14_dp) then
            new_cov = (cov*obs_var)/(cov+obs_var)
            new_mean = (obs_var*mean_o + cov*obs)/(cov+obs_var)
            a = sqrt(new_cov/cov)
            do ie=1,ens_size
                obs_inc(ie) = a*(ens_obs(ie)-mean_o) + new_mean - ens_obs(ie)
            end do
        else
            obs_inc = 0.0_dp
        end if
    end subroutine

    subroutine update_from_obs_inc(ens_obs, obs_inc, target_ens, ens_size, cov_factor)
        integer, intent(in) :: ens_size
        real(kind=dp), intent(in) :: ens_obs(ens_size), obs_inc(ens_size)
        real(kind=dp), intent(inout) :: target_ens(ens_size)
        real(kind=dp), intent(in) :: cov_factor
        real(kind=dp) :: mean_t, mean_o, cv_o, cv
        integer :: ie
        mean_t = sum(target_ens)/dble(ens_size)
        mean_o = sum(ens_obs)/dble(ens_size)
        cv_o = 0.0_dp; cv = 0.0_dp
        do ie=1,ens_size
            cv_o = cv_o + (ens_obs(ie)-mean_o)**2
            cv   = cv   + (target_ens(ie)-mean_t)*(ens_obs(ie)-mean_o)
        end do
        cv_o = cv_o/dble(ens_size); cv = cv/dble(ens_size)
        if (cv_o > 1.0e-14_dp) then
            do ie=1,ens_size
                target_ens(ie) = target_ens(ie) + cov_factor*(cv/cv_o)*obs_inc(ie)
            end do
        end if
    end subroutine

    subroutine inflate_parameter(p_ens, idx, n_ens, init_std)
        integer, intent(in) :: idx, n_ens
        real(kind=dp), intent(inout) :: p_ens(:,:)
        real(kind=dp), intent(in) :: init_std
        real(kind=dp) :: mean_p, std_p, alpha, a0=1.0e-3_dp, max_alpha=2.0_dp
        integer :: m
        mean_p = sum(p_ens(idx,:))/dble(n_ens)
        std_p = sqrt(sum((p_ens(idx,:)-mean_p)**2)/dble(n_ens))
        if (std_p < init_std*0.5_dp) then
            alpha = 1.0_dp + a0*init_std/max(std_p, 1.0e-12_dp)
            alpha = min(alpha, max_alpha)
            do m=1,n_ens
                p_ens(idx,m) = mean_p + alpha*(p_ens(idx,m)-mean_p)
            end do
        end if
    end subroutine

    subroutine clamp_params(p_ens, n_ens, np)
        integer, intent(in) :: n_ens, np
        real(kind=dp), intent(inout) :: p_ens(np, n_ens)
        real(kind=dp) :: lower(21), upper(21)
        integer :: i, j
        lower = [0.1_dp, 1.0_dp, 0.1_dp, 0.001_dp, 0.1_dp, 0.01_dp, 0.1_dp, 0.1_dp, &
                 0.1_dp, 0.01_dp, 0.001_dp, 0.01_dp, 0.01_dp, 0.001_dp, 1.0e-5_dp, &
                 0.1_dp, 0.001_dp, 0.1_dp, 1.0e-5_dp, 1.0e-5_dp, 1.0e-6_dp]
        upper = [50.0_dp, 200.0_dp, 20.0_dp, 1.0_dp, 200.0_dp, 50.0_dp, 200.0_dp, 10.0_dp, &
                 50.0_dp, 10.0_dp, 1.0_dp, 5.0_dp, 10.0_dp, 1.0_dp, 0.1_dp, &
                 10.0_dp, 1.0_dp, 200.0_dp, 0.1_dp, 0.1_dp, 0.1_dp]
        if (np == 21) then
            do j=1,n_ens
                do i=1,21
                    if (p_ens(i,j) < lower(i)) p_ens(i,j) = lower(i)
                    if (p_ens(i,j) > upper(i)) p_ens(i,j) = upper(i)
                end do
            end do
        end if
    end subroutine

    subroutine reset_all_46()
        sigma = 9.95_dp; kappa = 28.0_dp; b = 2.666666666666667_dp; c1 = 0.1_dp
        spd = 10.0_dp; ss = 1.0_dp; sm = 10.0_dp; c2 = 1.0_dp
        slm = 5.0_dp; old_val = 0.4_dp; c15 = 0.05_dp; c12 = 0.5_dp
        E_rate = 0.8_dp; c18 = 0.1_dp; c21 = 0.001_dp; c29 = 1.0_dp; c20 = 0.01_dp
        c22 = 0.01_dp; c28 = 1.0_dp; rrain = 0.009_dp; c26 = 0.00009_dp; c25 = 0.0018_dp  ! C-34: c28=1.0 定稿
        c6 = 0.001_dp; od_cnst = 1.0_dp
        om = 10.0_dp; gamma_deep = 100.0_dp; c3 = 0.01_dp; c4 = 0.01_dp; c5 = 1.0_dp
        c7 = 0.1_dp; c8 = 0.1_dp; c9 = 0.1_dp; c10 = 10.0_dp
        c11 = 0.01_dp; c13 = 0.01_dp; c14 = 0.1_dp
        c16 = 0.1_dp; c17 = 0.001_dp; c19 = 0.01_dp
        c23 = 0.01_dp; c24 = 0.005_dp; c27 = 0.5_dp; c30 = 1.2_dp
        sls_cnst = 1.0_dp; lambda = 0.3_dp; olm = 2.0_dp
    end subroutine

    real(kind=dp) function random_gaussian()
        real(kind=dp) :: u1, u2, r
        do
            call random_number(u1); call random_number(u2)
            u1 = 2.0_dp * u1 - 1.0_dp; u2 = 2.0_dp * u2 - 1.0_dp
            r = u1*u1 + u2*u2
            if (r > 0.0_dp .and. r < 1.0_dp) exit
        end do
        random_gaussian = u1 * sqrt(-2.0_dp * log(r) / r)
    end function
end module RKmethod
