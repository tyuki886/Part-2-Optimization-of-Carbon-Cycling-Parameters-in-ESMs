"""Create isolated, instrumented Fortran experiments from immutable production sources."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent;P=B.parent/'sync_four_groups_20260913'
def replace_once(s,a,b):
    assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
s=(P/'exp21_new.f90').read_text(encoding='utf-8')
s=replace_once(s,'        real(kind=dp)::param_std(45),param_mean_now(45)', '''        real(kind=dp)::param_std(45),param_mean_now(45)
        integer::paper_arm,paper_status,ju
        character(24)::paper_env
        real(dp)::forecast_mean(10),forecast_member(10),mom(10,12),incsum(10,2),incsquare(10,2)
        real(dp)::pm(10),em(10),e1(10),incm(10),inc1(10)
        integer(kind=8)::paper_count
        paper_arm=0
        call get_environment_variable('PAPER_ARM',paper_env,status=paper_status)
        if(paper_status==0)read(paper_env,*)paper_arm
        mom=0._dp;incsum=0._dp;incsquare=0._dp;paper_count=0_8''')
# Fortran declarations must precede any executable statement.
s=s.replace('        paper_arm=0\n        call get_environment_variable', '        logical::trc,traj,btraj,ex; character(8)::tv; integer::st4\n        paper_arm=0\n        call get_environment_variable',1)
s=s.replace('        logical::trc,traj,btraj,ex; character(8)::tv; integer::st4\n        trc=', '        trc=',1)
s=replace_once(s,'        do i=1,run_steps\n', '''        open(96,file='matched_states.bin',access='stream',form='unformatted',status='replace')
        do i=1,run_steps
            if(i==10000001_8)then
                open(95,file='branch_checkpoint.bin',access='stream',form='unformatted',status='replace')
                write(95)xt,xe,pe
                close(95)
                if(paper_arm==2)pe=spread(pt,2,en)
            endif
''')
s=replace_once(s,'            if(no2>0.and.i>=sa.and.i<ae2)then', '''            forecast_mean=sum(xe,dim=2)/real(en,dp);forecast_member=xe(:,1)
            if(no2>0.and.i>=sa.and.i<ae2)then''')
s=replace_once(s,'                    if(ne2>0)then; do k=1,ne2; row2=er(k)', '                    if(ne2>0.and.(paper_arm==0.or.i<=10000000_8))then; do k=1,ne2; row2=er(k)')
s=replace_once(s,'            if(i>rss.and.i<=ree)then', '''            if(i>10000000_8)then
                pm=sum(xe,dim=2)/real(en,dp);em=pm-xt;e1=xe(:,1)-xt
                incm=pm-forecast_mean;inc1=xe(:,1)-forecast_member
                paper_count=paper_count+1_8
                mom(:,1)=mom(:,1)+pm;mom(:,2)=mom(:,2)+xt;mom(:,3)=mom(:,3)+pm**2
                mom(:,4)=mom(:,4)+xt**2;mom(:,5)=mom(:,5)+pm*xt;mom(:,6)=mom(:,6)+em**2
                mom(:,7)=mom(:,7)+xe(:,1);mom(:,8)=mom(:,8)+xe(:,1)**2
                mom(:,9)=mom(:,9)+xe(:,1)*xt;mom(:,10)=mom(:,10)+e1**2
                mom(:,11)=mom(:,11)+forecast_mean**2;mom(:,12)=mom(:,12)+forecast_member**2
                incsum(:,1)=incsum(:,1)+incm;incsum(:,2)=incsum(:,2)+inc1
                incsquare(:,1)=incsquare(:,1)+incm**2;incsquare(:,2)=incsquare(:,2)+inc1**2
                if(mod(i,10_8)==0_8)write(96)real(i,dp)/100._dp,xt(psd_idx),xe(psd_idx,1),pm(psd_idx), &
                    forecast_member(psd_idx),forecast_mean(psd_idx)
            endif
            if(i>rss.and.i<=ree)then''')
s=replace_once(s,'        if(save_mean)close(94)', '''        close(96)
        open(95,file='matched_moments.txt',status='replace')
        write(95,*)paper_count
        do ju=1,10
            write(95,'(16ES26.17E3)')mom(ju,:)/real(max(1_8,paper_count),dp), &
                incsum(ju,:)/real(max(1_8,paper_count),dp),incsquare(ju,:)/real(max(1_8,paper_count),dp)
        enddo
        close(95)
        if(save_mean)close(94)''')
(B/'exp21_matched.f90').write_text(s,encoding='utf-8')
for n in ['MCPE42_new.f90','RKmethod.f90','config.json']:(B/n).write_bytes((P/n).read_bytes())
f=(B/'RKmethod.f90').read_text(encoding='utf-8')
f=replace_once(f,'    integer, parameter :: dp = selected_real_kind(15, 307)','    integer, parameter :: dp = selected_real_kind(15, 307)\n    real(dp) :: paper_fixed_carbon=-1._dp')
# Use max sentinel without changing any non-feedback carbon equation.
f=f.replace('c16*s(8)','c16*merge(paper_fixed_carbon,s(8),paper_fixed_carbon>=0._dp)')
f=f.replace('c17*s(8)','c17*merge(paper_fixed_carbon,s(8),paper_fixed_carbon>=0._dp)')
f=f.replace('c24*s(8)','c24*merge(paper_fixed_carbon,s(8),paper_fixed_carbon>=0._dp)')
(B/'RK_feedback.f90').write_text(f,encoding='utf-8')
audit=json.loads((B.parent/'carbon_feedback_off_20260914/analysis/audit.json').read_text())
(B/'fixed_carbon_means.txt').write_text('\n'.join(str(audit['block_statistics'][str(i)]['full']['50000-150000']['mean'][7]) for i in range(10))+'\n')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in B.glob('*.f90')}
(B/'source_manifest.json').write_text(json.dumps(manifest,indent=2))
print('PREPARED',manifest)
