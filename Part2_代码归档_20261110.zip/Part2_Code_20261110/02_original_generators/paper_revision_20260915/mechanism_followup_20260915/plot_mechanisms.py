from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from PIL import Image
B=Path(__file__).resolve().parent;P=B.parent;A=B/'analysis';O=B/'figures';O.mkdir(exist_ok=True)
font_manager.fontManager.addfont(str(P.parent/'saturation_remeasure_20260911/times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10,'mathtext.fontset':'stix','axes.titlesize':11,'axes.labelsize':10})
colors=['#0072B2','#D55E00','#009E73','#AA4499'];labels=['CDA8','MCPE30 continued','MCPE30 frozen','Truth parameters']
compcolors=['#4C72B0','#DD8452','#8172B3'];complabels=['Squared mean bias','Amplitude mismatch','Correlation mismatch']
rng=np.random.default_rng(20260915);ix=rng.integers(0,10,(19999,10))
def save(fig,name):
 fig.savefig(O/(name+'.png'),dpi=300,bbox_inches='tight',pad_inches=.08)
 plt.close(fig)
 with Image.open(O/(name+'.png')) as im:
  im.thumbnail((1600,1050));im.convert('RGB').save(O/(name+'_preview.jpg'),quality=89)
def style(ax):
 ax.grid(alpha=.17,lw=.6);ax.set_axisbelow(True);ax.tick_params(length=3)
def scalar(a):
 a=np.asarray(a);m=a.mean();lo,hi=np.percentile(a[ix].mean(1),[2.5,97.5]);return m,lo,hi
E=json.loads((A/'error_mechanisms.json').read_text());Z=np.load(A/'error_mechanisms.npz');F=json.loads((A/'feedback_peak_mechanisms.json').read_text());S=np.load(P/'matched_spectra.npz')
def rows(v,a):return [r for r in E['records'] if r['variable']==v and r['arm']==a]

fig,axs=plt.subplots(2,3,figsize=(14,6.5))
for r,v in enumerate(['Cocean','ALK']):
 ax=axs[r,0];time=Z['trace_time_TU'];ax.plot(time,Z[f'0_{v}_trace_truth'],color='black',lw=1.15)
 for a in [0,1]:ax.plot(time,Z[f'{a}_{v}_trace'],color=colors[a],lw=.85,ls='--' if a==0 else '-')
 ax.set_title(f'({chr(97+r*3)}) {v} | Seed 0');ax.set_xlabel('Time (TU)');ax.set_ylabel(v);ax.set_xlim(100000,110000);ax.set_xticks([100000,105000,110000]);ax.ticklabel_format(axis='x',style='plain',useOffset=False);style(ax)
 ax=axs[r,1];bottom=np.zeros(2)
 for key,c,l in zip(['bias2','amplitude_mismatch','correlation_mismatch'],compcolors,complabels):
  vals=np.array([np.mean([q[key] for q in rows(v,a)]) for a in [0,1]])
  ax.bar([0,1],vals,bottom=bottom,width=.55,color=c,label=l);bottom+=vals
 ax.set_xticks([0,1],['CDA8','MCPE30']);ax.set_ylabel('Mean squared error');ax.set_title(f'({chr(98+r*3)}) {v} | Error components');ax.set_ylim(bottom=0);style(ax)
 ax=axs[r,2];f=Z['carbon_frequency_millennium']
 for a in [0,1]:ax.plot(f[1:],Z[f'{a}_{v}_error'].mean(0)[1:],color=colors[a],ls='-' if a else '--',marker='o' if a else 'x',ms=3,lw=1.15)
 ax.set_title(f'({chr(99+r*3)}) {v} | Error spectrum');ax.set_xlabel('Frequency (Millennium$^{-1}$)');ax.set_ylabel('PSD of estimate minus truth');ax.set_xlim(0,1.5);ax.set_ylim(bottom=0);ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,2));style(ax)
fig.suptitle('Why spectral agreement and state-estimation error differ',fontsize=15,y=.995)
handles=[Line2D([],[],color='black',label='Truth')]+[Line2D([],[],color=colors[a],label=labels[a],ls='--' if a==0 else '-') for a in [0,1]]
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.952),ncol=3,frameon=False)
fig.legend(handles=[Patch(color=c,label=l) for c,l in zip(compcolors,complabels)],loc='upper center',bbox_to_anchor=(.5,.91),ncol=3,frameon=False)
fig.subplots_adjust(top=.80,bottom=.1,hspace=.40,wspace=.35);save(fig,'01_error_mechanisms_Cocean_ALK')

fig,axs=plt.subplots(2,3,figsize=(14,6.6))
for r,v in enumerate(['Cocean','ALK']):
 j=5+r;f=S[f'f{j}'];ax=axs[r,0];ax.plot(f,S[f'truth_{j}'].mean(0),color='black',lw=1.3)
 for a in [0,1,2]:ax.plot(f,S[f'{a}_mean_{j}'].mean(0),color=colors[a],lw=1.2,ls=['--','-','-.'][a],marker=['x','o','s'][a],ms=3)
 ax.set_title(f'({chr(97+r*3)}) {v} | State spectra');ax.set_xlabel('Frequency (Millennium$^{-1}$)');ax.set_ylabel('PSD');ax.set_xlim(0,1.5);ax.set_ylim(bottom=0);ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,2));style(ax)
 ax=axs[r,1]
 for a in [0,1,2]:
  m,lo,hi=scalar([q['native_rmse'] for q in rows(v,a)]);ax.bar(a,m,color=colors[a],width=.55);ax.errorbar(a,m,yerr=[[m-lo],[hi-m]],fmt='none',color='black',capsize=3,lw=1)
 ax.set_title(f'({chr(98+r*3)}) {v} | Native-step RMSE');ax.set_xticks([0,1,2],['CDA8','Continued','Frozen']);ax.set_ylabel('Mean RMSE');style(ax)
 ax=axs[r,2];bottom=np.zeros(3)
 for key,c in zip(['bias2','amplitude_mismatch','correlation_mismatch'],compcolors):
  vals=np.array([np.mean([q[key] for q in rows(v,a)]) for a in [0,1,2]]);ax.bar(range(3),vals,bottom=bottom,color=c,width=.55);bottom+=vals
 ax.set_xticks([0,1,2],['CDA8','Continued','Frozen']);ax.set_title(f'({chr(99+r*3)}) {v} | Error components');ax.set_ylabel('Mean squared error');style(ax)
fig.suptitle('Effect of continuing versus freezing parameter estimation',fontsize=15,y=.995)
fig.legend(handles=[Line2D([],[],color='black',label='Truth')]+[Line2D([],[],color=colors[a],label=labels[a],ls=['--','-','-.'][a]) for a in [0,1,2]],loc='upper center',bbox_to_anchor=(.5,.95),ncol=4,frameon=False)
fig.legend(handles=[Patch(color=c,label=l) for c,l in zip(compcolors,complabels)],loc='upper center',bbox_to_anchor=(.5,.905),ncol=3,frameon=False)
fig.subplots_adjust(top=.80,bottom=.09,hspace=.44,wspace=.34);save(fig,'02_parameter_freeze_intervention')

z=np.load(P/'feedback_spectra.npz');ac={0:'#D55E00',1:'#333333',5:'#0072B2'};al={0:'Full carbon feedback',1:'All carbon feedback off',5:'Fixed mean carbon feedback'}
fig,axs=plt.subplots(2,3,figsize=(14,6.8))
for c,(v,j) in enumerate([('w',1),('eta',2),('TL',3)]):
 ax=axs[0,c]
 for a in [0,1,5]:ax.plot(z[f'f{j}'],z[f'{a}_{j}'].mean(0),color=ac[a],lw=1.15,ls={0:'-',1:'--',5:'-.'}[a])
 ax.set_title(f'({chr(97+c)}) '+('η' if v=='eta' else v));ax.set_xlabel('Frequency ('+('Decade' if v=='eta' else 'Year')+'$^{-1}$)');ax.set_ylabel('PSD');ax.set_xlim(0,1.5);ax.set_ylim(bottom=0);ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,2));style(ax)
 ax=axs[1,c];defs=[(v,'peak_height','Peak'),(v,'band_power','Band power')] if v!='TL' else [('TL-low','peak_height','Low peak'),('TL-low','band_power','Low band'),('TL-annual','peak_height','Annual peak'),('TL-annual','band_power','Annual band')]
 for a,offset in [(0,-.10),(5,.10)]:
  for k,(name,metric,label) in enumerate(defs):
   q=next(x['percent_change_vs_off'] for x in F['summary'] if x['arm']==a and x['variable']==name and x['metric']==metric);m=q['mean'];lo,hi=q['ci95'];ax.errorbar(k+offset,m,yerr=[[m-lo],[hi-m]],color=ac[a],marker='o' if a==0 else 's',ms=4,capsize=3,lw=1)
 ax.axhline(0,color='black',lw=.7);ax.set_xticks(range(len(defs)),[d[2] for d in defs],rotation=18 if v=='TL' else 0);ax.set_ylabel('Change relative to feedback off (%)');ax.set_title(f'({chr(100+c)}) '+('η' if v=='eta' else v)+' | Paired comparison');ax.set_ylim(-25,25);style(ax)
fig.suptitle('Spectral peaks: mean carbon forcing versus dynamic feedback',fontsize=15,y=.995)
fig.legend(handles=[Line2D([],[],color=ac[a],label=al[a],ls={0:'-',1:'--',5:'-.'}[a]) for a in [0,1,5]],loc='upper center',bbox_to_anchor=(.5,.95),ncol=3,frameon=False)
fig.subplots_adjust(top=.85,bottom=.105,hspace=.44,wspace=.35);save(fig,'03_carbon_feedback_peak_mechanism')

H=np.load(A/'annual_response.npz');HR=json.loads((A/'annual_response.json').read_text());phase=np.arange(100)/100;theta=2*np.pi*phase
fig,axs=plt.subplots(2,3,figsize=(14,6.9))
ax=axs[0,0]
for a in [0,1,5]:
 cyc=H[f'{a}_baseline_cycle'][:,:,6];cyc=cyc-cyc.mean(1)[:,None];ax.plot(phase,cyc.mean(0),color=ac[a],ls={0:'-',1:'--',5:'-.'}[a],lw=1.2)
ax.set_title('(a) Unperturbed TL seasonal cycle');ax.set_xlabel('Annual phase (year)');ax.set_ylabel('TL anomaly');style(ax)
for col,eps in [(1,.025),(2,.05)]:
 ax=axs[0,col]
 for a in [0,1,5]:
  h=H[f'{a}_{eps}_gain'][:,6];y=h.real[:,None]*np.sin(theta)+h.imag[:,None]*np.cos(theta);m=y.mean(0);ci=np.percentile(y[ix].mean(1),[2.5,97.5],axis=0)
  ax.plot(phase,m,color=ac[a],ls={0:'-',1:'--',5:'-.'}[a],lw=1.2);ax.fill_between(phase,ci[0],ci[1],color=ac[a],alpha=.1)
 ax.set_title(f'({chr(97+col)}) Annual response | ε = {eps}');ax.set_xlabel('Annual phase (year)');ax.set_ylabel('TL response / forcing amplitude');ax.set_ylim(-1.15,1.15);style(ax)
ax=axs[1,0]
for a,k in zip([0,1,5],range(3)):
 for eps,offset,mk in [(.025,-.10,'o'),(.05,.10,'s')]:
  r=next(r for r in HR['records'] if r['arm']==a and r['epsilon']==eps and r['variable']=='TL');m=r['gain_magnitude'];lo,hi=r['gain_magnitude_ci95'];ax.errorbar(k+offset,m,yerr=[[m-lo],[hi-m]],color=ac[a],marker=mk,capsize=3,ms=5)
ax.set_xticks(range(3),['Full','Off','Fixed mean']);ax.set_ylabel('Annual response gain');ax.set_ylim(bottom=0);ax.set_title('(d) Gain and amplitude check');style(ax)
ax=axs[1,1]
for k,a in enumerate([0,5]):
 for eps,offset,mk in [(.025,-.1,'o'),(.05,.1,'s')]:
  r=next(r for r in HR['comparisons'] if r['arm']==a and r['epsilon']==eps);m=r['TL_gain_difference_vs_off'];lo,hi=r['ci95'];ax.errorbar(k+offset,m,yerr=[[m-lo],[hi-m]],color=ac[a],marker=mk,capsize=3,ms=5)
ax.axhline(0,color='black',lw=.8);ax.set_xticks([0,1],['Full − off','Fixed mean − off']);ax.set_ylabel('Difference in annual gain');ax.set_title('(e) Paired gain differences');style(ax)
ax=axs[1,2]
for k,a in enumerate([0,1,5]):
 for eps,offset,mk in [(.025,-.1,'o'),(.05,.1,'s')]:
  r=next(r for r in HR['records'] if r['arm']==a and r['epsilon']==eps and r['variable']=='TL');m=r['phase_deg'];lo,hi=r['phase_offset_ci95'];ax.errorbar(k+offset,m,yerr=[[-lo],[hi]],color=ac[a],marker=mk,capsize=3,ms=5)
ax.set_xticks(range(3),['Full','Off','Fixed mean']);ax.set_ylabel('Response phase relative to input (°)');ax.set_title('(f) Annual phase response');style(ax)
fig.suptitle('Controlled annual forcing of land temperature',fontsize=15,y=.995)
fig.legend(handles=[Line2D([],[],color=ac[a],label=al[a],ls={0:'-',1:'--',5:'-.'}[a]) for a in [0,1,5]],loc='upper center',bbox_to_anchor=(.5,.95),ncol=3,frameon=False)
fig.legend(handles=[Line2D([],[],color='#333333',marker=m,ls='none',label=f'ε = {eps}') for eps,m in [(.025,'o'),(.05,'s')]],loc='upper center',bbox_to_anchor=(.5,.91),ncol=2,frameon=False)
fig.subplots_adjust(top=.80,bottom=.1,hspace=.43,wspace=.35);save(fig,'04_controlled_TL_annual_response')

fig,axs=plt.subplots(1,3,figsize=(14,3.4))
ax=axs[0]
for a in [1,2]:
 y=Z[f'parameter_drift_{a}'];m=y.mean(0);lo,hi=np.percentile(y[ix].mean(1),[2.5,97.5],axis=0);ax.plot(Z['parameter_time_TU'],m,color=colors[a],label=labels[a]);ax.fill_between(Z['parameter_time_TU'],lo,hi,color=colors[a],alpha=.12)
ax.set_xlabel('Time (TU)');ax.set_ylabel('RMS relative parameter-mean change');ax.set_title('(a) Change from the freezing checkpoint');ax.ticklabel_format(axis='x',style='plain',useOffset=False);ax.locator_params(axis='x',nbins=4);style(ax)
for j,v in enumerate(['Cocean','ALK'],1):
 ax=axs[j]
 for a in [0,1,2]:ax.plot(Z['cumulative_frequency_TU'][1:],Z[f'{a}_{v}_cumulative'].mean(0)[1:],color=colors[a],ls=['--','-','-.'][a])
 ax.set_xscale('log');ax.set_xlabel('Frequency (TU$^{-1}$)');ax.set_ylabel('Cumulative centered error variance');ax.set_title(f'({chr(97+j)}) {v} | Integrated error spectrum');ax.set_ylim(bottom=0);style(ax)
fig.suptitle('Parameter-drift and error-spectrum consistency checks',fontsize=15,y=1.03)
fig.legend(handles=[Line2D([],[],color=colors[a],label=labels[a],ls=['--','-','-.'][a]) for a in [0,1,2]],loc='upper center',bbox_to_anchor=(.5,.98),ncol=3,frameon=False)
fig.subplots_adjust(top=.77,bottom=.19,wspace=.35);save(fig,'05_parameter_drift_and_error_budget')
print('PLOTTED',len(list(O.glob('*.png'))),flush=True)
