from pathlib import Path
import json
import numpy as np
B=Path(__file__).resolve().parent;O=B/'analysis';base=np.load(O/'annual_baselines.npz')
rng=np.random.default_rng(20260915);ix=rng.integers(0,10,(19999,10));out={};rows=[];receipts=[]
def scalar_ci(a):
 a=np.asarray(a);return {'mean':float(a.mean()),'ci95':np.percentile(a[ix].mean(1),[2.5,97.5]).tolist()}
for arm in [0,1,5]:
 h0=[];phase0=[]
 for seed in range(10):
  h=base[f'{arm}_{seed}_harmonics'];h0.append(2*(h[:,1]+1j*h[:,2]));phase0.append(base[f'{arm}_{seed}_seasonal'])
 out[f'{arm}_baseline_harmonic']=np.array(h0);out[f'{arm}_baseline_cycle']=np.array(phase0)
 for eps in [.025,.05]:
  gains=[];cycles=[];blockg=[]
  for seed in range(10):
   vals=[];cy=[];bl=[];checkpoints=[]
   for sign in [-1,1]:
    d=B/'response'/f'arm{arm}_amp{sign*eps:+.3f}_seed{seed}'
    receipt=json.loads((d/'receipt.json').read_text());receipts.append(receipt);checkpoints.append(receipt['checkpoint_sha256'])
    h=np.loadtxt(d/'harmonics.txt');cycle=np.loadtxt(d/'seasonal_cycle.txt');blocks=np.loadtxt(d/'blocks.txt')
    assert h.shape==(10,3) and cycle.shape==(100,11) and blocks.shape==(900,5)
    assert np.isfinite(h).all() and np.isfinite(cycle).all() and np.isfinite(blocks).all()
    vals.append(2*(h[:,1]+1j*h[:,2]));cy.append(cycle[:,1:]);bl.append(blocks[:,2:].reshape(90,10,3))
   assert checkpoints[0]==checkpoints[1]
   gains.append((vals[1]-vals[0])/(2*eps));cycles.append((cy[1]-cy[0])/(2*eps))
   blockg.append(((bl[1][:,:,1]-bl[0][:,:,1])+1j*(bl[1][:,:,2]-bl[0][:,:,2]))/eps)
  gains=np.array(gains);out[f'{arm}_{eps}_gain']=gains;out[f'{arm}_{eps}_cycle']=np.array(cycles);out[f'{arm}_{eps}_block_gain']=np.array(blockg)
  for col,name in [(1,'x2'),(3,'w'),(4,'eta'),(6,'TL')]:
   q=gains[:,col];mean=q.mean();boot=q[ix].mean(1);mag=np.abs(boot)
   phases=np.angle(boot/mean)*180/np.pi if abs(mean)>1e-12 else np.full(len(boot),np.nan)
   rows.append({'arm':arm,'epsilon':eps,'variable':name,'gain_real':scalar_ci(q.real),'gain_imag':scalar_ci(q.imag),
    'gain_magnitude':float(abs(mean)),'gain_magnitude_ci95':np.percentile(mag,[2.5,97.5]).tolist(),
    'phase_deg':float(np.angle(mean)*180/np.pi),'phase_offset_ci95':np.percentile(phases,[2.5,97.5]).tolist(),
    'gain_first_half':[[float(v.real),float(v.imag)] for v in np.array(blockg)[:,:45,col].mean(1)],
    'gain_second_half':[[float(v.real),float(v.imag)] for v in np.array(blockg)[:,45:,col].mean(1)]})
diffs=[]
for arm in [0,5]:
 for eps in [.025,.05]:
  q=out[f'{arm}_{eps}_gain'][:,6];ref=out[f'1_{eps}_gain'][:,6]
  bootq=q[ix].mean(1);bootref=ref[ix].mean(1);delta=abs(bootq)-abs(bootref)
  diffs.append({'arm':arm,'epsilon':eps,'TL_gain_difference_vs_off':float(abs(q.mean())-abs(ref.mean())),
   'ci95':np.percentile(delta,[2.5,97.5]).tolist()})
checks=[]
for arm in [0,1,5]:
 q=out[f'{arm}_0.025_gain'][:,6];r=out[f'{arm}_0.05_gain'][:,6];d=q-r
 checks.append({'arm':arm,'half_minus_full_gain_real':scalar_ci(d.real),'half_minus_full_gain_imag':scalar_ci(d.imag),
  'relative_complex_difference':float(abs(d.mean())/max(abs(r.mean()),1e-12))})
assert len(receipts)==120 and len(set(r['task'] for r in receipts))==120
for arm in [0,1,5]:
 for seed in range(10):assert len(set(r['checkpoint_sha256'] for r in receipts if r['arm']==arm and r['seed']==seed))==1
np.savez_compressed(O/'annual_response.npz',**out)
(O/'annual_response.json').write_text(json.dumps({'window_TU':[60000,150000],'forcing_start_TU':50000,'all_seeds':list(range(10)),
 'epsilon':[.025,.05],'frequency_year_inverse':1.,'response_definition':'central +/- epsilon derivative of the complex annual coefficient; real=sin, imag=cos',
 'CI':'paired seed bootstrap, 19999 draws; exploratory pointwise intervals, not simultaneous confidence',
 'records':rows,'comparisons':diffs,'amplitude_checks':checks,'receipts':receipts},indent=2))
(O/'RESPONSE_DONE').write_text('120 finite responses; 30 matched background checkpoints; all seeds retained.\n')
print('RESPONSE_DONE',json.dumps({'comparisons':diffs,'amplitude_checks':checks}),flush=True)
