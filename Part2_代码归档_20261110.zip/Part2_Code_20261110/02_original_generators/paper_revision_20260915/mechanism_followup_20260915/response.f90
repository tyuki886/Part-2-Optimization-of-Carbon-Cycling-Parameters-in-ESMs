program annual_response
 use RKmethod
 implicit none
 real(dp)::x(10),frozen(10),amplitude,theta,tot(10,3),blk(10,3),ph(10,100),pcount(100)
 real(dp)::before(10)
 integer::seed,arm,u,ub,phase,j,nb
 integer(kind=8)::it,n,bc,stopit
 character(80)::arg,path
 call get_command_argument(1,arg);read(arg,*)seed
 call get_command_argument(2,arg);read(arg,*)arm
 call get_command_argument(3,arg);read(arg,*)amplitude
 stopit=15000000_8
 call get_command_argument(4,arg);if(len_trim(arg)>0)read(arg,*)stopit
 call reset_all_46();rollback_events=0_8
 write(path,'(A,I0,A)')'../../../feedback/arm0_seed',seed,'/checkpoint.bin'
 open(newunit=u,file=trim(path),access='stream',form='unformatted',status='old');read(u)x;close(u)
 paper_fixed_carbon=-1._dp
 select case(arm)
 case(0)
 case(1);c16=0._dp;c17=0._dp;c24=0._dp
 case(5)
  open(newunit=u,file='../../../fixed_carbon_means.txt',status='old');read(u,*)frozen;close(u)
  paper_fixed_carbon=frozen(seed+1)
 case default;error stop 'bad arm'
 end select
 test_amplitude=amplitude
 open(newunit=ub,file='blocks.txt',status='new')
 tot=0._dp;blk=0._dp;ph=0._dp;pcount=0._dp;n=0_8;bc=0_8;nb=0
 do it=1000001_8,stopit
  call adv_true_state(x,it,10)
  if(rollback_events/=0_8)error stop 'rollback'
  if(.not.all(abs(x)<=huge(1._dp)))error stop 'nonfinite'
  if(it==5000000_8)then
   open(newunit=u,file='forcing_checkpoint.bin',access='stream',form='unformatted',status='new');write(u)x;close(u)
  endif
  if(amplitude==0._dp.and.it==5000010_8)then
   open(newunit=u,file='replay_sample.bin',access='stream',form='unformatted',status='new');write(u)x;close(u)
  endif
  if(it>6000000_8.and.mod(it,10_8)==0_8)then
   theta=2._dp*PI*real(mod(it,1000_8),dp)/1000._dp
   n=n+1;bc=bc+1
   blk(:,1)=blk(:,1)+x;blk(:,2)=blk(:,2)+x*sin(theta);blk(:,3)=blk(:,3)+x*cos(theta)
   phase=int(mod(it/10_8,100_8))+1;ph(:,phase)=ph(:,phase)+x;pcount(phase)=pcount(phase)+1
   if(mod(it,100000_8)==0_8)then
    nb=nb+1;tot=tot+blk
    do j=1,10
     write(ub,'(2I8,3ES26.17E3)')nb,j,blk(j,:)/real(bc,dp)
    enddo
    blk=0._dp;bc=0_8
   endif
  endif
 enddo
 close(ub)
 if(stopit==15000000_8)then
  if(n/=900000_8.or.nb/=90.or.bc/=0_8)error stop 'wrong count'
  open(newunit=u,file='harmonics.txt',status='new')
  do j=1,10
   write(u,'(3ES26.17E3)')tot(j,:)/real(n,dp)
  enddo
  close(u)
  open(newunit=u,file='seasonal_cycle.txt',status='new')
  do phase=1,100
   write(u,'(11ES26.17E3)')real(phase-1,dp)/100._dp,ph(:,phase)/pcount(phase)
  enddo
  close(u)
 endif
 open(newunit=u,file='DONE',status='new');write(u,*)seed,arm,amplitude,stopit,n,rollback_events;close(u)
end program
