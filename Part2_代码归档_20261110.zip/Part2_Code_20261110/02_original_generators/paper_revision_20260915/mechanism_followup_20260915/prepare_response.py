"""Create an isolated, minimal additive-forcing modification of the audited RK module."""
from pathlib import Path
import hashlib, json
B=Path(__file__).resolve().parent
source=(B.parent/'RK_feedback.f90').read_text(encoding='utf-8')
anchor='    real(dp) :: paper_fixed_carbon=-1._dp'
assert source.count(anchor)==1
source=source.replace(anchor,anchor+'\n    real(dp) :: test_amplitude=0._dp\n    integer(kind=8) :: test_start=5000000_8')
anchor='        if (n >= 9) then\n            ds(8) ='
assert source.count(anchor)==1
source=source.replace(anchor,'        if(it>test_start) ds(7)=ds(7)+test_amplitude*sin(2._dp*PI*real(it,dp)*0.01_dp/10._dp)/olm\n'+anchor)
(B/'RK_response.f90').write_text(source,encoding='utf-8')
manifest={'source_parent_sha256':hashlib.sha256((B.parent/'RK_feedback.f90').read_bytes()).hexdigest(),
 'forcing':'add epsilon*sin(2*pi*t/10) to TL heat-budget numerator, only after 50000 TU',
 'arms':[0,1,5], 'seeds':list(range(10)), 'amplitudes':[-.05,-.025,.025,.05],
 'spinup_TU':10000,'forcing_start_TU':50000,'evaluation_TU':[60000,150000],
 'dt_TU':.01,'saved_statistics_sampling_TU':.1,'block_TU':1000,
 'baseline':'existing unforced feedback arm, identical 10000-TU checkpoint',
 'exclusions':'none; retain all 10 seeds; disclose uncertainty and amplitude dependence',
 'frequency_year_inverse':1.,'purpose':'annual TL response only, not a low-frequency transfer-function scan'}
(B/'design.json').write_text(json.dumps(manifest,indent=2))
print('PREPARED',B)
