"""Read-only source analysis. Exact full-record FFT identities are separate from Welch plots."""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent;P=B.parent;O=B/'analysis';O.mkdir(exist_ok=True)
rng=np.random.default_rng(20260915);boot=rng.integers(0,10,(19999,10))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ci(a):
 a=np.asarray(a);return {'mean':float(a.mean()),'ci95':np.percentile(a[boot].mean(1),[2.5,97.5]).tolist(),'seeds':a.tolist()}
def spectrum(x):
 z=np.fft.rfft(x-x.mean());s=np.full(len(z),2./(10*len(x)));s[0]/=2
 if len(x)%2==0:s[-1]/=2
 return z,s
records=[];arrays={};max_closure=0.;sources=[];parameter_drift=[]
for arm in range(4):
 for seed in range(10):
  d=P/'matched'/f'arm{arm}_seed{seed}';assert (d/'DONE').exists() and (d/'receipt.json').exists()
  path=d/'matched_states.bin';assert path.stat().st_size==500000*36*8
  a=np.memmap(path,dtype='<f8',mode='r',shape=(500000,36));assert np.all(np.isfinite(a))
  assert np.array_equal(a[[0,-1],0],[100000.1,150000.])
  native=np.loadtxt(d/'matched_moments.txt',skiprows=1)
  sources.append({'path':str(path),'bytes':path.stat().st_size,'receipt_sha256':sha(d/'receipt.json')})
  for j,v,origcol in [(5,'Cocean',8),(6,'ALK',9)]:
   t=np.array(a[:,1+j]);x=np.array(a[:,15+j]);e=x-t
   zx,scale=spectrum(x);zt,_=spectrum(t);ze,_=spectrum(e)
   px=scale*abs(zx)**2;pt=scale*abs(zt)**2;pe=scale*abs(ze)**2;cross=scale*(zx*np.conj(zt)).real
   df=10/len(x);f=np.fft.rfftfreq(len(x),.1);bias=float(e.mean());mse=float(np.mean(e**2))
   identity=px+pt-2*cross
   closure=abs(float(pe.sum()*df+bias*bias)-mse);max_closure=max(max_closure,closure)
   assert np.allclose(pe,identity,rtol=1e-8,atol=1e-10)
   assert closure<1e-10
   vx=x.var();vt=t.var();cov=np.mean((x-x.mean())*(t-t.mean()))
   amp=(np.sqrt(vx)-np.sqrt(vt))**2;timing=2*(np.sqrt(vx*vt)-cov)
   assert np.isclose(bias*bias+amp+timing,mse,rtol=1e-9,atol=1e-11)
   masks=[(f>0)&(f<=.00015),(f>.00015)&(f<=.1),(f>.1)]
   band_error=[float(pe[m].sum()*df) for m in masks]
   spectral_amplitude=(np.sqrt(px)-np.sqrt(pt))**2
   spectral_phase=2*(np.sqrt(px*pt)-cross)
   assert np.min(spectral_phase)>-1e-9
   row=dict(arm=arm,seed=seed,variable=v,bias=bias,bias2=bias*bias,amplitude_mismatch=float(amp),correlation_mismatch=float(timing),
    rmse=float(np.sqrt(mse)),native_rmse=float(np.sqrt(native[origcol,5])),sd_ratio=float(np.sqrt(vx/vt)),correlation=float(cov/np.sqrt(vx*vt)),
    band_error=band_error,band_amplitude=[float(spectral_amplitude[m].sum()*df) for m in masks],
    band_phase=[float(spectral_phase[m].sum()*df) for m in masks],closure=closure)
   records.append(row)
   take=(f*10000<=1.5);arrays.setdefault(f'{arm}_{v}_error',[]).append(pe[take]/10000)
   arrays.setdefault(f'{arm}_{v}_power',[]).append(px[take]/10000)
   arrays.setdefault(f'{arm}_{v}_truth',[]).append(pt[take]/10000)
   cumidx=np.unique(np.r_[0,np.geomspace(1,len(f)-1,600).astype(int),len(f)-1]);arrays['cumulative_frequency_TU']=f[cumidx]
   arrays.setdefault(f'{arm}_{v}_cumulative',[]).append(np.cumsum(pe)[cumidx]*df)
   arrays['carbon_frequency_millennium']=f[take]*10000
   if seed==0:
    arrays[f'{arm}_{v}_trace']=x[:100000];arrays[f'{arm}_{v}_trace_truth']=t[:100000];arrays['trace_time_TU']=a[:100000,0].copy()
  if arm in [1,2]:
   p=np.loadtxt(d/'parameter_mean.txt');sel=p[:,0]>=100000;p=p[sel]
   rows=[2,4,3,1,33,5,42,26,7,32,39,40,35,16,10,17,9,37,15,36,12,38]
   norm=np.sqrt(np.mean((p[:,rows]/p[0,rows]-1)**2,axis=1))
   arrays.setdefault(f'parameter_drift_{arm}',[]).append(norm);arrays['parameter_time_TU']=p[:,0]
   if arm==2:assert np.max(abs(norm))<1e-12,'Frozen parameter mean changed'
  print('matched',arm,seed,flush=True)
summary=[]
for v in ['Cocean','ALK']:
 for arm in range(4):
  rr=[r for r in records if r['arm']==arm and r['variable']==v]
  summary.append({'arm':arm,'variable':v,**{k:ci([r[k] for r in rr]) for k in ['native_rmse','bias2','amplitude_mismatch','correlation_mismatch','sd_ratio','correlation']}})
(O/'error_mechanisms.json').write_text(json.dumps({'window_TU':[100000,150000],'all_seeds':list(range(10)),'sample_dt_TU':.1,'native_RMSE_dt_TU':.01,
 'bands_TU_inverse':[[0,.00015],[.00015,.1],[.1,5]],'records':records,'summary':summary,'max_parseval_closure':max_closure,'sources':sources},indent=2))
np.savez_compressed(O/'error_mechanisms.npz',**{k:np.array(v) for k,v in arrays.items()})

z=np.load(P/'analysis/feedback_spectra.npz');peakrows=[];baselines={}
definitions=[('x2',0,.1,.7),('w',1,0,.3),('eta',2,0,.5),('TL-low',3,0,.5),('TL-annual',3,.95,1.05)]
for arm in [0,1,5]:
 for name,j,lo,hi in definitions:
  f=z[f'f{j}'];mask=(f>lo)&(f<=hi);ff=f[mask];df=ff[1]-ff[0]
  pp=z[f'{arm}_{j}'][:,mask]
  for seed in range(10):
   yy=pp[seed];k=yy.argmax();height=yy[k];area=yy.sum()*df
   peakrows.append(dict(arm=arm,seed=seed,variable=name,peak_height=float(height),peak_frequency=float(ff[k]),band_power=float(area),
    equivalent_width=float(area/height),peak_at_band_boundary=bool(k in [0,len(ff)-1])))
 for seed in range(10):
  a=np.memmap(P/'feedback'/f'arm{arm}_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(1000000,10))[100000:]
  assert a.shape==(900000,10)
  ph=(np.arange(900000)+1)%100;theta=2*np.pi*ph/100
  harm=np.c_[a.mean(0),(a*np.sin(theta)[:,None]).mean(0),(a*np.cos(theta)[:,None]).mean(0)]
  seasonal=np.empty((100,10))
  for k in range(100):seasonal[k]=a[ph==k].mean(0)
  blocks=np.stack([a.reshape(90,10000,10).mean(1),(a*np.sin(theta)[:,None]).reshape(90,10000,10).mean(1),(a*np.cos(theta)[:,None]).reshape(90,10000,10).mean(1)],axis=-1)
  baselines[f'{arm}_{seed}_harmonics']=harm;baselines[f'{arm}_{seed}_seasonal']=seasonal;baselines[f'{arm}_{seed}_blocks']=blocks
 print('feedback baseline',arm,flush=True)
peaksummary=[]
for name,j,lo,hi in definitions:
 for arm in [0,5]:
  for metric in ['peak_height','band_power','equivalent_width','peak_frequency']:
   r=[next(v[metric] for v in peakrows if v['arm']==arm and v['seed']==s and v['variable']==name) for s in range(10)]
   ref=[next(v[metric] for v in peakrows if v['arm']==1 and v['seed']==s and v['variable']==name) for s in range(10)]
   peaksummary.append({'variable':name,'arm':arm,'metric':metric,'percent_change_vs_off':ci(100*(np.array(r)/ref-1))})
(O/'feedback_peak_mechanisms.json').write_text(json.dumps({'window_TU':[50000,150000],'records':peakrows,'summary':peaksummary,
 'peak_bands':definitions,'width_definition':'fixed-band integrated PSD divided by band peak, not FWHM',
 'boundary_warning':'A maximum at a band boundary is not a resolved characteristic mode.'},indent=2))
np.savez_compressed(O/'annual_baselines.npz',**baselines)
(O/'ANALYSIS_DONE').write_text('All 40 matched records, exact spectral identities, and 30 feedback baselines verified.\n')
print('ANALYSIS_DONE',max_closure,flush=True)
