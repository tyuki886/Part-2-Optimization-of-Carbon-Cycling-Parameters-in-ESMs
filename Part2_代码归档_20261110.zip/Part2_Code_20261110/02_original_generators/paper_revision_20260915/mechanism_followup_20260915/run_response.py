from pathlib import Path
import sys,os,json,subprocess,re,time,hashlib
B=Path(__file__).resolve().parent
task=int(sys.argv[1]);pilot=task>=120
if pilot:
 arm=[0,1,5][task-120];seed=0;amp=0.;name=f'pilot_arm{arm}'
else:
 seed=task%10;amp=[-.05,-.025,.025,.05][(task//10)%4];arm=[0,1,5][task//40];name=f'arm{arm}_amp{amp:+.3f}_seed{seed}'
d=B/'response'/name;d.mkdir(parents=True,exist_ok=False);start=time.time()
cmd=[str(B/'response_model'),str(seed),str(arm),str(amp)]
if pilot:cmd.append('5000010')
with (d/'run.log').open('w') as log:
 p=subprocess.run(['/usr/bin/strace','-f','-s','240','-e','trace=process','-o',str(d/'run.trace')]+cmd,cwd=d,stdout=log,stderr=subprocess.STDOUT)
trace=(d/'run.trace').read_text();exits=[int(x) for x in re.findall(r'^\d+\s+\+\+\+ exited with (\d+) \+\+\+',trace,re.M)]
if p.returncode:assert p.returncode==255 and exits==[0,255] and 'ECHILD' in trace and 'WEXITSTATUS(s) == 0' in trace,(p.returncode,exits)
else:assert exits and all(x==0 for x in exits)
assert (d/'DONE').exists()
if pilot:
 with (B.parent/'feedback'/f'arm{arm}_seed0'/'states.bin').open('rb') as f:reference=f.read(80)
 assert reference==(d/'replay_sample.bin').read_bytes(),'zero-amplitude reference replay mismatch'
else:
 assert len((d/'blocks.txt').read_text().splitlines())==900
 assert len((d/'harmonics.txt').read_text().splitlines())==10
receipt={'task':task,'arm':arm,'seed':seed,'amplitude':amp,'pilot':pilot,'zero_replay':pilot,'seconds':time.time()-start,'wrapper_returncode':p.returncode,
 'checkpoint_sha256':hashlib.sha256((d/'forcing_checkpoint.bin').read_bytes()).hexdigest()}
(d/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
