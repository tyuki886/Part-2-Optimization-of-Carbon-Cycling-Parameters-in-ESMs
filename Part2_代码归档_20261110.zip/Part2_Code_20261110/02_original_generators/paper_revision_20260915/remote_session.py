"""Task-scoped SSH session. Password is entered once and never saved."""
import getpass,json,sys
from pathlib import Path
import paramiko
c=paramiko.SSHClient();c.load_system_host_keys()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
print('CONNECTED',flush=True)
for line in sys.stdin:
    try:
        q=json.loads(line)
        if q.get('quit'):break
        if 'cmd' in q:
            _,o,e=c.exec_command(q['cmd'],timeout=q.get('timeout',120))
            a=o.read().decode('utf-8','replace');b=e.read().decode('utf-8','replace')
            print(json.dumps({'code':o.channel.recv_exit_status(),'stdout':a,'stderr':b}),flush=True)
        else:
            with c.open_sftp() as f:
                for local,remote in q.get('put',[]):
                    assert remote.startswith('/public/home/hou/wyh/MCPE26.0/paper_revision_20260915/')
                    f.put(local,remote)
                for remote,local in q.get('get',[]):
                    assert remote.startswith('/public/home/hou/wyh/MCPE26.0/')
                    p=Path(local);p.parent.mkdir(parents=True,exist_ok=True);f.get(remote,str(p))
            print('TRANSFER_DONE',flush=True)
    except Exception as e: print(json.dumps({'error':str(e)}),flush=True)
c.close()
