from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from PIL import Image
B=Path(__file__).parent;O=B/'figures';font_manager.fontManager.addfont(str(B.parent/'saturation_remeasure_20260911/times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10,'mathtext.fontset':'stix'})
def save(fig,name):
 fig.savefig(O/(name+'.png'),dpi=300,bbox_inches='tight',pad_inches=.12);plt.close(fig)
 with Image.open(O/(name+'.png')) as im:im.thumbnail((1500,1100));im.convert('RGB').save(O/(name+'_preview.jpg'),quality=87)
A=json.loads((B/'feedback_results.json').read_text());z=np.load(B/'feedback_spectra.npz')
fig,axes=plt.subplots(2,4,figsize=(16,7.0));colors=['#111111','#D55E00','#0072B2'];labs=['Full feedback','All feedback off','Constant carbon forcing']
arms=[1,2,3,4,5];short=['All off','c16 off','c17 off','c24 off','Constant']
for j,v in enumerate(['x2','w','η','TL']):
 ax=axes[0,j]
 for arm,c,l in zip([0,1,5],colors,labs):ax.plot(z[f'f{j}'],z[f'{arm}_{j}'].mean(0),color=c,label=l,lw=1)
 ax.set_title(f'({chr(97+j)}) {v}');ax.set_xlim(0,1.5);ax.set_ylim(bottom=0);ax.set_xlabel('Frequency ('+['Month','Year','Decade','Year'][j]+'$^{-1}$)');ax.set_ylabel('PSD');ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,3));ax.grid(alpha=.2)
 ax=axes[1,j]
 rr=[next(r for r in A['records'] if r['arm']==a and r['variable']==['x2','w','eta','TL'][j]) for a in arms];m=np.array([r['mean_percent_variance_change'] for r in rr]);ci=np.array([r['ci95'] for r in rr]);ax.bar(range(5),m,color=['#D55E00','#999999','#009E73','#CC79A7','#0072B2'],alpha=.85);ax.errorbar(range(5),m,yerr=np.vstack([m-ci[:,0],ci[:,1]-m]),fmt='none',ecolor='black',capsize=3,lw=1)
 ax.axhline(0,color='black',lw=.8);ax.set_xticks(range(5),short,rotation=25,ha='right');ax.set_ylabel('Variance change vs full (%)');ax.set_title(f'({chr(101+j)}) {v}');ax.grid(axis='y',alpha=.2)
fig.suptitle('Controlled carbon-feedback experiments',fontsize=16,y=.99);fig.legend(handles=[Line2D([],[],color=c,label=l) for c,l in zip(colors,labs)],ncol=3,loc='upper center',bbox_to_anchor=(.5,.956),frameon=False);fig.subplots_adjust(top=.84,bottom=.12,hspace=.58,wspace=.4);save(fig,'carbon_feedback_controlled')
R=json.loads((B/'matched_results.json').read_text());rec=R['records'];z=np.load(B/'matched_spectra.npz');labels=['CDA8','MCPE30 continued','MCPE30 frozen','All-parameter truth'];clrs=['#0072B2','#D55E00','#009E73','#CC79A7'];summary=[]
for a in range(4):
 for v in ['x2','w','eta','TL','Catm','Cocean','ALK']:
  for sample in ['mean','member','forecast_mean','forecast_member']:
   rr=[r for r in rec if r['arm']==a and r['variable']==v and r['sample']==sample];assert len(rr)==10
   q={k:float(np.mean([r[k] for r in rr])) for k in rr[0] if k not in ['arm','seed','variable','sample']};q.update(arm=a,variable=v,sample=sample);summary.append(q)
(B/'matched_summary.json').write_text(json.dumps(summary,indent=2))
fig,axes=plt.subplots(2,3,figsize=(13,7.1));rng=np.random.default_rng(20260915);ix=rng.integers(0,10,(19999,10))
for j,v in enumerate(['Catm','Cocean','ALK']):
 for row,measure in enumerate(['native_rmse','spectral_L1_relative']):
  ax=axes[row,j]
  for a,c in enumerate(clrs):
   rr=[r for r in rec if r['arm']==a and r['variable']==v and r['sample']=='mean'];vals=np.array([r[measure] for r in rr]);m=vals.mean();lo,hi=np.percentile(vals[ix].mean(1),[2.5,97.5]);ax.bar(a,m,color=c,width=.65);ax.errorbar(a,m,yerr=[[m-lo],[hi-m]],color='black',capsize=3,lw=.8)
  ax.set_xticks(range(4),['CDA8','Continued','Frozen','Truth params'],rotation=18,ha='right');ax.set_ylabel('RMSE' if row==0 else 'Relative spectral L1 error');ax.set_title(f'({chr(97+row*3+j)}) {v}');ax.grid(axis='y',alpha=.2)
fig.suptitle('Matched-window carbon-state diagnostics',fontsize=16,y=.99);fig.subplots_adjust(top=.91,bottom=.1,hspace=.53,wspace=.35);save(fig,'matched_window_metrics')
fig,axes=plt.subplots(2,3,figsize=(13,7.2))
for row,sample in enumerate(['mean','member']):
 for j,v in enumerate(['Catm','Cocean','ALK']):
  k=j+4;ax=axes[row,j];f=z[f'f{k}'];ax.plot(f,z[f'truth_{k}'].mean(0),color='black',label='Truth',lw=1.4)
  for a,c,l in zip(range(4),clrs,labels):ax.plot(f,z[f'{a}_{sample}_{k}'].mean(0),color=c,label=l,lw=1.1)
  ax.set_title(f'({chr(97+row*3+j)}) {v} | '+('Ensemble mean' if row==0 else 'Member 1'));ax.set_xlabel('Frequency ('+('Year' if j==0 else 'Millennium')+'$^{-1}$)');ax.set_ylabel('PSD');ax.set_xlim(0,1.5);ax.set_ylim(bottom=0);ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,3));ax.grid(alpha=.2)
fig.suptitle('Carbon spectra under controlled parameter interventions',fontsize=16,y=.995);fig.legend(*axes[0,0].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.5,.96),ncol=5,frameon=False);fig.subplots_adjust(top=.84,bottom=.09,hspace=.5,wspace=.32);save(fig,'matched_window_carbon_spectra')
for v in ['Catm','Cocean','ALK']:
 print(v,[(a,[(sample,round(next(q for q in summary if q['arm']==a and q['variable']==v and q['sample']==sample)['rmse'],5),round(next(q for q in summary if q['arm']==a and q['variable']==v and q['sample']==sample)['spectral_L1_relative'],3)) for sample in ['mean','member']]) for a in range(4)])
