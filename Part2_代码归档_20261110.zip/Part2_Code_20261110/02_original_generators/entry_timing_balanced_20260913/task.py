"""Paired 8obs timing experiment; all seeds retained, exact channel-event audit."""
from pathlib import Path
import os,sys,json,hashlib
import numpy as np
from checked_exec import checked
B=Path(__file__).resolve().parent
C=json.loads((B/'config.json').read_text())
REF=B.parent/'three_channel_full22_20260912'/'runs'

def config_check():
    for arm in C['arms']:
        env=os.environ.copy();env['MCPE_ENTRY_ARM']=arm
        checked(B/'test_config',B,env,'config_'+arm)
        got=np.loadtxt(B/('config_'+arm+'.log'),dtype=np.int64)
        expected=[]
        for n in C['schemes']:
            cfg=C['configs'][arm][str(n)]
            assert [sum(s['group']==g for s in cfg['slots']) for g in range(3)]==[n//3]*3
            names=cfg['unique_parameters'];assert len(names)==len(set(names))
            for p in names:
                se=cfg['entries_steps'][p];cycles=cfg['cycles_steps'][p]
                first=min(x for x in se if x>=0)
                for j in range(8):expected.append([n,C['row45'][p],j+1,se[j],cycles[j],first,10000001])
        np.testing.assert_array_equal(got,expected)
    for n in C['schemes']:
        a=C['configs']['sync'][str(n)];b=C['configs']['staggered'][str(n)]
        assert a['unique_parameters']==b['unique_parameters'] and a['cycles_steps']==b['cycles_steps']
        for x,y in zip(a['slots'],b['slots']):
            assert y['entry_TU']-x['entry_TU']==(2000 if x['group']==2 else 0)
    print('CONFIG_ALL_TEN_PASS',flush=True)

def validate(d,arm,n,v,seed,steps,start,end):
    scal=(d/'audit_scalars.txt').read_text().splitlines()
    assert np.fromstring(scal[0],sep=' ',dtype=np.int64).tolist()==[steps,start,end,end-start,0]
    expected_state=[max(0,steps//round(C['obs_frequency_TU'][o]*100)-(1000000+round(C['obs_frequency_TU'][o]*100)-1)//round(C['obs_frequency_TU'][o]*100)+1) for o in C['observations']]
    np.testing.assert_array_equal(np.fromstring(scal[1],sep=' ',dtype=np.int64),expected_state)
    counts=np.zeros((45,8),dtype=np.int64);first=np.full((45,8),-1,dtype=np.int64);last=first.copy()
    if v==6:
        cfg=C['configs'][arm][str(n)];sched=[];channel=[]
        for p in cfg['unique_parameters']:
            rr=C['row45'][p];se=cfg['entries_steps'][p];cy=cfg['cycles_steps'][p]
            sched.append([rr,min(x for x in se if x>=0),10000001]+cy)
            for j,obs in enumerate(C['observations']):
                channel.append([rr,j+1,se[j],cy[j],10000001])
                if not cy[j]:assert se[j]==-1;continue
                freq=round(C['obs_frequency_TU'][obs]*100)
                first_step=((se[j]+cy[j]+freq-1)//freq)*freq
                period=((cy[j]+freq-1)//freq)*freq
                if first_step<=steps:
                    num=(steps-first_step)//period+1
                    counts[rr-1,j]=num;first[rr-1,j]=first_step;last[rr-1,j]=first_step+(num-1)*period
        np.testing.assert_array_equal(np.loadtxt(d/'schedule.txt',dtype=np.int64),sched)
        np.testing.assert_array_equal(np.loadtxt(d/'channel_schedule.txt',dtype=np.int64),channel)
    got=np.loadtxt(d/'parameter_updates.txt',dtype=np.int64).reshape(45,8,5)
    for j,expected in enumerate([counts,first,last],2):np.testing.assert_array_equal(got[:,:,j],expected)
    init=np.loadtxt(d/'initial_parameters.txt');final=np.loadtxt(d/'final_parameters.txt')
    assert init.shape==final.shape==(45,4) and np.isfinite(init).all() and np.isfinite(final).all()
    np.testing.assert_array_equal(init[~counts.any(1)],final[~counts.any(1)])
    assert (d/'initial_parameters.txt').read_bytes()==(REF/f'CDA8{seed}'/'initial_parameters.txt').read_bytes()
    rmse=np.loadtxt(d/f'rmse_M{n:02d}_v{v:02d}.txt')
    assert rmse.shape==(10,) and np.isfinite(rmse).all() and (rmse>=0).all()
    means=np.loadtxt(d/'parameter_mean.txt')
    assert means.shape[1]==91 and np.isfinite(means).all() and means[0,0]==0 and means[-1,0]==steps/100
    np.testing.assert_allclose(means[-1,1:46],final[:,2],rtol=1e-14)
    return dict(arm=arm,scheme=n,variant=v,seed=seed,steps=steps,rmse=rmse.tolist(),update_count=int(counts.sum()),rmse_samples=end-start,
      initial_sha256=hashlib.sha256((d/'initial_parameters.txt').read_bytes()).hexdigest())

def run(d,arm,n,v,seed,steps=10000000,start=9000000,end=10000000):
    d.mkdir(parents=True,exist_ok=False)
    env={k:v for k,v in os.environ.items() if not k.startswith('MCPE_')}
    env.update(MCPE_SCHEME=str(n),MCPE_VARIANT=str(v),MCPE_SEED=str(seed),MCPE_ENTRY_ARM=arm,
     MCPE_FREQ='1,4,20',MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS=str(steps),MCPE_EVAL=str(start),MCPE_EVAL_END=str(end),
     MCPE_SAVE_PARAM_MEAN='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    if steps!=10000000:env.update(MCPE_SMOKE='1',MCPE_CHECKPOINT='checkpoint.txt')
    try:
        exe=checked(B/'exp21_new',d,env,'run')
        result=validate(d,arm,n,v,seed,steps,start,end);result['execution']=exe
        (d/'audit.json').write_text(json.dumps(result,indent=2));(d/'READY').touch()
        print('READY',arm,n,v,seed,flush=True)
    except Exception as exc:(d/'FAILED').write_text(repr(exc));raise

def preflight():
    config_check()
    # All three numerical trajectories must be byte-identical before the first entry.
    for arm,n,v in [('sync',24,6),('staggered',24,6),('baseline',22,3)]:
        run(B/'preflight'/('before_'+arm),arm,n,v,0,1999900,1999000,1999900)
    ref=(B/'preflight/before_baseline/checkpoint.txt').read_bytes()
    for arm in C['arms']:assert (B/'preflight'/('before_'+arm)/'checkpoint.txt').read_bytes()==ref
    # Actual model tests include all eight ranks, both shared-channel entries and a full cycle afterwards.
    for arm in C['arms']:run(B/'preflight'/('after_'+arm),arm,24,6,0,6820000,6810000,6820000)
    # The modified driver must reproduce the old full-duration CDA8 reference exactly.
    d=B/'preflight/baseline_full';run(d,'baseline',22,3,0)
    for name in ['rmse_M22_v03.txt','initial_parameters.txt','final_parameters.txt','parameter_mean.txt','parameter_updates.txt']:
        assert (d/name).read_bytes()==(REF/'CDA80'/name).read_bytes(),name
    (B/'PREFLIGHT_PASS').write_text('All configurations, unchanged pre-entry states, exact baseline replay, actual shared-channel clocks and finite outputs passed.\n')

def production(i):
    assert (B/'PREFLIGHT_PASS').exists() and 0<=i<100
    arm=C['arms'][i//50];n=C['schemes'][(i%50)//10];seed=i%10
    run(B/'runs'/f'{i:03d}',arm,n,6,seed)

def summarize():
    results=[json.loads((B/'runs'/f'{i:03d}'/'audit.json').read_text()) for i in range(100)]
    assert all((B/'runs'/f'{i:03d}'/'READY').exists() for i in range(100))
    baseline=[]
    for seed in C['seeds']:
        p=REF/f'CDA8{seed}'
        scal=np.fromstring((p/'audit_scalars.txt').read_text().splitlines()[0],sep=' ',dtype=np.int64)
        np.testing.assert_array_equal(scal,[10000000,9000000,10000000,1000000,0])
        baseline.append(np.loadtxt(p/'rmse_M22_v03.txt').tolist())
    base=np.array(baseline);assert base.shape==(10,10) and np.isfinite(base).all()
    summary=dict(variables=['x1','x2','x3','w','eta','ice','TL','Catm','Cocean','ALK'],seeds=C['seeds'],baseline=dict(mean=base.mean(0).tolist(),per_seed=baseline),results={})
    for arm in C['arms']:
        summary['results'][arm]={}
        for n in C['schemes']:
            a=sorted([r for r in results if r['arm']==arm and r['scheme']==n],key=lambda r:r['seed'])
            assert [r['seed'] for r in a]==C['seeds']
            values=np.array([r['rmse'] for r in a]);diff=values-base
            summary['results'][arm][str(n)]=dict(mean=values.mean(0).tolist(),per_seed=values.tolist(),delta_vs_CDA8=diff.mean(0).tolist(),seeds_lower_than_CDA8=(diff<0).sum(0).tolist())
    (B/'summary.json').write_text(json.dumps(summary,indent=2))
    lines=['# 两组入场时序对照结果','', '8obs；10个seed全部纳入；RMSE窗口(90000,100000] TU，逐step计算后取seed均值。','', '|方案|Catm|Cocean|ALK|','|---|---:|---:|---:|']
    lines.append('|CDA8|'+'|'.join(f'{v:.7f}' for v in base.mean(0)[7:])+'|')
    for n in C['schemes']:
        for arm,label in [('sync','同步'),('staggered','错开')]:
            a=summary['results'][arm][str(n)]['mean']
            lines.append(f'|MCPE{n} {label}|'+ '|'.join(f'{v:.7f}' for v in a[7:])+'|')
    (B/'RMSE对比.md').write_text('\n'.join(lines)+'\n')
    (B/'RESULTS_READY').touch();print('\n'.join(lines),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='preflight':preflight()
    elif sys.argv[1]=='summary':summarize()
    elif sys.argv[1]=='config':config_check()
    else:production(int(sys.argv[1]))
