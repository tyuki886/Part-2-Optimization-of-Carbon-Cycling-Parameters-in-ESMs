import subprocess,re
def checked(exe,folder,env,label):
 trace=folder/(label+'.trace');log=folder/(label+'.log')
 with log.open('w') as f:
  p=subprocess.run(['/usr/bin/strace','-f','-s','240','-e','trace=process','-o',str(trace),str(exe)],
                   cwd=folder,env=env,stdout=f,stderr=subprocess.STDOUT)
 text=trace.read_text();exits=[int(x) for x in re.findall(r'^\d+\s+\+\+\+ exited with (\d+) \+\+\+',text,re.M)]
 if p.returncode==0:assert exits and all(x==0 for x in exits),exits
 else:
  assert p.returncode==255 and exits==[0,255] and 'ECHILD' in text and 'WEXITSTATUS(s) == 0' in text,(p.returncode,exits)
 return {'outer_exit':p.returncode,'real_model_exit':0,'trace':trace.name}
