"""Build a separate, reproducible two-arm timing experiment; never modify old runs."""
from pathlib import Path
import json,re,hashlib,shutil
B=Path(__file__).resolve().parent
SRC=B.parent/'three_channel_complete578_20260913'
def put(name,text):
    (B/name).write_text(text,encoding='utf-8',newline='\n')
def replace_once(s,a,b):
    assert s.count(a)==1,(a,s.count(a))
    return s.replace(a,b)
cfg=json.loads((SRC/'baseline_config.json').read_text(encoding='utf-8'))
groups=[['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11'],
 ['c24','c16','c20','c29','c18','c30','c28','c19','c22','c23'],
 ['c27','c29','c30','c20','c16','c19','c24','c17','c22','c23']]
row=dict(zip(groups[0],[2,4,3,1,33,5,42,26,7,32]))
row.update(dict(zip(groups[1],[39,35,10,16,9,17,15,37,12,38])));row.update(c27=40,c17=36)
obs=['x1','x2','x3','w','TL','Catm','Cocean','ALK']
cfg={k:cfg[k] for k in ['spinup_TU','pure_CDA_TU','end_TU','RMSE_window_TU','RMSE_samples_per_run','dt_TU','ensemble_members','seeds','obs_frequency_TU','cycles_TU']}
cfg.update(version=B.name,groups=groups,row45=row,schemes=[12,15,18,21,24],arms=['sync','staggered'],observations=obs,
 note='Only ALK entry changes. Water and Catm/Cocean retain the same rank-based times in both arms. One ensemble per unique parameter; no reset on second-channel entry.',configs={})
for arm in cfg['arms']:
    cfg['configs'][arm]={}
    for n in cfg['schemes']:
        slots=[];unique=[]
        for rank in range(n//3):
            for g in range(3):
                p=groups[g][rank];t=20000+6000*rank+2000*g
                if arm=='sync' and g==2:t-=2000
                slots.append(dict(group=g,rank=rank+1,name=p,row45=row[p],entry_TU=t))
                if p not in unique:unique.append(p)
        entries={p:[-1]*8 for p in unique};cycles={p:[0]*8 for p in unique}
        for slot in slots:
            channels=[range(5),range(5,7),range(7,8)][slot['group']]
            for j in channels:
                entries[slot['name']][j]=slot['entry_TU']*100
                cycles[slot['name']][j]=cfg['cycles_TU'][slot['name']].get(obs[j],0)*100
                assert cycles[slot['name']][j]>0
        cfg['configs'][arm][str(n)]=dict(slots=slots,unique_parameters=unique,entries_steps=entries,cycles_steps=cycles)
put('config.json',json.dumps(cfg,indent=2,ensure_ascii=False)+'\n')
f=(SRC/'MCPE42_new.f90').read_text(encoding='utf-8')
cases=[]
for n in cfg['schemes']:
    rr=[row[p] for p in cfg['configs']['sync'][str(n)]['unique_parameters']]
    cases.append(f"        case({n}); allocate(rows({len(rr)})); rows=[{','.join(map(str,rr))}]")
fun='''    function scheme_est_rows(ns) result(rows)
        integer,intent(in)::ns
        integer,allocatable::rows(:)
        select case(ns)
'''+ '\n'.join(cases)+'''
        case default; error stop 'INVALID_BALANCED_QUOTA'
        end select
    end function'''
f,count=re.subn(r'    function scheme_est_rows\(ns\) result\(rows\).*?    end function',lambda _:fun,f,flags=re.S);assert count==1
sub='''
    subroutine quota_channels(n,no,rows,cc,entries,starts,ends,weights)
        integer,intent(in)::n,no,rows(:)
        integer(kind=8),intent(out)::cc(:,:),entries(:,:),starts(:),ends(:)
        real(kind=dp),intent(out)::weights(:,:)
        integer,parameter::alk10(10)=[40,16,17,10,35,37,39,36,12,38]
        integer::rank,g,p,k,j,first,last,status
        integer(kind=8)::entry,full(8)
        character(16)::arm
        call get_environment_variable('MCPE_ENTRY_ARM',arm,status=status)
        if(status/=0)error stop 'ENTRY_ARM_REQUIRED'
        if(trim(arm)/='sync'.and.trim(arm)/='staggered')error stop 'INVALID_ENTRY_ARM'
        if(mod(n,3)/=0.or.n<12.or.n>24)error stop 'INVALID_QUOTA'
        entries=-1_8;cc=0_8;weights=0._dp;starts=huge(1_8);ends=10000001_8
        do rank=1,n/3
            do g=1,3
                select case(g)
                case(1);p=phys_top10(rank);first=1;last=5
                case(2);p=carb_top10(rank);first=6;last=7
                case(3);p=alk10(rank);first=8;last=8
                end select
                entry=(20000_8+6000_8*(rank-1)+2000_8*(g-1))*100_8
                if(trim(arm)=='sync'.and.g==3)entry=entry-200000_8
                k=1
                do while(k<=size(rows))
                    if(rows(k)==p)exit
                    k=k+1
                enddo
                if(k>size(rows))error stop 'MISSING_SHARED_ROW'
                call canonical_cycles(p,full)
                do j=first,min(last,no)
                    if(entries(k,j)/=-1_8)error stop 'DUPLICATE_CHANNEL'
                    entries(k,j)=entry;cc(k,j)=full(j);weights(k,j)=1._dp
                    starts(k)=min(starts(k),entry)
                    if(cc(k,j)<=0_8)error stop 'ZERO_SELECTED_CYCLE'
                enddo
            enddo
        enddo
    end subroutine
'''
f=replace_once(f,'end module MCPE42',sub+'end module MCPE42');put('MCPE42_new.f90',f)
e=(SRC/'exp21_new.f90').read_text(encoding='utf-8')
e=replace_once(e,'cc(:,:),st2(:),en2(:)','cc(:,:),st2(:),en2(:),chstart(:,:)')
e=replace_once(e,"if(.not.((n>=6.and.n<=20.and.v>=4.and.v<=6).or.(n==22.and.v>=0.and.v<=3)))error stop 'INVALID_COMPLETE_MODE'", "if(.not.((n>=12.and.n<=24.and.mod(n,3)==0.and.v==6).or.(n==22.and.v==3)))error stop 'INVALID_TIMING_EXPERIMENT'")
e=replace_once(e,'case(6:22); write(stem','case(12:24); write(stem')
a=e.index('        ! C-37/C-38:');z=e.index("        if(v==4)lb=",a)
e=e[:a]+'''        r=scheme_est_rows(n);nr=size(r)
        allocate(cc(nr,no),st2(nr),en2(nr),chstart(nr,no),w(nr,no),cv(nr))
        call quota_channels(n,no,r,cc,chstart,st2,en2,w);cv=1._dp
'''+e[z:]
e=replace_once(e,'r,cc,st2,en2,w,cv,br2=br,nr3=nr2,tsp=ts,rs=es,re=ee,ae=ee+1_8)',
 'r,cc,st2,en2,w,cv,br2=br,nr3=nr2,tsp=ts,rs=es,re=ee,ae=ee+1_8,channel_se=chstart)')
e=replace_once(e,'subroutine r21(sn,rf,oi2,ov3,of2,er,ct2,se,ee3,lw,cf2,br2,tsp,res,rs,re,ae,nr3)',
 'subroutine r21(sn,rf,oi2,ov3,of2,er,ct2,se,ee3,lw,cf2,br2,tsp,res,rs,re,ae,nr3,channel_se)')
e=replace_once(e,'optional::ct2(:,:),se(:),ee3(:)','optional::ct2(:,:),se(:),ee3(:),channel_se(:,:)')
e=replace_once(e,'        isd=0._dp','''        open(93,file='channel_schedule.txt',status='replace')
        do k=1,ne2
            do io2=1,no2
                write(93,'(5I14)')er(k),io2,channel_se(k,io2),ct2(k,io2),ee3(k)
            enddo
        enddo
        close(93)
        isd=0._dp''')
e=replace_once(e,'if(no2>0)then; do k=1,ne2; lastup(k,:)=se(k); enddo; endif',
 'if(no2>0)then; lastup=channel_se; endif')
e=replace_once(e,'                        if(ct2(k,io2)<=0_8)cycle;',
 '                        if(i<channel_se(k,io2))cycle\n                        if(ct2(k,io2)<=0_8)cycle;')
put('exp21_new.f90',e)
for name in ['RKmethod.f90','checked_exec.py']:shutil.copy2(SRC/name,B/name)
# Exhaustive scheduler export without numerical integrations, independently checked by task.py.
put('test_config.f90','''program test_config
use MCPE42
implicit none
integer::n,k,j
integer,allocatable::r(:)
integer(kind=8),allocatable::c(:,:),s(:,:),first(:),last(:)
real(kind=dp),allocatable::w(:,:)
call configure_parameter_channels()
do n=12,24,3
 r=scheme_est_rows(n)
 allocate(c(size(r),8),s(size(r),8),first(size(r)),last(size(r)),w(size(r),8))
 call quota_channels(n,8,r,c,s,first,last,w)
 do k=1,size(r)
  do j=1,8
   write(*,'(7I14)')n,r(k),j,s(k,j),c(k,j),first(k),last(k)
  enddo
 enddo
 deallocate(r,c,s,first,last,w)
enddo
end program
''')
lines=['# 五方案、两种碳通道入场时序对照','',
 '两组都采用独立通道和独立周期，共享参数只保留一套集合，不在第二通道入场时重新初始化。',
 '同步组：同一敏感性排名的 Catm/Cocean 与 ALK 参数同时入场（不要求参数名称相同）。',
 '错开组：水循环 → Catm/Cocean → ALK 各占2000 TU。',
 '水循环与 Catm/Cocean 的时点在两组中一致；同步组仅把 ALK 提前2000 TU，不压缩水循环后续时段。',
 '各参数更新周期、观测、初始扰动、seed配对均不变。8obs；10个seed；总长100000 TU；RMSE取(90000,100000]逐步统计。',
 '编号表示组内名额总和，不是去重后的参数数目。本批不跑功率谱，不生成全套图。','',
 '|方案|三组名额|不同参数数|同步组最后入场TU|错开组最后入场TU|','|---|---|---:|---:|---:|']
for n in cfg['schemes']:
    a=cfg['configs']['sync'][str(n)];b=cfg['configs']['staggered'][str(n)]
    lines.append(f"|MCPE{n}|{n//3}+{n//3}+{n//3}|{len(a['unique_parameters'])}|{max(s['entry_TU'] for s in a['slots'])}|{max(s['entry_TU'] for s in b['slots'])}|")
put('实验说明.md','\n'.join(lines)+'\n')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in B.iterdir() if p.suffix in ['.py','.f90','.json','.md'] and p.name!='manifest.json'}
put('manifest.json',json.dumps(manifest,indent=2)+'\n')
print('PREPARED',B,flush=True)
