from pathlib import Path
import json,getpass
import paramiko
B=Path(__file__).resolve().parent;R='/public/home/hou/wyh/MCPE26.0';PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
DEPS=R+'/twin_work_3x3/python_deps:'+R+'/power_combined/python_deps'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=30,look_for_keys=False,allow_agent=False)
def run(s):
    _,o,e=c.exec_command(s,timeout=180);a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);print(a,flush=True);return a
try:
    run(f'PYTHONPATH={DEPS} {PY} -c "import numpy,scipy,matplotlib; print(numpy.__version__,scipy.__version__)"')
    for local,script,log,jobfile,jobkey,done,name in [(B,'recompute_4x.py','psd4x.log','psd4x_job.json','job','psd_4x_20260914/DONE','PSD4xFix'),(B.parent/'carbon_feedback_off_20260914','compute_feedback_psd.py','analysis.log','analysis_submission.json','job_id','analysis/ANALYSIS_DONE','FBpsdFix')]:
        rd=R+'/'+local.name;old=json.loads((local/jobfile).read_text());job=old[jobkey]
        state=run(f'qstat -f {job} 2>/dev/null || true; tail -n 10 {rd}/{log}')
        assert not any('job_state = '+s in state for s in ['Q','R','E','H','W','T']),state
        run(f'test ! -e {rd}/{done}; grep -q "No module named" {rd}/{log}')
        new=run(f'cd {rd}/logs && qsub -N {name} -q new -l nodes=1:ppn=1 -l walltime=00:30:00 -j oe <<\'EOF\'\n#!/bin/bash\nset -eu\ncd {rd}\nexport OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1\nexport PYTHONPATH={DEPS}\n{PY} {script} > {log} 2>&1\nEOF').strip()
        old['previous_job']=job;old[jobkey]=new;old['dependency_paths']=DEPS
        # Preserve first submission as a separate audit file.
        backup=local/(jobfile+'.initial');backup.write_text((local/jobfile).read_text()) if not backup.exists() else None
        (local/jobfile).write_text(json.dumps(old,indent=2))
        with c.open_sftp() as ftp:ftp.put(str(local/jobfile),rd+'/'+jobfile)
finally:c.close()
