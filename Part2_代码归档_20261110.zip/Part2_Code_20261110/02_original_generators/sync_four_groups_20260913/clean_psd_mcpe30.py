"""MCPE30原Welch谱排版修订：只保留总标题/图例，面板按行标(a)-(g)。"""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.text import Text
from PIL import Image
import plot_corrected as plot

B=Path(__file__).resolve().parent
longer='--4x' in sys.argv
source=B/'psd_4x_20260914'/'plot_data.json' if longer else B/'figures'/'power_spectra'/'plot_data.json'
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
data=json.loads(source.read_text(encoding='utf-8'))
compact='--compact' in sys.argv
out=B/('psd_4x_20260914' if longer else ('psd_compact_20260914' if compact else 'psd_clean_20260914'));out.mkdir(exist_ok=True)
plot.configure_font(B)
config,xlim=plot.original_config(B)
methods=['CTL','CDA8']+[f'MCPE{n}' for n in [12,15,18,21,24,27,30]]
labels=['Truth','CTL','CDA8','MCPE30']
styles={'Truth':dict(color='#111111',ls='-',marker=None),
        'CTL':dict(color='#777777',ls=(0,(6,3)),marker=None),
        'CDA8':dict(color='#0072B2',ls=(0,(1,1.8)),marker='x'),
        'MCPE30':dict(color='#D64000',ls='-',marker='o')}
letters={'x2':'a','Catm':'b','w':'c','Cocean':'d','eta':'e','ALK':'f','TL':'g'}
fig=plt.figure(figsize=(14,10.2 if compact else 13.5))
outer=fig.add_gridspec(1,2,left=.062 if compact else .078,right=.985 if compact else .976,
                      bottom=.065 if compact else .055,top=.90 if compact else .91,
                      wspace=.15 if compact else .23)
left=outer[0,0].subgridspec(4,1,hspace=.53 if compact else .58)
right=outer[0,1].subgridspec(3,1,hspace=.34 if compact else .40)
axes={}
for names,grid in ((plot.VARIABLES[:4],left),(plot.VARIABLES[4:],right)):
    for i,var in enumerate(names):axes[var]=fig.add_subplot(grid[i,0])
fig.suptitle('Power spectra: CTL, Truth, CDA8 and MCPE30',y=.987,fontsize=16)
handles=[Line2D([],[],lw=1.5,markersize=5,markerfacecolor='white',**styles[m]) for m in labels]
legend=fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.52,.963),
                 ncol=4,frameon=False,fontsize=11,handlelength=3.4,columnspacing=1.45)
checks={}
for var,ax in axes.items():
    d=data[var];f=np.array(d['frequency'])
    assert np.isfinite(f).all() and (np.diff(f)>0).all()
    for i,m in enumerate(labels):
        y=np.array(d[m]);assert y.shape==f.shape and np.isfinite(y).all() and (y>=0).all()
        stride=max(7,len(f)//9)
        line,=ax.plot(f,y,lw=1.5,markersize=4.7,markerfacecolor='white',markeredgewidth=.9,
                     markevery=list(range(i%stride,len(f),stride)),**styles[m])
        np.testing.assert_array_equal(line.get_xdata(),f)
        np.testing.assert_array_equal(line.get_ydata(),y)
    # Preserve the original seven-scheme shared y limits, not newly autoscaled limits.
    ymax=1.1*max(max(d[m]) for m in (labels if longer else ['Truth']+methods))
    ax.set_xlim(*xlim);ax.set_ylim(0,ymax)
    plot.axis_style(ax,var,config[var]['xlab'].replace('Model ',''),'PSD',spectrum=True)
    ax.set_title(f'({letters[var]}) {var}',fontsize=12)
    checks[var]={'letter':letters[var],'points':len(f),'ylim':[0,ymax],'curves':labels}
assert len(fig.axes)==7 and sum(len(ax.lines) for ax in fig.axes)==28
assert len(fig.texts)==1
assert not any(any(s in text.get_text().lower() for s in ['segment','full record','full-record','fixed member','seeds'])
               for text in fig.findobj(Text))
fig.canvas.draw();renderer=fig.canvas.get_renderer()
legend_box=legend.get_window_extent(renderer)
assert not legend_box.overlaps(fig._suptitle.get_window_extent(renderer))
for ax in fig.axes:
    assert not legend_box.overlaps(ax.get_tightbbox(renderer))
for column in (plot.VARIABLES[:4],plot.VARIABLES[4:]):
    for upper,lower in zip(column,column[1:]):
        assert not axes[upper].get_tightbbox(renderer).overlaps(axes[lower].get_tightbbox(renderer)), (upper,lower)
path=out/('power_spectra_MCPE30_vs_CTL_Truth_CDA8_Welch4x.png' if longer else 'power_spectra_MCPE30_vs_CTL_Truth_CDA8.png')
fig.savefig(path,dpi=300,facecolor='white');plt.close(fig)
assert source_hash==hashlib.sha256(source.read_bytes()).hexdigest()
with Image.open(path) as im:
    size=list(im.size);im.thumbnail((1300,1250));im.convert('RGB').save(out/'preview.jpg',quality=75)
(out/'validation.json').write_text(json.dumps({'source':str(source),'source_sha256':source_hash,
    'unchanged':{'window_TU':[100000,150000],'seeds':10,'member':1,'Welch_config':config,
                 'data_and_styles_and_axis_limits':True},'panel_checks':checks,
    'removed':'Two header notes, segment/full-record panel descriptions, and both footer notes',
    'title_and_legend_only_above_panels':True,'compact':compact,'Welch_segment_factor':4 if longer else 1,'size':size,'output':str(path)},indent=2),encoding='utf-8')
print('PASS: 7 panels, 28 unchanged curves; no segment/footer notes; header clear.')
print(path)
