from pathlib import Path
import json, hashlib, shutil

B = Path(__file__).resolve().parent
D = Path(r'D:\SRDP\论文大作！\MCPE26.0\9.2\同步MCPE12-30_七方案四类图_20260913')
records = []
for folder, audit, dest in [
    ('parameter_ensemble_20260913', 'audit.json', 'parameter_ensemble'),
    ('evidence_123_20260913', 'paired_audit.json', 'evidence_123'),
]:
    source = B / folder
    meta = json.loads((source / audit).read_text(encoding='utf-8'))
    for relative, info in meta['images'].items():
        src = source / relative
        rel = Path(relative)
        if rel.parts[0] == 'figures':
            rel = Path(*rel.parts[1:])
        dst = D / dest / rel
        assert src.suffix.lower() == '.png'
        expected = info['sha256']
        assert hashlib.sha256(src.read_bytes()).hexdigest() == expected
        if dst.exists():
            assert hashlib.sha256(dst.read_bytes()).hexdigest() == expected, dst
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        assert hashlib.sha256(dst.read_bytes()).hexdigest() == expected
        records.append({'path': str(dst), 'sha256': expected})
(B / 'diagnostics_delivery.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'PNG_DELIVERED {len(records)}')
print(D)
