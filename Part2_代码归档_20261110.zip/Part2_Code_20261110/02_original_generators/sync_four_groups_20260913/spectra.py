from pathlib import Path
import sys
for dep in ['twin_work_3x3/python_deps','power_combined/python_deps']:
    sys.path.insert(0,str(Path(__file__).resolve().parent.parent/dep))
import json,hashlib
import numpy as np
from scipy import signal
import plot_corrected as plot
B=Path(__file__).resolve().parent
FACTORS=[1]
def psd(x,cfg,factor):
    x=np.asarray(x,dtype=float);x=x-x.mean()
    n=len(x) if cfg['nperseg']=='full' else cfg['nperseg']*factor
    window='boxcar' if cfg['nperseg']=='full' else 'hann'
    assert n<=len(x)
    f,p=signal.welch(x,fs=cfg['fs'],window=window,nperseg=n,noverlap=n//2,nfft=n,detrend='constant',return_onesided=True,scaling='density',average='mean')
    return f*cfg['mult'],p/cfg['mult']
def selftest():
    cfg,_=plot.original_config(B)
    rng=np.random.RandomState(20260913)
    for name,c in cfg.items():
        x=rng.normal(size=max(10000,8193))
        f,p=psd(x,c,1)
        n=len(x) if c['nperseg']=='full' else c['nperseg'];win='boxcar' if c['nperseg']=='full' else 'hann'
        a,b=signal.welch(x-x.mean(),fs=c['fs'],window=win,nperseg=n,scaling='spectrum')
        w=signal.get_window(win,n);enbw=c['fs']*(w*w).sum()/w.sum()**2
        np.testing.assert_allclose(f,a*c['mult'],atol=0,rtol=0)
        np.testing.assert_allclose(p*c['mult']*enbw,b,rtol=1e-12,atol=1e-15)
        integ=lambda y,x:np.sum((y[1:]+y[:-1])*.5*np.diff(x))
        np.testing.assert_allclose(integ(p,f),integ(p*c['mult'],f/c['mult']),rtol=1e-12)
    print('PSD_SELFTEST_PASS',flush=True)
def analyze(d):
    cfg,xlim=plot.original_config(B)
    a=np.memmap(d/'spectral_member1.bin',dtype='<f8',mode='r',shape=(500001,15))
    arrays={};meta={'window_TU':[100000,150000],'member_index':0,'factors':FACTORS,'variables':{}}
    for j,var in enumerate(plot.VARIABLES):
        c=cfg[var];stride=int(round(10/c['fs']))
        data=a[::stride];n=len(data)
        assert n==int(50000*c['fs'])+1
        assert np.isfinite(data).all()
        meta['variables'][var]={'samples':n,'sample_interval_TU':1/c['fs'],'truth_sha256':hashlib.sha256(np.ascontiguousarray(data[:,1+j]).tobytes()).hexdigest()}
        for factor in FACTORS:
            f,t=psd(data[:,1+j],c,factor);g,m=psd(data[:,8+j],c,factor)
            np.testing.assert_array_equal(f,g)
            mask=(f>=xlim[0])&(f<=xlim[1])
            for label,value in [('frequency',f[mask]),('truth',t[mask]),('member1',m[mask])]:
                assert np.isfinite(value).all() and (value>=0).all()
                arrays[f'{var}_{factor}_{label}']=value
            if c['nperseg']=='full':assert mask.sum()==8
    np.savez_compressed(d/'spectra.npz',**arrays)
    (d/'spectra_audit.json').write_text(json.dumps(meta,indent=2))
