"""Extend only the approved synchronous quotas, retaining numerical model and cycles."""
from pathlib import Path
import json,re,shutil,hashlib
B=Path(__file__).resolve().parent
TIMING=B.parent/'entry_timing_balanced_20260913'
PSD=B.parent/'three_channel_figures_psd150k_20260913'
OLD=B.parent/'three_channel_complete578_20260913'
def write(name,s):(B/name).write_text(s,encoding='utf-8',newline='\n')
def one(s,a,b):
    assert s.count(a)==1,(a,s.count(a))
    return s.replace(a,b)
# Reuse the reviewed quota generator mechanically in this independent directory.
s=(TIMING/'prepare.py').read_text(encoding='utf-8')
s=s.replace('schemes=[12,15,18,21,24]','schemes=[12,15,18,21,24,27,30]')
s=s.replace('n>24','n>30').replace('do n=12,24,3','do n=12,30,3')
s=s.replace("n<=24.and.mod(n,3)==0.and.v==6).or.(n==22.and.v==3)","n<=30.and.mod(n,3)==0.and.v>=4.and.v<=6).or.(n==22.and.v>=0.and.v<=3)")
s=s.replace("case(12:24); write(stem","case(12:30); write(stem")
exec(compile(s,str(TIMING/'prepare.py'),'exec'),{'__file__':str(B/'prepare.py'),'__name__':'quota_generator'})
c=json.loads((B/'config.json').read_text());c['arms']=['sync'];c['configs']={'sync':c['configs']['sync']};c['PSD_window_TU']=[100000,150000]
c['production_end_TU']={'5obs':100000,'7obs':100000,'8obs':150000};c['parameter_mean_window_TU']=[0,100000]
c['correction_reference']='MCPE12; mean of per-seed percentage corrections'
write('config.json',json.dumps(c,indent=2))
e=(B/'exp21_new.f90').read_text()
e=one(e,"write(93,'(*(I12,1X))')er(k),se(k),ee3(k),ct2(k,:)","write(93,'(*(I24,1X))')er(k),se(k),ee3(k),ct2(k,:)")
e=one(e,"if(ts/=10000000_8.or.es/=9000000_8.or.ee/=10000000_8)error stop 'WRONG_PRODUCTION_WINDOW'", "if((ts/=10000000_8.and.ts/=15000000_8).or.es/=9000000_8.or.ee/=10000000_8)error stop 'WRONG_PRODUCTION_WINDOW'")
e=one(e,'call quota_channels(n,no,r,cc,chstart,st2,en2,w);cv=1._dp','call quota_channels(n,no,r,cc,chstart,st2,en2,w);cv=1._dp\n        en2=ts+1_8')
assert e.count('ae=ee+1_8')==2;e=e.replace('ae=ee+1_8','ae=ts+1_8')
e=one(e,'        logical::save_mean','''        logical::save_mean,save_psd
        integer,parameter::psd_idx(7)=[2,4,5,7,8,9,10]
        integer(kind=8)::psd_start
        character(40)::psd_env
        integer::psd_st''')
e=one(e,'        mse2=0._dp; cr2=0_8','''        save_psd=.false.;psd_start=10000000_8
        call get_environment_variable('MCPE_PSD',psd_env,status=psd_st)
        if(psd_st==0)save_psd=trim(psd_env)=='1'
        call get_environment_variable('MCPE_PSD_START',psd_env,status=psd_st)
        if(psd_st==0)read(psd_env,*)psd_start
        if(save_psd)open(97,file='spectral_member1.bin',access='stream',form='unformatted',status='replace')
        mse2=0._dp; cr2=0_8''')
e=one(e,'            if(i>rss.and.i<=ree)then','''            if(save_psd.and.i>=psd_start.and.mod(i,10_8)==0_8)then
                write(97)real(i,dp)/100._dp,xt(psd_idx),xe(psd_idx,1)
            endif
            if(i>rss.and.i<=ree)then''')
e=one(e,'        if(save_mean)close(94)','        if(save_mean)close(94)\n        if(save_psd)close(97)')
write('exp21_new.f90',e)
for name in ['times.ttf','plot_corrected.py','original_plot_psd_v10v7.py']:
    shutil.copy2(PSD/name,B/name)
# Keep exact PSD transformation and full-window sampling. Only the old main factor is plotted.
s=(PSD/'spectra.py').read_text();s=s[:s.index('def postprocess():')];s=s.replace('FACTORS=[1,4,8]','FACTORS=[1]')
write('spectra.py',s)
s=(OLD/'plot_c80_15figs.py').read_text();s=one(s,'NS = list(range(6, 21))','NS = [12,15,18,21,24,27,30]');write('plot_rmse.py',s)
s=(OLD/'plot_corr_c79.py').read_text();s=one(s,'NS = list(range(7, 21))','NS = [15,18,21,24,27,30]')
s=s.replace("S6/seed{s}/rmse_M06", "S12/seed{s}/rmse_M12").replace('MCPE7-20','MCPE15-30').replace('MCPE6','MCPE12').replace('vs M6','vs M12')
write('plot_corr.py',s)
write('实验说明.md','''# 同步版七方案四类图

用户已选择同步入场，方案为MCPE12/15/18/21/24/27/30，即三组各4至10个名额。共享参数仍只保留一套集合，同名次Catm/Cocean与ALK参数同时开启各自通道；不同名次共享参数各自到时开启，不重置集合。周期和观测均不变。

RMSE：7张原七柱图，CTL、CDA5、CDA7、CDA8、MCPE5obs、MCPE7obs、MCPE8obs；窗口(90000,100000] TU逐step，全部10seed。
修正率：3张，5/7/8obs各一张，以新起始MCPE12为基准，逐seed计算百分比后均值。
功率谱：7张，各方案分别对比CTL、Truth、CDA8；沿用[100000,150000] TU、固定成员1、逐seed计算后10seed平均；原主图Welch分段、频率倍率和坐标窗口均不变。持续同化与参数估计到150000 TU，不冻结参数。慢变量保留真实8个频率点，不插值。
参数均值：7张8obs图，0–100000 TU，每100 TU记录，10seed集合均值/真值，无时间平滑；共享参数仅画一次，但标出不同通道的入场线。

24张主图，英文Times New Roman、PNG，不生成PDF。旧代码和图不覆盖。
5/7obs缺少的通道不启用、不压缩其他组入场时刻。初始集合统一top22，全部33个非固定参数10%偏置，top22额外5%高斯扰动。

生产共210次：7方案×3观测系统×10seed，其中70次8obs跑到150000 TU并输出谱；140次5/7obs跑到100000 TU。复用经匹配验证的CTL/CDA基线。原五方案8obs的90000–100000 TU RMSE和前100000 TU参数均值须逐字节/逐值复现后才接受新结果。
''')
files=[p for p in B.iterdir() if p.suffix in ['.py','.f90','.json','.md','.ttf'] and p.name!='manifest.json']
write('manifest.json',json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
print('SEVEN_SYNC_PREPARED')
