# plot_corr_c79.py — C-80 修正率（C-79 修订版） vs MCPE12（14 柱 M7-M20）
import os
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from pathlib import Path

ROOT = Path(__file__).resolve().parent
R = Path(os.environ.get('MCPE_RESULTS_DIR', str(ROOT / 'results_C80')))
FIGD = Path(os.environ.get('MCPE_FIGURES_DIR', str(R / 'figures')))
FIGD.mkdir(parents=True, exist_ok=True)
TAG = os.environ.get('MCPE_TAG', 'C80')
LABEL = os.environ.get('MCPE_LABEL', 'C-80')
TITLE_TEMPLATE = os.environ.get('MCPE_CORR_TITLE_TEMPLATE')
VARS = ['x1','x2','x3','w','eta','ice','TL','Catm','Cocean','ALK']
NS = [15,18,21,24,27,30]   # 14 柱 M7-M20

def load(p):
    f = Path(p)
    if f.exists(): return np.loadtxt(f)
    return None

M6 = np.full((3, 10, 10), np.nan)                      # [g, var, seed]
for g, v in enumerate([4, 5, 6]):
    for s in range(10):
        r6 = load(str(R / f'S12/seed{s}/rmse_M12_v0{v}.txt'))
        if r6 is not None: M6[g, :, s] = r6

corr = np.full((3, len(NS), 10, 10), np.nan)           # [g, nidx, var, seed] %
for g, v in enumerate([4, 5, 6]):
    for s in range(10):
        if np.isnan(M6[g, 0, s]): continue
        for ni, n in enumerate(NS):
            rn = load(str(R / f'S{n}/seed{s}/rmse_M{n:02d}_v0{v}.txt'))
            if rn is None: continue
            corr[g, ni, :, s] = (M6[g, :, s] - rn) / M6[g, :, s] * 100.0

OBS = {4: 5, 5: 7, 6: 8}
FNAME = {4: f'rate_{TAG}_MCPE15-30_5obs.png', 5: f'rate_{TAG}_MCPE15-30_7obs.png', 6: f'rate_{TAG}_MCPE15-30_8obs.png'}

def nice_step(span):
    if span <= 0: return 1.0
    raw = span / 5.0
    exp = np.floor(np.log10(raw))
    base = raw / 10**exp
    for m in (1.0, 2.5, 5.0, 10.0):
        if base <= m + 1e-12:
            return m * 10**exp
    return 10.0 * 10**exp

for g, v in enumerate([4, 5, 6]):
    fig, axes = plt.subplots(2, 5, figsize=(13, 8), sharex=False)
    for j in range(10):
        ax = axes[j // 5, j % 5]
        m = np.nanmean(corr[g, :, j, :], axis=1)
        xx = np.arange(len(NS))
        lo0 = min(0.0, np.floor(np.nanmin(m)))
        hi0 = max(0.0, np.ceil(np.nanmax(m)))
        step = nice_step(hi0 - lo0)
        lo = np.floor(lo0 / step) * step
        hi = np.ceil(hi0 / step) * step
        ax.set_ylim(lo - 0.65 * step, hi + 0.65 * step)
        ax.yaxis.set_major_locator(mticker.MultipleLocator(step))
        for x, vv in zip(xx, m):
            color = '#C44E52' if vv < 0 else '#4C72B0'
            ax.bar(x, vv, width=0.78, color=color, edgecolor='k', lw=0.4, alpha=0.9, zorder=3)
            if vv >= 0:
                ax.text(x, vv + 0.03 * step, f'{vv:.1f}', ha='center',
                        va='bottom', fontsize=5.5, zorder=4)
            else:
                ax.text(x, vv - 0.03 * step, f'{vv:.1f}', ha='center',
                        va='top', fontsize=5.5, zorder=4)
        ax.axhline(0, color='k', lw=1)
        ax.set_title(VARS[j], fontsize=10)
        ax.set_xticks(xx)
        ax.set_xticklabels([f'{n}' for n in NS], fontsize=6, fontstretch='condensed')
        ax.tick_params(axis='x', pad=2, length=2, width=0.6)
        ax.set_xlim(-0.6, len(NS) - 0.4)
        ax.grid(alpha=0.3, axis='y')
        if j == 0: ax.set_ylabel('Correction rate vs M12 (%)', fontsize=10)
        if j >= 5: ax.set_xlabel('MCPE scheme', fontsize=8)
    title = (TITLE_TEMPLATE.format(obs=OBS[v]) if TITLE_TEMPLATE
             else f'RMSE correction rate vs MCPE12 ({LABEL}, {OBS[v]}obs)')
    fig.suptitle(title, fontweight='bold', fontsize=13)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(FIGD / FNAME[v], dpi=300)
    print('Saved', FNAME[v])

# ============ 修正率表（%）：含 CDA5 参照行 ============
print('\n==== 修正率表（%, 10 seed 均值；= (M6-RMSE)/M6*100，正=比 M6 好） ====')
for gi, (v, vtag) in enumerate(((4, '5obs'), (5, '7obs'), (6, '8obs'))):
    M6_cur = M6[gi]
    print(f'--- {vtag} ---')
    print('method   ' + ' '.join(f'M{n:2d}' for n in NS))
    rows = []
    for s in range(10):
        c5 = load(str(R / f'CDA/seed{s}/rmse_M20_v01.txt'))
        if c5 is None or np.isnan(M6_cur[0, s]): continue
        rows.append((M6_cur[:, s] - c5) / M6_cur[:, s] * 100.0)
    m = np.mean(rows, axis=0)
    print('  CDA5 ' + ' '.join(f'{m[j]:7.1f}' for j in range(10)) + f'  mean={m.mean():.1f}')
    for ni, n in enumerate(NS):
        m = np.nanmean(corr[gi, ni], axis=1)
        print(f'M{n:>5d} ' + ' '.join(f'{m[j]:7.1f}' for j in range(10)) + f'  mean={np.nanmean(m):.1f}')
    print()
