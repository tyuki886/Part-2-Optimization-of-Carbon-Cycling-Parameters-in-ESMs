"""Local image/provenance verification; publish only after explicit visual-QA receipt."""
from pathlib import Path
import json,hashlib,sys,shutil
import numpy as np
from PIL import Image,ImageOps,ImageDraw
B=Path(__file__).resolve().parent
DEST=Path('D:/SRDP/论文大作！/MCPE26.0/9.2/同步MCPE12-30_七方案四类图_20260913')
def verify():
    meta=json.loads((B/'delivery.json').read_text());summary=json.loads((B/'summary.json').read_text());cfg=json.loads((B/'config.json').read_text())
    assert len(meta['images'])==24
    for group,count in [('RMSE',7),('correction_rate',3),('power_spectra',7),('parameter_means',7)]:
        names=[n for n in meta['images'] if n.startswith(group+'/')];assert len(names)==count
        for n in names:
            p=B/'figures'/n;info=meta['images'][n]
            assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
            with Image.open(p) as im:im.verify()
        qa=B/'visual_qa';qa.mkdir(exist_ok=True)
        sheet=Image.new('RGB',(1800,600*int(np.ceil(count/2))),'white');draw=ImageDraw.Draw(sheet)
        for k,n in enumerate(names):
            with Image.open(B/'figures'/n) as im:
                tile=ImageOps.contain(im.convert('RGB'),(890,560))
                x=(k%2)*900;y=(k//2)*600
                sheet.paste(tile,(x+(900-tile.width)//2,y+30));draw.text((x+8,y+8),Path(n).name,fill='black')
        sheet.save(qa/(group+'.png'))
    for k,a in summary['RMSE_per_seed'].items():
        a=np.array(a);assert a.shape==(10,10) and np.isfinite(a).all() and (a>=0).all()
        np.testing.assert_allclose(a.mean(0),summary['RMSE_mean'][k],atol=1e-14,rtol=0)
    old=json.loads((B.parent/'entry_timing_balanced_20260913/summary.json').read_text())
    for n in [12,15,18,21,24]:
        np.testing.assert_array_equal(summary['RMSE_per_seed'][f'M{n}_v6'],old['results']['sync'][str(n)]['per_seed'])
    psd=json.loads((B/'figures/power_spectra/plot_data.json').read_text())
    for var,d in psd.items():
        f=np.array(d['frequency']);assert (np.diff(f)>0).all()
        if var in ['Cocean','ALK']:assert len(f)==8
        for k,v in d.items():assert len(v)==len(f) and np.isfinite(v).all() and (np.array(v)>=0).all()
    z=np.load(B/'figures/parameter_means/plot_source_arrays.npz')
    for n in cfg['schemes']:
        assert z[f'M{n}_seed_means'].shape==(10,1001,45)
        assert np.isfinite(z[f'M{n}_seed_means']).all()
    (B/'LOCAL_VALIDATION_PASS').write_text('24 image hashes, exact original five-scheme RMSE replay, all mean computations, 7 spectra and parameter arrays checked.\n')
    print('LOCAL_VALIDATION_PASS',flush=True)
def publish():
    assert (B/'LOCAL_VALIDATION_PASS').exists() and (B/'VISUAL_QA_PASS.md').exists()
    meta=json.loads((B/'delivery.json').read_text())
    for name,info in meta['images'].items():
        src=B/'figures'/name;target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True)
        assert hashlib.sha256(src.read_bytes()).hexdigest()==info['sha256']
        if target.exists():assert hashlib.sha256(target.read_bytes()).hexdigest()==info['sha256']
        else:shutil.copyfile(src,target)
    (B/'PUBLISHED').write_text(str(DEST)+'\n')
    print('PUBLISHED_24_PNG',DEST,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='verify':verify()
    elif sys.argv[1]=='publish':publish()
