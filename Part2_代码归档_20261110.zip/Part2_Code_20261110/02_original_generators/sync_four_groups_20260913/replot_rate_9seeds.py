"""User-requested, post-hoc seed-3 exclusion. Preserve MCPE12 baseline and original mean-of-rates formula."""
from pathlib import Path
import json,hashlib
from decimal import Decimal,getcontext
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from PIL import Image
import plot_corrected as style
B=Path(__file__).resolve().parent;O=B/'figures'/'correction_rate_9seeds';O.mkdir(exist_ok=True)
style.configure_font(B)
P=B/'summary.json';h=hashlib.sha256(P.read_bytes()).hexdigest();data=json.loads(P.read_text())['RMSE_per_seed']
RAW=B/'correction_audit'/'raw_rmse.json';rows=json.loads(RAW.read_text());receipt=json.loads((B/'delivery.json').read_text())
expected={r['path']:r['sha256'] for r in receipt['receipts']}
getcontext().prec=40
NS=[15,18,21,24,27,30];KEEP=[0,1,2,4,5,6,7,8,9]
VARS=['x1','x2','x3','w','eta','ice','TL','Catm','Cocean','ALK'];values={}
for r in rows:
    if r['variant']!=6 or r['scheme'] not in [12]+NS:continue
    assert r['sha256']==expected[r['path']]
    assert hashlib.sha256(r['text'].encode()).hexdigest()==r['sha256']
    a=[Decimal(x) for x in r['text'].split()];assert len(a)==10
    np.testing.assert_array_equal([float(x) for x in a],data[f"M{r['scheme']}_v6"][r['seed']])
    values[r['scheme'],r['seed']]=a
assert len(values)==70
def rates(seeds):
    return np.array([[float(sum((values[12,s][j]-values[n,s][j])/values[12,s][j]*100 for s in seeds)/len(seeds)) for j in range(10)] for n in NS])
old=rates(list(range(10)));new=rates(KEEP)
def nice_step(span):
    if span<=0:return 1.
    raw=span/5.;exp=np.floor(np.log10(raw));base=raw/10**exp
    for m in [1.,2.5,5.,10.]:
        if base<=m+1e-12:return m*10**exp
fig,axes=plt.subplots(2,5,figsize=(13,8),sharex=False)
for j,ax in enumerate(axes.flat):
    m=new[:,j];xx=np.arange(len(NS));lo0=min(0.,np.floor(m.min()));hi0=max(0.,np.ceil(m.max()));step=nice_step(hi0-lo0)
    ax.set_ylim(np.floor(lo0/step)*step-.65*step,np.ceil(hi0/step)*step+.65*step)
    ax.yaxis.set_major_locator(mticker.MultipleLocator(step))
    for x,v in zip(xx,m):
        ax.bar(x,v,width=.78,color='#C44E52' if v<0 else '#4C72B0',edgecolor='k',lw=.4,alpha=.9,zorder=3)
        ax.text(x,v+(.03*step if v>=0 else -.03*step),f'{v:.1f}',ha='center',va='bottom' if v>=0 else 'top',fontsize=5.5,zorder=4)
    np.testing.assert_allclose([b.get_height() for b in ax.patches],m,rtol=0,atol=1e-12)
    ax.axhline(0,color='k',lw=1);ax.set_title(f'({chr(97+j)}) {VARS[j]}',fontsize=10);ax.set_xticks(xx)
    ax.set_xticklabels([str(n) for n in NS],fontsize=6,fontstretch='condensed');ax.tick_params(axis='x',pad=2,length=2,width=.6)
    ax.set_xlim(-.6,len(NS)-.4);ax.grid(alpha=.3,axis='y')
    if j==0:ax.set_ylabel('Correction rate vs M12 (%)',fontsize=10)
    if j>=5:ax.set_xlabel('MCPE scheme',fontsize=8)
fig.suptitle('RMSE correction rate vs MCPE12 (8obs)',fontweight='bold',fontsize=13)
fig.tight_layout(rect=[0,.045,1,.96]);fig.canvas.draw();renderer=fig.canvas.get_renderer()
assert [a.get_title() for a in axes.flat]==[f'({chr(97+j)}) {v}' for j,v in enumerate(VARS)]
for a in axes.flat:
    for t in a.texts:
        bb=t.get_window_extent(renderer);assert bb.x0>=0 and bb.y0>=0 and bb.x1<=fig.bbox.x1 and bb.y1<=fig.bbox.y1
p=O/'rate_sync_MCPE15-30_8obs_9seeds.png';fig.savefig(p,dpi=300);plt.close(fig)
with Image.open(p) as im:assert im.size==(3900,2400)
assert hashlib.sha256(P.read_bytes()).hexdigest()==h
audit={'retained_seeds':KEEP,'excluded_seeds':[3],'baseline':'MCPE12','formula':'mean_s[100*(RMSE_MCPE12_s-RMSE_scheme_s)/RMSE_MCPE12_s]','window_TU':[90000,100000],'post_hoc':True,'original_files_unchanged':True,'source_sha256':{str(P):h,str(RAW):hashlib.sha256(RAW.read_bytes()).hexdigest()},'schemes':NS,'variables':VARS,'old_10seed_rates':old.tolist(),'new_9seed_rates':new.tolist(),'all_60_bars_verified':True}
(O/'audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(p)
print('MCPE15 Cocean: old rate',old[0,8],'new rate',new[0,8])
for n in [12,15]:
    a=np.array(data[f'M{n}_v6'])[:,8];print(n,'mean RMSE 10seed',a.mean(),'9seed',a[KEEP].mean())
