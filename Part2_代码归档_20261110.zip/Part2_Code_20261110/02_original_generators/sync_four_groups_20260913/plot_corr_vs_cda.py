"""CDA5/7/8 reference, percentage reduction of mean RMSE; preserve original bar layout."""
from pathlib import Path
from decimal import Decimal, getcontext
import hashlib, json, sys, getpass
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib import font_manager
from PIL import Image

B = Path(__file__).resolve().parent
OUT = B / 'figures' / 'correction_rate_vs_CDA_meanRMSE'
AUDIT = B / 'correction_audit'
NS = [12, 15, 18, 21, 24, 27, 30]
VARS = ['x1','x2','x3','w','eta','ice','TL','Catm','Cocean','ALK']
GROUPS = [(5,4,1), (7,5,2), (8,6,3)]
getcontext().prec = 40

def fetch_baselines():
    import paramiko
    receipt = json.loads((B/'delivery.json').read_text())
    rows = [r for r in receipt['receipts'] if r['scheme']==22 and r['variant'] in [1,2,3]]
    assert len(rows)==30
    code = "from pathlib import Path\nimport json,hashlib\nrows="+repr(rows)+"\nfor r in rows:\n p=Path(r['path']);d=p.parent\n assert (d/'READY').exists() and not (d/'FAILED').exists()\n raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256']\n r['text']=raw.decode();r['scalars']=(d/'audit_scalars.txt').read_text()\nprint(json.dumps(rows))\n"
    c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
    try:
        _,o,e=c.exec_command("/public/home/hou/miniconda3/envs/yuki/bin/python - <<'CHECKPY'\n"+code+"CHECKPY",timeout=60)
        stdout=o.read().decode();stderr=e.read().decode();assert o.channel.recv_exit_status()==0,stderr
        result=json.loads(stdout);assert len(result)==30
        (AUDIT/'raw_cda_rmse.json').write_text(json.dumps(result,indent=2))
        print('Verified and fetched 30 original CDA RMSE files.')
    finally:c.close()

def nice_step(span):
    if span<=0:return 1.0
    raw=span/5.0;exp=np.floor(np.log10(raw));base=raw/10**exp
    for m in (1.,2.5,5.,10.):
        if base<=m+1e-12:return m*10**exp
    return 10.*10**exp

def main():
    summary=json.loads((B/'summary.json').read_text())
    assert summary['schemes']==NS and summary['all_seeds_retained'] is True
    assert summary['RMSE_window_TU']==[90000,100000]
    receipts={r['path']:r['sha256'] for r in json.loads((B/'delivery.json').read_text())['receipts']}
    raw=json.loads((AUDIT/'raw_rmse.json').read_text())+json.loads((AUDIT/'raw_cda_rmse.json').read_text())
    assert len(raw)==240
    exact={}
    for row in raw:
        n,v,s=row['scheme'],row['variant'],row['seed'];key=n,v,s
        assert key not in exact and s in range(10)
        assert hashlib.sha256(row['text'].encode()).hexdigest()==row['sha256']==receipts[row['path']]
        vals=[Decimal(x) for x in row['text'].split()]
        assert len(vals)==10 and all(x.is_finite() and x>0 for x in vals)
        expected_steps=15000000 if v==6 else 10000000
        assert list(map(int,row['scalars'].splitlines()[0].split()))==[expected_steps,9000000,10000000,1000000,0]
        np.testing.assert_allclose([float(x) for x in vals],summary['RMSE_per_seed'][f'M{n}_v{v}'][s],rtol=0,atol=1e-14)
        exact[key]=vals
    OUT.mkdir(exist_ok=True)
    font_manager.fontManager.addfont(str(B/'times.ttf'))
    font_manager.findfont('Times New Roman',fallback_to_default=False)
    plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'mathtext.fontset':'stix',
        'axes.titlesize':13,'axes.labelsize':11,'xtick.labelsize':10,'ytick.labelsize':10,
        'axes.linewidth':.8,'savefig.facecolor':'white','figure.facecolor':'white'})
    report={'formula':'100 * (mean_seed(RMSE_CDA) - mean_seed(RMSE_MCPE)) / mean_seed(RMSE_CDA)',
        'window_TU':[90000,100000],'interval':'(90000,100000]','samples_per_seed':1000000,
        'seeds':list(range(10)),'baseline_mapping':{'5obs':'CDA5','7obs':'CDA7','8obs':'CDA8'},
        'raw_files_verified':240,'values':[],'images':{},'legacy_images_unchanged':True,
        'independent_panel_scales':True,'uncertainty':'No error bars, following the established figure format.'}
    for obs,v,cv in GROUPS:
        base=np.array(summary['RMSE_per_seed'][f'M22_v{cv}']);assert base.shape==(10,10)
        baseline=base.mean(axis=0)
        test=np.array([summary['RMSE_per_seed'][f'M{n}_v{v}'] for n in NS]);assert test.shape==(7,10,10)
        means=test.mean(axis=1)
        rates=100*(baseline[None,:]-means)/baseline[None,:]
        np.testing.assert_allclose(baseline,summary['RMSE_mean'][f'M22_v{cv}'],rtol=0,atol=1e-14)
        fig,axes=plt.subplots(2,5,figsize=(13,8),sharex=False)
        for j,ax in enumerate(axes.flat):
            m=rates[:,j];xx=np.arange(len(NS))
            lo0=min(0.,np.floor(m.min()));hi0=max(0.,np.ceil(m.max()))
            step=nice_step(hi0-lo0);lo=np.floor(lo0/step)*step;hi=np.ceil(hi0/step)*step
            ax.set_ylim(lo-.65*step,hi+.65*step);ax.yaxis.set_major_locator(mticker.MultipleLocator(step))
            for x,n,vv in zip(xx,NS,m):
                db=sum(exact[22,cv,s][j] for s in range(10))/10
                dm=sum(exact[n,v,s][j] for s in range(10))/10
                independent=100*(db-dm)/db
                assert abs(float(independent)-vv)<1e-10
                bar=ax.bar(x,vv,width=.78,color='#C44E52' if vv<0 else '#4C72B0',edgecolor='k',lw=.4,alpha=.9,zorder=3)[0]
                assert abs(bar.get_height()-float(independent))<1e-10
                shown=0. if abs(vv)<.05 else vv
                ax.text(x,vv+(.03 if vv>=0 else -.03)*step,f'{shown:.1f}',ha='center',va='bottom' if vv>=0 else 'top',fontsize=5.5,zorder=4)
                report['values'].append({'obs':obs,'baseline':f'CDA{obs}','scheme':n,'variable':VARS[j],
                    'baseline_mean_RMSE':str(db),'scheme_mean_RMSE':str(dm),'rate_percent':str(independent),'actual_bar':float(bar.get_height())})
            ax.axhline(0,color='k',lw=1);ax.set_title(VARS[j],fontsize=10)
            ax.set_xticks(xx);ax.set_xticklabels([str(n) for n in NS],fontsize=6,fontstretch='condensed')
            ax.tick_params(axis='x',pad=2,length=2,width=.6);ax.set_xlim(-.6,len(NS)-.4);ax.grid(alpha=.3,axis='y')
            if j==0:ax.set_ylabel(f'Correction rate vs CDA{obs} (%)',fontsize=10)
            if j>=5:ax.set_xlabel('MCPE scheme',fontsize=8)
        fig.suptitle(f'RMSE correction rate vs CDA{obs} ({obs}obs)',fontweight='bold',fontsize=13)
        fig.tight_layout(rect=[0,0,1,.96]);fig.canvas.draw();renderer=fig.canvas.get_renderer()
        for ax in axes.flat:
            for labels in [ax.get_xticklabels(),ax.texts]:
                boxes=[t.get_window_extent(renderer) for t in labels]
                assert all(not a.overlaps(b) for i,a in enumerate(boxes) for b in boxes[i+1:]),'Overlapping labels'
            for t in ax.texts:
                bb=t.get_window_extent(renderer);assert fig.bbox.contains(bb.x0,bb.y0) and fig.bbox.contains(bb.x1,bb.y1)
        path=OUT/f'rate_sync_MCPE12-30_vs_CDA{obs}_{obs}obs.png'
        fig.savefig(path,dpi=300);plt.close(fig)
        with Image.open(path) as im:im.verify()
        with Image.open(path) as im:assert im.size==(3900,2400)
        report['images'][path.name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':[3900,2400],'bars_checked':70}
        print('Saved',path.name)
    assert len(report['values'])==210
    for name,info in json.loads((B/'delivery.json').read_text())['images'].items():
        assert hashlib.sha256((B/'figures'/name).read_bytes()).hexdigest()==info['sha256']
    (AUDIT/'cda_reference_redraw.json').write_text(json.dumps(report,indent=2))
    print('PASS: 240 original RMSE files, 210 bars, 3 PNGs; all original 24 PNGs unchanged.')

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='fetch':fetch_baselines()
    else:main()
