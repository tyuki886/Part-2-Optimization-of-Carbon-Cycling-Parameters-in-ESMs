"""Seven 2x5 RMSE time-series figures, seven methods each, all ten seeds."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
B=Path(__file__).resolve().parent;P=B.parent;sys.path.insert(0,str(P))
import plot_corrected as plot
from process_task import TASKS,SCHEMES
VARS=['x1','x2','x3','w','eta','ice','TL','Catm','Cocean','ALK']
LABELS=['CTL','CDA5','CDA7','CDA8','MCPE-5obs','MCPE-7obs','MCPE-8obs']
COLORS=['#777777','#0072B2','#009E73','#8E44AD','#E69F00','#D55E00','#B2182B']
LINES=['-','--','--','--','-','-','-']
def main():
    out=B/'figures';out.mkdir(exist_ok=True);data={};receipts=[]
    for n,v,s in TASKS:
        d=B/'runs'/f'M{n}_v{v}'/f'seed{s}';assert (d/'READY').exists() and not (d/'FAILED').exists()
        a=np.load(d/'process_rmse.npz');assert a['rmse'].shape==(100,10) and np.isfinite(a['rmse']).all()
        np.testing.assert_array_equal(a['start_TU'],np.arange(0,100000,1000));np.testing.assert_array_equal(a['end_TU'],np.arange(1000,100001,1000))
        data[n,v,s]=a['rmse'];receipts.append(json.loads((d/'audit.json').read_text()))
    means={(n,v):np.mean([data[n,v,s] for s in range(10)],axis=0) for n,v,s in TASKS}
    for n,v in means:np.testing.assert_allclose(means[n,v],sum(data[n,v,s] for s in range(10))/10,rtol=1e-14,atol=1e-15)
    cfg=json.loads((P/'config.json').read_text());plot.configure_font(P)
    metadata={'window_TU':[0,100000],'RMSE_bin_TU':1000,'bin_samples':100000,'seeds':list(range(10)),
        'formula':'mean_seed(sqrt(mean_native_step((ensemble_mean - truth)^2))) within each non-overlapping 1000-TU bin',
        'x_position':'window midpoint','images':{},'runs_verified':250}
    t=np.arange(500,100000,1000)
    for n in SCHEMES:
        keys=[(22,v) for v in range(4)]+[(n,v) for v in [4,5,6]]
        fig,axes=plt.subplots(2,5,figsize=(22,10));count=0
        end=max(slot['entry_TU'] for slot in cfg['configs']['sync'][str(n)]['slots'])
        for j,ax in enumerate(axes.flat):
            for i,key in enumerate(keys):
                y=means[key][:,j]
                ln,=ax.plot(t,y,color=COLORS[i],ls=LINES[i],lw=1.4,label=LABELS[i])
                np.testing.assert_array_equal(ln.get_ydata(),np.mean([data[key[0],key[1],s][:,j] for s in range(10)],axis=0));count+=1
            for pos in [10000,20000,end]:ax.axvline(pos,color='#999999',ls=':',lw=.65,zorder=0)
            ax.set(title=VARS[j],xlabel='Time (TU)',ylabel='RMSE',xlim=(0,100000),ylim=(0,None))
            ax.set_xticks([0,20000,40000,60000,80000,100000]);ax.tick_params(axis='x',labelsize=8);ax.grid(alpha=.2)
        fig.suptitle(f'MCPE{n} RMSE evolution',fontsize=18,y=.99)
        fig.legend(handles=[Line2D([],[],color=c,ls=l,lw=1.7,label=name) for c,l,name in zip(COLORS,LINES,LABELS)],loc='upper center',bbox_to_anchor=(.5,.957),ncol=7,frameon=False,fontsize=12)
        fig.text(.5,.022,'1000-TU non-overlapping windows | All native 0.01-TU steps | Mean RMSE over 10 seeds | Points at window midpoints',ha='center',fontsize=11)
        fig.text(.5,.006,f'Dotted lines: state assimilation begins (10000 TU), parameter estimation begins (20000 TU), last channel entry ({end:g} TU).',ha='center',fontsize=10)
        fig.tight_layout(rect=(0,.045,1,.915));assert count==70
        path=out/f'rmse_time_MCPE{n}_CTL_CDA578_MCPE578.png';fig.savefig(path,dpi=300);plt.close(fig)
        with Image.open(path) as im:im.verify()
        metadata['images'][path.name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'lines_checked':count,'size':[6600,3000]}
        print('FIGURE_READY',n,flush=True)
    np.savez_compressed(B/'plot_arrays.npz',time_TU=t,**{f'M{n}_v{v}':a for (n,v),a in means.items()})
    (B/'delivery.json').write_text(json.dumps(metadata,indent=2));(B/'FIGURES_READY').write_text('7 PNGs, 490 lines checked; visual QA pending.\n')
if __name__=='__main__':main()
