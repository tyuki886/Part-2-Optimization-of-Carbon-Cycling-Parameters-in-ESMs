"""Restore the established yuki dependency path in this diagnostic job only."""
import getpass,paramiko
R='/public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913/rmse_time_20260913'
deps='/public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913:/public/home/hou/wyh/MCPE26.0/twin_work_3x3/python_deps:/public/home/hou/wyh/MCPE26.0/power_combined/python_deps'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),look_for_keys=False,allow_agent=False,timeout=25)
try:
 with c.open_sftp() as ftp:
  with ftp.open(R+'/logs/TimeRMSECheck.o25558') as f:assert b"ModuleNotFoundError: No module named 'numpy'" in f.read()
  assert 'preflight' not in ftp.listdir(R) and 'PREFLIGHT_PASS' not in ftp.listdir(R)
  for name in ['preflight.pbs','run.pbs','plot.pbs']:
   with ftp.open(R+'/'+name) as f:s=f.read().decode()
   assert 'PYTHONPATH=' not in s
   s=s.replace('export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1','export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1\nexport PYTHONPATH='+deps)
   with ftp.open(R+'/'+name,'w') as f:f.write(s)
  ftp.rename(R+'/preflight_job.txt',R+'/preflight_job_failed_numpy.txt')
 _,o,e=c.exec_command('export PYTHONPATH='+deps+'; /public/home/hou/miniconda3/envs/yuki/bin/python -c "import numpy; print(numpy.__version__)" && cd '+R+'/logs && qsub ../preflight.pbs > ../preflight_job.txt && cat ../preflight_job.txt',timeout=30)
 a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);print(a)
finally:c.close()
