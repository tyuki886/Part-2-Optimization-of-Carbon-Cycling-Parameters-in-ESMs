from pathlib import Path
import getpass,paramiko
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),look_for_keys=False,allow_agent=False,timeout=25)
code='''from pathlib import Path
import json
b=Path('/public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913/rmse_time_20260913')
print('DIRECTORY',[(p.name,p.stat().st_size) for p in b.iterdir()])
for p in list((b/'logs').glob('*'))+list(b.glob('preflight/*/*/run.log'))+list(Path('/public/home/hou').glob('TimeRMSECheck.o25558')):
 print('LOG',str(p),p.read_text()[-8000:])
'''
try:
 _,o,e=c.exec_command("/public/home/hou/miniconda3/envs/yuki/bin/python - <<'CHECKPY'\n"+code+"CHECKPY",timeout=30)
 print(o.read().decode());print(e.read().decode())
 _,o,e=c.exec_command('qstat -f 25558',timeout=30);print(o.read().decode());print(e.read().decode())
finally:c.close()
