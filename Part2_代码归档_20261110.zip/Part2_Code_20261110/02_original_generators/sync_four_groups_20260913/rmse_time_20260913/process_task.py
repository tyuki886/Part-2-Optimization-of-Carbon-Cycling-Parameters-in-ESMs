"""Replay unchanged experiment to record native-step squared-error sums."""
from pathlib import Path
import sys,os,json,subprocess,hashlib,traceback
import numpy as np
B=Path(__file__).resolve().parent;P=B.parent
sys.path.insert(0,str(P))
from task import validate
SCHEMES=[12,15,18,21,24,27,30]
TASKS=[(22,v,s) for v in range(4) for s in range(10)]+[(n,v,s) for n in SCHEMES for v in [4,5,6] for s in range(10)]
def env_for(n,v,s,steps=10000000):
    env={k:v for k,v in os.environ.items() if not k.startswith('MCPE_')}
    env.update(MCPE_SCHEME=str(n),MCPE_VARIANT=str(v),MCPE_SEED=str(s),MCPE_ENTRY_ARM='sync',
        MCPE_FREQ='1,4,20',MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS=str(steps),
        MCPE_EVAL='9000000' if steps==10000000 else '2000000',MCPE_EVAL_END=str(steps),
        MCPE_SAVE_PARAM_MEAN='1',MCPE_PSD='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    if steps!=10000000:env['MCPE_SMOKE']='1'
    return env
def execute(exe,d,env):
    d.mkdir(parents=True,exist_ok=False)
    with (d/'run.log').open('w') as out:
        p=subprocess.run([str(exe)],cwd=d,env=env,stdout=out,stderr=subprocess.STDOUT)
    (d/'execution.json').write_text(json.dumps({'returncode':p.returncode,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}))
    assert p.returncode==0,(p.returncode,str(d))
def bins(d,steps):
    a=np.loadtxt(d/'process_mse_10TU.txt');assert a.shape==(steps//1000,13) and np.isfinite(a).all()
    np.testing.assert_array_equal(a[:,0],np.arange(0,steps,1000))
    np.testing.assert_array_equal(a[:,1],np.arange(1000,steps+1,1000))
    np.testing.assert_array_equal(a[:,2],np.full(steps//1000,1000))
    assert (a[:,3:]>=0).all()
    return a
def preflight():
    for n,v,s in [(22,3,0),(30,6,0)]:
        env=env_for(n,v,s,2500000);env['MCPE_CHECKPOINT']='checkpoint.txt'
        a=B/'preflight'/f'M{n}_v{v}'/'original';b=a.parent/'diagnostic'
        execute(P/'exp21_new',a,env);execute(B/'exp21_process',b,env)
        for name in ['checkpoint.txt','initial_parameters.txt','final_parameters.txt','parameter_updates.txt','parameter_mean.txt',f'rmse_M{n:02d}_v{v:02d}.txt']:
            assert (a/name).read_bytes()==(b/name).read_bytes(),name
        z=bins(b,2500000)
        np.testing.assert_allclose(np.sqrt(z[2000:,3:].sum(0)/500000),np.loadtxt(b/f'rmse_M{n:02d}_v{v:02d}.txt'),rtol=0,atol=5.1e-8)
        print('PREFLIGHT_EXACT_MATCH',n,v,flush=True)
    (B/'PREFLIGHT_PASS').write_text('Original and diagnostic checkpoints/parameters/RMSE match exactly after 25000 TU.\n')
def run(tid):
    assert (B/'PREFLIGHT_PASS').exists()
    n,v,s=TASKS[tid];d=B/'runs'/f'M{n}_v{v}'/f'seed{s}'
    execute(B/'exp21_process',d,env_for(n,v,s))
    try:
        audit=validate(d,n,v,s,10000000,9000000,10000000)
        receipts=json.loads((P/'delivery.json').read_text())['receipts']
        record=next(r for r in receipts if r['scheme']==n and r['variant']==v and r['seed']==s)
        ref=Path(record['path']);assert hashlib.sha256(ref.read_bytes()).hexdigest()==record['sha256']
        assert (d/ref.name).read_bytes()==ref.read_bytes(),'Final RMSE not reproduced'
        original_mean=ref.parent/'parameter_mean.txt'
        if original_mean.exists():np.testing.assert_array_equal(np.loadtxt(d/'parameter_mean.txt'),np.loadtxt(original_mean)[:1001])
        if v!=6:assert (d/'final_parameters.txt').read_bytes()==(ref.parent/'final_parameters.txt').read_bytes()
        a=bins(d,10000000)
        np.testing.assert_allclose(np.sqrt(a[9000:,3:].sum(0)/1000000),np.loadtxt(ref),rtol=0,atol=5.1e-8)
        grouped=a[:,3:].reshape(100,100,10).sum(1)/100000
        np.savez_compressed(d/'process_rmse.npz',start_TU=np.arange(0,100000,1000),end_TU=np.arange(1000,100001,1000),
            mse=grouped,rmse=np.sqrt(grouped),seed=s)
        audit.update(original_RMSE_exact_match=True,native_dt_TU=.01,storage_bin_TU=10,figure_window_TU=1000,
            samples_per_figure_window=100000,windows=100,source_rmse=str(ref),squared_error_sha256=hashlib.sha256((d/'process_mse_10TU.txt').read_bytes()).hexdigest())
        (d/'audit.json').write_text(json.dumps(audit,indent=2));(d/'READY').write_text('Validated original match and all RMSE windows.\n')
        print('READY',tid,n,v,s,flush=True)
    except Exception as e:(d/'FAILED').write_text(repr(e));raise
if __name__=='__main__':
    try:
        if sys.argv[1]=='preflight':preflight()
        else:run(int(sys.argv[1]))
    except Exception:traceback.print_exc();sys.exit(1)
