"""Scoped diagnostic replay orchestration. Never overwrite original experiments."""
from pathlib import Path
import paramiko,getpass,sys,json,time,hashlib
B=Path(__file__).resolve().parent
P='/public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913';R=P+'/'+B.name
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
def cmd(s):
    _,o,e=c.exec_command(s,timeout=120);a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);return a
def pbs(name,action):
    return f'''#!/bin/bash
#PBS -N {name}
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=02:00:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
{PY} {action}
'''
def advance():
    code='from pathlib import Path;import json;b=Path('+repr(R)+');print(json.dumps(dict(preflight=(b/"PREFLIGHT_PASS").exists(),production=(b/"production_job.txt").read_text().strip() if (b/"production_job.txt").exists() else None,ready=len(list(b.glob("runs/*/*/READY"))),failed=[str(p) for p in b.glob("runs/*/*/FAILED")],post=(b/"post_job.txt").read_text().strip() if (b/"post_job.txt").exists() else None,complete=(b/"FIGURES_READY").exists())))'
    state=json.loads(cmd(f"{PY} - <<'STATEPY'\n{code}\nSTATEPY"))
    if state['failed']:raise RuntimeError(state)
    if state['preflight'] and not state['production']:
        print('PRODUCTION',cmd(f'cd {R}/logs && qsub -t 0-249%10 ../run.pbs > ../production_job.txt && cat ../production_job.txt'),flush=True)
    if state['ready']==250 and not state['post']:
        print('POST',cmd(f'cd {R}/logs && qsub ../plot.pbs > ../post_job.txt && cat ../post_job.txt'),flush=True)
    if state['complete']:
        with c.open_sftp() as ftp:
            for name in ['delivery.json','PREFLIGHT_PASS','FIGURES_READY','preflight_job.txt','production_job.txt','post_job.txt','plot_arrays.npz']:
                ftp.get(R+'/'+name,str(B/name))
            m=json.loads((B/'delivery.json').read_text());(B/'figures').mkdir(exist_ok=True)
            for name,info in m['images'].items():
                p=B/'figures'/name;ftp.get(R+'/figures/'+name,str(p));assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
        print('DOWNLOADED_7_RMSE_TIME_PNG',flush=True)
    return state
try:
    if sys.argv[1]=='deploy':
        cmd(f'test ! -e {R} && mkdir -p {R}/logs')
        manifest={}
        with c.open_sftp() as ftp:
            for name in ['exp21_process.f90','process_task.py','plot_process.py']:
                manifest[name]=hashlib.sha256((B/name).read_bytes()).hexdigest();ftp.put(str(B/name),R+'/'+name)
            for name,label,action in [('preflight.pbs','TimeRMSECheck','process_task.py preflight'),('run.pbs','TimeRMSE','process_task.py "${PBS_ARRAYID:?}"'),('plot.pbs','TimeRMSEPlot','plot_process.py')]:
                with ftp.open(R+'/'+name,'w') as f:f.write(pbs(label,action))
        code='import pathlib,hashlib;m='+repr(manifest)+';assert all(hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest()==h for n,h in m.items())'
        print(cmd(f"cd {R} && {PY} - <<'HASHPY'\n{code}\nHASHPY\ngfortran -O3 -ffree-line-length-none -I.. exp21_process.f90 ../MCPE42_new.o ../RKmethod.o -o exp21_process\n{PY} -m py_compile process_task.py plot_process.py\ncd logs && qsub ../preflight.pbs > ../preflight_job.txt && cat ../preflight_job.txt"),flush=True)
        (B/'manifest.json').write_text(json.dumps(manifest,indent=2))
    elif sys.argv[1] in ['watch','advance']:
        old=None
        for i in range(240 if sys.argv[1]=='watch' else 1):
            state=advance()
            if state!=old:print(json.dumps(state),flush=True);old=state
            if state['complete']:break
            if sys.argv[1]=='watch':time.sleep(10)
    elif sys.argv[1]=='inspect':print(cmd(f'cd {R}; tail -n 20 logs/TimeRMSECheck.o* 2>/dev/null || true; qstat -u hou'),flush=True)
    else:raise ValueError(sys.argv[1])
finally:c.close()
