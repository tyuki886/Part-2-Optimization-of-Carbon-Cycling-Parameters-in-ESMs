"""Whole-record PSD sensitivity check; only segment length changes, no integrations."""
from pathlib import Path
import sys, json, hashlib
B=Path(__file__).resolve().parent
for d in [B, B.parent/'twin_work_3x3/python_deps', B.parent/'power_combined/python_deps']:
    sys.path.insert(0,str(d))
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
import plot_corrected as plot

OUT=B/'full_record_psd_20260913'
SCHEMES=[12,15,18,21,24,27,30]
METHODS=['CTL','CDA8']+[f'MCPE{n}' for n in SCHEMES]

def full_psd(x,c):
    x=np.asarray(x,dtype=float);x=x-x.mean();n=len(x)
    window='boxcar' if c['nperseg']=='full' else 'hann'
    f,p=signal.periodogram(x,fs=c['fs'],window=window,nfft=n,detrend='constant',scaling='density',return_onesided=True)
    # Independent FFT normalization and window-energy/Parseval check.
    y=x-x.mean();w=signal.get_window(window,n)
    z=np.fft.rfft(y*w);manual=(z.real*z.real+z.imag*z.imag)/(c['fs']*np.sum(w*w))
    manual[1:-1 if n%2==0 else None]*=2
    np.testing.assert_allclose(p,manual,rtol=1e-9,atol=max(float(p.max())*1e-12,1e-20))
    np.testing.assert_allclose(p.sum()*c['fs']/n,np.sum((y*w)**2)/np.sum(w*w),rtol=1e-11,atol=1e-15)
    return f*c['mult'],p/c['mult'],window

def main():
    OUT.mkdir(exist_ok=True);figdir=OUT/'figures';figdir.mkdir(exist_ok=True)
    cfg,xlim=plot.original_config(B);spec={};freq={};truth=None;truth_hash=None;receipts=[]
    original=json.loads((B/'figures/power_spectra/plot_data.json').read_text())
    meta={'window_TU':[100000,150000],'seeds':list(range(10)),'fixed_member':1,
          'segment_count_per_seed':1,'seed_average':True,'temporal_smoothing':False,
          'fft_padding':False,'window_functions_preserved':True,'variables':{},'images':{}}
    for method in METHODS:
        current=[]
        for seed in range(10):
            d=(B.parent/'three_channel_figures_psd150k_20260913'/'runs'/method/f'seed{seed}') if method in ['CTL','CDA8'] else B/'runs'/f'M{method[4:]}_v6'/f'seed{seed}'
            assert (d/'READY').exists() and not (d/'FAILED').exists()
            p=d/'spectral_member1.bin';assert p.stat().st_size==500001*15*8
            a=np.memmap(p,dtype='<f8',mode='r',shape=(500001,15));assert np.isfinite(a).all()
            np.testing.assert_allclose(a[:,0],np.arange(10000000,15000001,10)/100,rtol=0,atol=1e-10)
            th=hashlib.sha256(np.ascontiguousarray(a[:,1:8]).tobytes()).hexdigest()
            assert th==json.loads((d/'audit.json').read_text())['truth_sha256']
            if truth_hash is None:truth_hash=th
            assert th==truth_hash
            rows={};tr={};old=dict(np.load(d/'spectra.npz'))
            for j,var in enumerate(plot.VARIABLES):
                c=cfg[var];stride=int(round(10/c['fs']));data=a[::stride]
                assert len(data)==int(50000*c['fs'])+1
                f,y,window=full_psd(data[:,8+j],c);mask=(f>=xlim[0])&(f<=xlim[1])
                if var in freq:np.testing.assert_array_equal(f[mask],freq[var])
                else:freq[var]=f[mask]
                rows[var]=y[mask]
                if truth is None:
                    ft,yt,_=full_psd(data[:,1+j],c);np.testing.assert_array_equal(ft,f);tr[var]=yt[mask]
                if c['nperseg']=='full':
                    np.testing.assert_array_equal(f[mask],old[f'{var}_1_frequency'])
                    np.testing.assert_allclose(y[mask],old[f'{var}_1_member1'],rtol=1e-12,atol=1e-15)
                meta['variables'][var]={'samples':len(data),'sample_interval_TU':1/c['fs'],
                    'window_function':window,'frequency_spacing_TU_inverse':c['fs']/len(data),
                    'displayed_bins':int(mask.sum()),'segment_count':1}
            if truth is None:truth=tr
            current.append(rows)
            receipts.append({'method':method,'seed':seed,'source':str(p),'bytes':p.stat().st_size,
                'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'truth_sha256':th})
            print('PSD_READY',method,seed,flush=True)
            del a
        spec[method]={var:np.mean([r[var] for r in current],axis=0) for var in plot.VARIABLES}
        # Independent seed-sum check on the published mean arrays.
        for var in plot.VARIABLES:
            np.testing.assert_allclose(spec[method][var],sum(r[var] for r in current)/10,rtol=1e-14,atol=1e-15)
        np.savez_compressed(OUT/f'{method}_seed_psd.npz',**{f'{var}_seed{s}':r[var] for s,r in enumerate(current) for var in plot.VARIABLES})
    arrays={}
    for var in plot.VARIABLES:
        arrays[var+'_frequency']=freq[var];arrays[var+'_Truth']=truth[var]
        for method in METHODS:arrays[var+'_'+method]=spec[method][var]
        if cfg[var]['nperseg']=='full':
            np.testing.assert_array_equal(freq[var],original[var]['frequency'])
            np.testing.assert_allclose(truth[var],original[var]['Truth'],rtol=1e-12,atol=1e-15)
            for method in METHODS:np.testing.assert_allclose(spec[method][var],original[var][method],rtol=1e-12,atol=1e-15)
    np.savez_compressed(OUT/'plot_arrays.npz',**arrays)
    plot.configure_font(B);plt.rcParams['path.simplify']=False
    styles={'Truth':dict(color='#111111',ls='-',marker=None),'CTL':dict(color='#777777',ls=(0,(6,3)),marker=None),
        'CDA8':dict(color='#0072B2',ls=(0,(1,1.8)),marker='x'),'MCPE':dict(color='#D64000',ls='-',marker='o')}
    limits={var:1.1*max(float(truth[var].max()),*[float(spec[m][var].max()) for m in METHODS]) for var in plot.VARIABLES}
    for n in SCHEMES:
        labels=['Truth','CTL','CDA8',f'MCPE{n}']
        fig,axes=plot.seven_panel(f'Power spectra: CTL, Truth, CDA8 and MCPE{n}',
            '100000–150000 TU | Mean PSD over 10 seeds | Fixed member 1',
            'Full-record spectra for all variables | State assimilation and parameter estimation continue')
        plot.shared_legend(fig,[Line2D([],[],lw=1.5,markersize=5,markerfacecolor='white',**styles[m if m in styles else 'MCPE']) for m in labels],labels)
        checked=0
        for var,ax in axes.items():
            f=freq[var]
            for i,m in enumerate(labels):
                y=truth[var] if m=='Truth' else spec[m][var];stride=max(7,len(f)//9)
                line,=ax.plot(f,y,lw=1.5,markersize=4.7,markerfacecolor='white',markeredgewidth=.9,
                    markevery=list(range(i%stride,len(f),stride)),**styles[m if m in styles else 'MCPE'])
                np.testing.assert_array_equal(line.get_xdata(),arrays[var+'_frequency'])
                np.testing.assert_array_equal(line.get_ydata(),arrays[var+'_'+m]);checked+=1
            ax.set_xlim(*xlim);ax.set_ylim(0,limits[var]);plot.axis_style(ax,var,cfg[var]['xlab'],'PSD',spectrum=True)
            ax.set_title(var+' | full record',fontsize=12)
        fig.text(.5,.032,'One full-length segment per seed; no segment averaging, interpolation or extra smoothing.',ha='center',fontsize=9.3)
        fig.text(.5,.016,'Original windows retained: Hann for x2, w, eta, TL and Catm; rectangular for Cocean and ALK.',ha='center',fontsize=9.3)
        assert checked==28
        path=figdir/f'power_spectra_full_record_MCPE{n}_vs_CTL_Truth_CDA8.png';fig.savefig(path,dpi=300);plt.close(fig)
        with Image.open(path) as im:im.verify()
        with Image.open(path) as im:size=list(im.size)
        meta['images'][path.name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':size,'lines_checked':checked}
        print('FIGURE_READY',n,flush=True)
    assert len(receipts)==90 and len(meta['images'])==7
    meta['sources']=receipts;meta['original_Cocean_ALK_exact_configuration_preserved']=True
    (OUT/'audit.json').write_text(json.dumps(meta,indent=2))
    (OUT/'READY').write_text('7 full-record PSD PNGs; no integration rerun; visual QA pending.\n')
    print('FULL_RECORD_READY',flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        OUT.mkdir(exist_ok=True);(OUT/'FAILED').write_text(repr(e));raise
