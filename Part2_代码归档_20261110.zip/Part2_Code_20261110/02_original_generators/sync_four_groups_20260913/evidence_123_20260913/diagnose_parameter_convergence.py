from pathlib import Path
import json,hashlib
import numpy as np
B=Path(__file__).resolve().parent;P=B.parent
source=P/'parameter_ensemble_20260913/plot_arrays.npz'
z=np.load(source);cfg=json.loads((P/'config.json').read_text(encoding='utf-8'))
keep=np.array([0,1,2,4,5,6,7,8,9]);t=z['time_TU'];late=(t>90000)&(t<=100000)
records=[];combos=[]
for n in [12,15,18,21,24,27,30]:
    raw=z[f'M{n}_seed_means'];truth=z[f'M{n}_truth'];sd=z[f'M{n}_seed_population_sd']
    ratio=raw[keep]/truth
    for name in cfg['configs']['sync'][str(n)]['unique_parameters']:
        j=cfg['row45'][name]-1;r=ratio[:,:,j];e=r-1
        ini=float(np.sqrt(np.mean(e[:,0]**2)));err=float(np.sqrt(np.mean(e[:,late]**2)))
        entry=min(s['entry_TU'] for s in cfg['configs']['sync'][str(n)]['slots'] if s['name']==name)
        records.append(dict(scheme=n,parameter=name,first_entry_TU=entry,late_mean_ratio=float(r[:,late].mean()),initial_ratio_rmse=ini,late_ratio_rmse=err,late_seed_mean_min=float(r[:,late].mean(1).min()),late_seed_mean_max=float(r[:,late].mean(1).max()),late_within_rms_sd=float(np.sqrt(np.mean((sd[keep][:,late,j]/abs(truth[j]))**2))),late_trend_per10000TU=float(np.polyfit(t[late]-95000,r[:,late].mean(0),1)[0]*10000),late_rmse_all10=float(np.sqrt(np.mean((raw[:,late,j]/truth[j]-1)**2))),improved_seeds=int(np.sum(np.mean(e[:,late]**2,axis=1)<e[:,0]**2))))
    for names in [('kappa','c1'),('kappa','c13')]:
        if not all(k in cfg['configs']['sync'][str(n)]['unique_parameters'] for k in names):continue
        j,k=[cfg['row45'][x]-1 for x in names]
        prod=ratio[:,:,j]*ratio[:,:,k]
        combos.append(dict(scheme=n,combination='*'.join(names),initial_ratio_mean=float(prod[:,0].mean()),late_ratio_mean=float(prod[:,late].mean()),initial_ratio_rmse=float(np.sqrt(np.mean((prod[:,0]-1)**2))),late_ratio_rmse=float(np.sqrt(np.mean((prod[:,late]-1)**2))),late_parameter_seed_mean_correlation=float(np.corrcoef(ratio[:,late,j].mean(1),ratio[:,late,k].mean(1))[0,1])))
out=dict(obs=8,retained_seeds=keep.tolist(),excluded_seed=3,window_TU=[90000,100000],source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),definition='Late normalized error is sqrt(mean_seed,time((parameter ensemble mean / truth - 1)^2)); not an error of the grand mean.',parameters=records,combinations=combos)
(B/'parameter_convergence_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print('M30 name mean_ratio init_RMS late_RMS late_trend/10000TU within_SD improved/9')
for r in records:
    if r['scheme']==30:print(r['parameter'],*[round(r[k],4) for k in ['late_mean_ratio','initial_ratio_rmse','late_ratio_rmse','late_trend_per10000TU','late_within_rms_sd']],r['improved_seeds'])
print('RANGES across schemes actually estimating parameter: mean_ratio; normalized RMS')
for name in cfg['row45']:
    rs=[r for r in records if r['parameter']==name]
    print(name, 'mean',round(min(r['late_mean_ratio'] for r in rs),3),round(max(r['late_mean_ratio'] for r in rs),3),'rms',round(min(r['late_ratio_rmse'] for r in rs),3),round(max(r['late_ratio_rmse'] for r in rs),3),'seedimprove',[r['improved_seeds'] for r in rs])
print('PRODUCTS');print(json.dumps(combos,indent=2))
