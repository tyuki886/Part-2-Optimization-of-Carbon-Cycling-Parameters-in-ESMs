"""Post-hoc, explicitly labelled nine-seed sensitivity figures; original data immutable."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from scipy.stats import bootstrap
from PIL import Image
B=Path(__file__).resolve().parent;P=B.parent
sys.path.insert(0,str(P))
import plot_corrected
plot_corrected.configure_font(P)
O=B/'exclude_seed3_9seeds';O.mkdir(exist_ok=True)
KEEP=np.array([0,1,2,4,5,6,7,8,9]);NS=[12,15,18,21,24,27,30]
GROUPS=[(5,4,1),(7,5,2),(8,6,3)];VARS=[('Catm',7),('Cocean',8),('ALK',9)]
COLORS=['#111111','#0072B2','#E69F00','#009E73','#CC79A7','#D55E00','#56B4E9','#8C564B']
MARKERS=['h','o','s','^','D','v','P','X']
paths=[B/'moments_arrays.npz',B/'paired_audit.json',P/'summary.json']
source_hash={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
raw=np.load(paths[0]);data={k:raw[k][KEEP].copy() for k in raw.files}
summary=json.loads(paths[2].read_text(encoding='utf-8'))
for key,a in data.items():
    assert a.shape==(9,10,6) and np.isfinite(a).all()
    mx,mt,vx,vt,cov,mse=np.moveaxis(a,-1,0)
    np.testing.assert_allclose((mx-mt)**2+vx+vt-2*cov,mse,rtol=1e-8,atol=1e-10)
    np.testing.assert_allclose(np.sqrt(mse),np.array(summary['RMSE_per_seed'][key])[KEEP],rtol=0,atol=5.1e-8)
receipt={'retained_seeds':KEEP.tolist(),'excluded_seeds':[3],'exclusion':'User-requested post-hoc sensitivity analysis; same seed removed from every method and observation setting.','window_TU':[90000,100000],'source_sha256':source_hash,'images':{},'decomposition':[],'taylor':[],'paired':[]}
def save(fig,name):
    path=O/name;fig.canvas.draw();fig.savefig(path,dpi=300);plt.close(fig)
    with Image.open(path) as im:im.verify()
    with Image.open(path) as im:size=list(im.size)
    receipt['images'][name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':size}
    print('READY',name,flush=True)
for obs,v,cv in GROUPS:
    keys=[f'M22_v{cv}']+[f'M{n}_v{v}' for n in NS]
    labels=[f'CDA{obs}']+[f'M{n}' for n in NS]
    fig,axes=plt.subplots(1,3,figsize=(16,6))
    for ax,(var,j) in zip(axes,VARS):
        components=[]
        for key,label in zip(keys,labels):
            a=data[key][:,j,:];mx,mt,vx,vt,cov,mse=a.T
            terms=np.array([(mx-mt)**2,(np.sqrt(vx)-np.sqrt(vt))**2,2*(np.sqrt(vx*vt)-cov)])
            assert terms.min()>-1e-10
            terms=np.maximum(terms,0)
            np.testing.assert_allclose(terms.sum(0),mse,rtol=1e-8,atol=1e-10)
            components.append(terms.mean(1))
            receipt['decomposition'].append({'obs':obs,'variable':var,'method':label,'components':terms.mean(1).tolist(),'mean_MSE':float(mse.mean()),'mean_RMSE':float(np.sqrt(mse).mean())})
        comp=np.array(components);bottom=np.zeros(8)
        for k,color in enumerate(['#4C72B0','#DD8452','#8172B3']):
            bars=ax.bar(np.arange(8),comp[:,k],bottom=bottom,color=color,width=.72,edgecolor='white',lw=.4)
            np.testing.assert_allclose([b.get_height() for b in bars],comp[:,k],rtol=1e-10,atol=1e-12);bottom+=comp[:,k]
        ax.set_xticks(np.arange(8));ax.set_xticklabels(labels,rotation=45,ha='right',fontsize=9)
        ax.set_title(var);ax.set_ylabel('Mean squared error');ax.set_ylim(bottom=0);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    fig.suptitle(f'State-estimation error decomposition ({obs}obs)',fontsize=16,y=.99)
    fig.legend(handles=[Patch(color=c,label=l) for c,l in zip(['#4C72B0','#DD8452','#8172B3'],['Squared mean bias','Variance-amplitude mismatch','Correlation mismatch'])],loc='upper center',bbox_to_anchor=(.5,.95),ncol=3,frameon=False)
    fig.text(.5,.038,'90000–100000 TU | Ensemble-mean states | 9-seed sensitivity analysis: seed 3 excluded from all methods',ha='center',fontsize=10)
    fig.text(.5,.013,'Components computed per seed, then averaged. Post-hoc exclusion; original 10-seed results retained.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.065,1,.86));save(fig,f'MSE_decomposition_{obs}obs_9seeds.png')
    fig,axes=plt.subplots(1,3,figsize=(16,6.8),subplot_kw={'projection':'polar'})
    for ax,(var,j) in zip(axes,VARS):
        stats=[]
        for key,label in zip(keys,labels):
            a=data[key][:,j,:];vx,vt,cov=a[:,2],a[:,3],a[:,4]
            r=float(cov.mean()/np.sqrt(vx.mean()*vt.mean()))
            ratio=float(np.sqrt(vx.mean()/vt.mean()))
            assert abs(r)<=1+1e-10
            crms=float(np.sqrt(max(0,(vx.mean()+vt.mean()-2*cov.mean())/vt.mean())))
            np.testing.assert_allclose(crms**2,1+ratio**2-2*ratio*r,rtol=1e-10,atol=1e-12)
            stats.append((r,ratio));receipt['taylor'].append({'obs':obs,'variable':var,'method':label,'correlation':r,'SD_ratio':ratio,'normalized_centered_RMSE':crms})
        rmax=float(np.ceil(max(1.5,1.15*max(s[1] for s in stats))*2)/2)
        theta=np.linspace(0,np.pi,181);tt,rr=np.meshgrid(theta,np.linspace(0,rmax,150))
        centered=np.sqrt(np.maximum(0,1+rr**2-2*rr*np.cos(tt)))
        cs=ax.contour(tt,rr,centered,levels=5,colors='#BBBBBB',linewidths=.6);ax.clabel(cs,inline=True,fontsize=7,fmt='%.1f')
        ax.plot(theta,np.ones_like(theta),color='#888888',ls='--',lw=.8)
        for i,(r,ratio) in enumerate(stats):
            line,=ax.plot(np.arccos(np.clip(r,-1,1)),ratio,marker=MARKERS[i],ls='',color=COLORS[i],markersize=8,zorder=5+i*.01)
            np.testing.assert_allclose(line.get_xdata(),[np.arccos(np.clip(r,-1,1))]);np.testing.assert_array_equal(line.get_ydata(),[ratio])
        ax.plot(0,1,marker='*',color='black',markersize=12,ls='',clip_on=False,zorder=8)
        ticks=np.array([1,.9,.7,.5,0,-.5,-.7,-.9,-1])
        ax.set_thetamin(0);ax.set_thetamax(180);ax.set_thetagrids(np.degrees(np.arccos(ticks)),[f'{r:g}' for r in ticks],fontsize=8)
        ax.set_ylim(0,rmax);ax.set_yticks(np.arange(0,rmax+.01,.5));ax.set_title(var+' | correlation',pad=16);ax.set_rlabel_position(100);ax.tick_params(axis='y',labelsize=8);ax.grid(alpha=.3)
        # Only eight method summaries and one Truth marker, never individual seed points.
        assert sum(line.get_marker() not in [None,'None',''] for line in ax.lines)==9
    fig.suptitle(f'Taylor diagrams of state estimates ({obs}obs)',fontsize=16,y=.99)
    handles=[Line2D([],[],color=c,marker=m,ls='',label=l) for c,m,l in zip(COLORS,MARKERS,labels)]
    handles.append(Line2D([],[],color='black',marker='*',ls='',label='Truth'))
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.94),ncol=9,frameon=False,fontsize=10)
    fig.text(.5,.10,'90000–100000 TU | Ensemble-mean states | 9-seed sensitivity analysis: seed 3 excluded from all methods',ha='center',fontsize=10)
    fig.text(.5,.065,'Summary points only: pooled within-seed centered moments | Radius: SD / truth SD | Angle: correlation',ha='center',fontsize=9)
    fig.text(.5,.03,'Grey contours: normalized centered RMSE; mean bias excluded. Post-hoc exclusion; original 10-seed results retained.',ha='center',fontsize=9)
    fig.subplots_adjust(top=.82,bottom=.18,left=.055,right=.97,wspace=.3)
    save(fig,f'Taylor_diagram_{obs}obs_9seeds_summary_only.png')
# Recompute paired intervals from the identical nine retained seed pairs.
fig,axes=plt.subplots(3,3,figsize=(16,15))
for row,(obs,v,cv) in enumerate(GROUPS):
    for col,(var,j) in enumerate(VARS):
        ax=axes[row,col];means=[];bounds=[]
        base=np.array(summary['RMSE_per_seed'][f'M22_v{cv}'])[KEEP,j]
        for i,n in enumerate(NS):
            model=np.array(summary['RMSE_per_seed'][f'M{n}_v{v}'])[KEEP,j];diff=base-model
            res=bootstrap((base,model),lambda x,y,axis:np.mean(x-y,axis=axis),paired=True,vectorized=True,confidence_level=.95,n_resamples=19999,method='percentile',random_state=20260913)
            ci=[float(res.confidence_interval.low),float(res.confidence_interval.high)]
            means.append(diff.mean());bounds.append(ci);wins=int((diff>0).sum())
            sc=ax.scatter(i+np.linspace(-.16,.16,9),diff,color='#777777',s=19,alpha=.65,zorder=3)
            np.testing.assert_array_equal(np.asarray(sc.get_offsets())[:,1],diff)
            ax.text(i,.98,f'{wins}/9',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=10)
            receipt['paired'].append({'obs':obs,'variable':var,'scheme':n,'seed_differences':diff.tolist(),'mean_difference':float(diff.mean()),'CI95':ci,'seeds_improved':wins})
        means=np.array(means);bounds=np.array(bounds)
        line,caps,bars=ax.errorbar(np.arange(7),means,yerr=[means-bounds[:,0],bounds[:,1]-means],fmt='D',color='#2166AC',capsize=4,markersize=5,lw=1.4,zorder=4)
        np.testing.assert_array_equal(line.get_ydata(),means)
        np.testing.assert_allclose(np.array(bars[0].get_segments())[:,:,1],bounds,rtol=1e-13,atol=1e-14)
        ax.axhline(0,color='black',lw=.8);ax.set_xticks(np.arange(7));ax.set_xticklabels([str(n) for n in NS])
        ax.set_title(f'{var} | {obs}obs',fontsize=13,pad=10);ax.set_xlabel('MCPE scheme',fontsize=11);ax.set_ylabel(f'RMSE(CDA{obs}) - RMSE(MCPE)',fontsize=11)
        ax.tick_params(labelsize=10);ax.grid(axis='y',alpha=.2);ax.margins(y=.2)
fig.suptitle('Paired-seed RMSE improvement relative to CDA',fontsize=19,y=.987)
fig.legend(handles=[Line2D([],[],marker='o',ls='',color='#777777',label='Individual paired seed'),Line2D([],[],marker='D',color='#2166AC',label='Mean difference and pointwise 95% bootstrap interval')],loc='upper center',bbox_to_anchor=(.5,.966),ncol=2,frameon=False,fontsize=12)
fig.text(.5,.045,'90000–100000 TU | 9-seed sensitivity analysis: seed 3 excluded from all methods | Positive = lower MCPE RMSE',ha='center',fontsize=10)
fig.text(.5,.027,'Labels: improved seeds / 9 | Post-hoc exclusion; original 10-seed results retained.',ha='center',fontsize=10)
fig.text(.5,.009,'Exploratory pointwise intervals; no multiple-comparison adjustment. Bootstrap resamples paired seeds, not time steps.',ha='center',fontsize=10)
fig.subplots_adjust(left=.07,right=.985,bottom=.09,top=.92,wspace=.27,hspace=.30)
save(fig,'paired_RMSE_improvement_578obs_3x3_9seeds.png')
assert len(receipt['images'])==7
assert source_hash=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(O/'audit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print('VERIFIED_7_IMAGES_ORIGINAL_SOURCES_UNCHANGED',flush=True)
