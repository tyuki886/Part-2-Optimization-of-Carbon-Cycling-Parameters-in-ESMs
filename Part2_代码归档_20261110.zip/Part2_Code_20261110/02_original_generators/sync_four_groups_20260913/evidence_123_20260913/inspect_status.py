import getpass, paramiko
c=paramiko.SSHClient()
c.load_system_host_keys()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80', username='hou', password=getpass.getpass('HPC password: '), look_for_keys=False, allow_agent=False, timeout=25)
try:
    command='cd /public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913/evidence_123_20260913 && tail -n 45 logs/EvidencePlots.o25567'
    _,out,err=c.exec_command(command, timeout=60)
    print(out.read().decode()); print(err.read().decode())
finally:
    c.close()
