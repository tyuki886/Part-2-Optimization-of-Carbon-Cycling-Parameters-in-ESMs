from pathlib import Path
import hashlib, json, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B.parent))
import plot_corrected
plot_corrected.configure_font(B.parent)
source=B/'paired_audit.json'
meta=json.loads(source.read_text(encoding='utf-8'))
lookup={(x['obs'],x['variable'],x['scheme']):x for x in meta['values']}
ns=[12,15,18,21,24,27,30]
fig,axes=plt.subplots(3,3,figsize=(16,15))
checks=[]
for row,obs in enumerate([5,7,8]):
    for col,var in enumerate(['Catm','Cocean','ALK']):
        ax=axes[row,col]
        rows=[lookup[obs,var,n] for n in ns]
        y=np.array([r['mean_difference'] for r in rows])
        ci=np.array([r['CI95'] for r in rows])
        for i,r in enumerate(rows):
            d=np.array(r['seed_differences'])
            assert d.shape==(10,) and np.isfinite(d).all()
            np.testing.assert_allclose(y[i],d.mean(),rtol=1e-14,atol=1e-15)
            assert r['seeds_improved']==int((d>0).sum())
            sc=ax.scatter(i+np.linspace(-.16,.16,10),d,color='#777777',s=19,alpha=.65,zorder=3)
            np.testing.assert_array_equal(np.asarray(sc.get_offsets())[:,1],d)
            ax.text(i,.98,f"{r['seeds_improved']}/10",transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=10)
        line,cap,bars=ax.errorbar(np.arange(7),y,yerr=[y-ci[:,0],ci[:,1]-y],fmt='D',color='#2166AC',capsize=4,markersize=5,lw=1.4,zorder=4)
        np.testing.assert_array_equal(line.get_ydata(),y)
        np.testing.assert_allclose(np.array(bars[0].get_segments())[:,:,1],ci,rtol=1e-13,atol=1e-14)
        ax.axhline(0,color='black',lw=.8)
        ax.set_xticks(np.arange(7));ax.set_xticklabels([str(n) for n in ns])
        ax.set_title(f'{var} | {obs}obs',fontsize=13,pad=10)
        ax.set_xlabel('MCPE scheme',fontsize=11)
        ax.set_ylabel(f'RMSE(CDA{obs}) - RMSE(MCPE)',fontsize=11)
        ax.tick_params(labelsize=10);ax.grid(axis='y',alpha=.2);ax.margins(y=.2)
        checks.append({'obs':obs,'variable':var,'schemes':ns,'seed_points_checked':70,'CI_checked':7})
fig.suptitle('Paired-seed RMSE improvement relative to CDA',fontsize=19,y=.987)
fig.legend(handles=[Line2D([],[],marker='o',ls='',color='#777777',label='Individual paired seed'),Line2D([],[],marker='D',color='#2166AC',label='Mean difference and pointwise 95% bootstrap interval')],loc='upper center',bbox_to_anchor=(.5,.966),ncol=2,frameon=False,fontsize=12)
fig.text(.5,.042,'90000–100000 TU | Ensemble-mean states | All 10 seeds | Positive = lower MCPE RMSE',ha='center',fontsize=11)
fig.text(.5,.025,'Labels: improved seeds / 10 | Each observation setting is compared with its corresponding CDA baseline.',ha='center',fontsize=10)
fig.text(.5,.009,'Exploratory pointwise intervals; no multiple-comparison adjustment. Bootstrap resamples paired seeds, not time steps.',ha='center',fontsize=10)
fig.subplots_adjust(left=.07,right=.985,bottom=.09,top=.92,wspace=.27,hspace=.30)
out=B/'figures'/'paired_RMSE_improvement_578obs_3x3.png'
fig.canvas.draw();fig.savefig(out,dpi=300);plt.close(fig)
with Image.open(out) as im: im.verify()
receipt={'source_audit_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'file':out.name,'size':[4800,4500],'panels':checks,'rows':[5,7,8],'columns':['Catm','Cocean','ALK'],'original_three_figures_preserved':True}
(B/'paired_3x3_audit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(out)
