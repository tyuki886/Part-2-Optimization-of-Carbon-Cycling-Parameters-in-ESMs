from pathlib import Path
import hashlib,json,shutil
B=Path(__file__).resolve().parent
D=Path(r'D:\SRDP\论文大作！\MCPE26.0\9.2\同步MCPE12-30_七方案四类图_20260913\evidence_123')
receipt=[]
def copy(src,dst,expected):
    assert src.suffix=='.png' and hashlib.sha256(src.read_bytes()).hexdigest()==expected
    if dst.exists():
        assert hashlib.sha256(dst.read_bytes()).hexdigest()==expected,dst
    else:
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    assert hashlib.sha256(dst.read_bytes()).hexdigest()==expected
    receipt.append({'path':str(dst),'sha256':expected})
a=json.loads((B/'paired_3x3_audit.json').read_text(encoding='utf-8'))
copy(B/'figures'/a['file'],D/a['file'],a['sha256'])
a=json.loads((B/'moments_audit.json').read_text(encoding='utf-8'))
for name,info in a['images'].items():
    src=B/name
    folder='MSE_decomposition' if src.name.startswith('MSE_') else 'Taylor_diagrams'
    copy(src,D/folder/src.name,info['sha256'])
(B/'completed_delivery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print('DELIVERED',len(receipt),'PNG')
for r in receipt:print(r['path'])
