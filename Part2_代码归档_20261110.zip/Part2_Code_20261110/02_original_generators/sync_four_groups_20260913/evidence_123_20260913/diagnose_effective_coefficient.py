from pathlib import Path
import json,numpy as np
B=Path(__file__).resolve().parent;P=B.parent
z=np.load(P/'parameter_ensemble_20260913/plot_arrays.npz');m=np.load(B/'moments_arrays.npz')
cfg=json.loads((P/'config.json').read_text(encoding='utf-8'));idx=cfg['row45'];t=z['time_TU'];late=(t>90000)&(t<=100000)
records=[]
for keep in [[0,1,2,4,5,6,7,8,9],list(range(10))]:
    for n in [12,15,18,21,24,27,30]:
        a=z[f'M{n}_seed_means'][keep];pt=z[f'M{n}_truth']
        w=float(m[f'M{n}_v6'][0,3,1]);tl=float(m[f'M{n}_v6'][0,6,1])
        j,k,l=[idx[s]-1 for s in ['kappa','c1','c13']]
        ref=pt[j]*(1+pt[k]*w+pt[l]*tl)
        eff=a[:,:,j]*(1+a[:,:,k]*w+a[:,:,l]*tl)/ref
        expanded=(a[:,:,j]+a[:,:,j]*a[:,:,k]*w+a[:,:,j]*a[:,:,l]*tl)/ref
        np.testing.assert_allclose(eff,expanded,rtol=1e-13,atol=1e-13)
        records.append(dict(scheme=n,seeds=len(keep),retained_seeds=keep,truth_mean_w=w,truth_mean_TL=tl,initial_ratio=float(eff[:,0].mean()),late_ratio=float(eff[:,late].mean()),initial_normalized_RMS_error=float(np.sqrt(np.mean((eff[:,0]-1)**2))),late_normalized_RMS_error=float(np.sqrt(np.mean((eff[:,late]-1)**2)))))
out={'definition':'A=kappa*(1+c1*w_ref+c13*TL_ref), evaluated using each seed parameter ensemble means and fixed Truth time means w_ref and TL_ref. Ratios relative to A from true parameters.', 'caveats':['Not the actual ensemble-mean dynamic tendency; products of parameter means omit within-ensemble covariances.','Fixed mean reference states, not time-varying estimated states; no out-of-sample validation.','c13 in MCPE12 is not estimated; its saved fixed biased value is included in this coefficient.'], 'records':records}
(B/'effective_coefficient_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
for r in records:
    if r['scheme']==30: print(r)
# Build a compact, source-backed receipt. No local absolute paths or credentials embedded.
p=json.loads((B/'parameter_convergence_audit.json').read_text(encoding='utf-8'))
byname={}
for r in p['parameters']:byname.setdefault(r['parameter'],[]).append(r)
rows=[{'parameter':name,'late_mean_ratio_min':min(r['late_mean_ratio'] for r in rs),'late_mean_ratio_max':max(r['late_mean_ratio'] for r in rs),'late_normalized_RMS_min':min(r['late_ratio_rmse'] for r in rs),'late_normalized_RMS_max':max(r['late_ratio_rmse'] for r in rs)} for name,rs in byname.items()]
payload={'schemaVersion':1,'items':[
 {'id':'parameter-recovery','title':'各参数趋真程度随参数和方案不同','queries':[{'id':'parameter-summary','source':{'label':'同步七方案8obs参数轨迹','files':['parameter_convergence_audit.json','plot_arrays.npz','config.json'],'filters':['8obs；同步MCPE12、15、18、21、24、27、30','仅纳入方案实际估计的参数','保留9seed；统一排除seed 3'],'caveats':['9seed为事后敏感性分析；原10seed数据保留。','均值接近真值不代表所有seed均接近，另核对seed与时间上的归一化RMS误差。','100000 TU内的靠近趋势不证明渐近收敛。']},'reportingPeriod':'90000–100000 TU；初始值作为偏差改善基准','rows':rows,'columns':['parameter','late_mean_ratio_min','late_mean_ratio_max','late_normalized_RMS_min','late_normalized_RMS_max'],'summary':'b和sigma在各方案9个seed均改善；c20、c27、c12也有一致改善。kappa、c1等仍系统偏离；c16等存在seed间分歧。'}]},
 {'id':'effective-coefficient','title':'固定Truth平均背景下，参数组合比单参数更接近真值','queries':[{'id':'coefficient','source':{'label':'x2方程合成系数诊断','files':['effective_coefficient_audit.json','RKmethod.f90'],'filters':['8obs；同步七方案','使用各seed参数集合均值','w与TL固定为Truth在评估窗内的时间平均值'],'caveats':out['caveats']},'reportingPeriod':'90000–100000 TU；与初始参数组合对比','rows':records,'columns':['scheme','seeds','initial_ratio','late_ratio','initial_normalized_RMS_error','late_normalized_RMS_error'],'methods':[{'language':'calculation','code':'A=kappa*(1+c1*w_ref+c13*TL_ref); ratio=A/A_truth; normalized_RMS=sqrt(mean_seed,time((ratio-1)^2)).'}]}]}
]}
(B/'parameter_analysis_sources.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
