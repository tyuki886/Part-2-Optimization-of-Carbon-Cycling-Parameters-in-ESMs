"""核对8obs MCPE30相对CDA8的误差来源，占比与减少量分别计算。"""
from pathlib import Path
import json,hashlib
import numpy as np

B=Path(__file__).resolve().parent
src=B/'exclude_seed3_9seeds'/'audit.json'
a=json.loads(src.read_text(encoding='utf-8'))
raw=np.load(B/'moments_arrays.npz')
assert hashlib.sha256((B/'moments_arrays.npz').read_bytes()).hexdigest()==a['source_sha256']['moments_arrays.npz']
rows=[];changes=[]
for var,j in [('Catm',7),('Cocean',8),('ALK',9)]:
    pair=[]
    for method,key in [('CDA8','M22_v3'),('M30','M30_v6')]:
        r=next(r for r in a['decomposition'] if r['obs']==8 and r['variable']==var and r['method']==method)
        mx,mt,vx,vt,cov,mse=raw[key][a['retained_seeds'],j,:].T
        terms=np.stack([(mx-mt)**2,(vx**.5-vt**.5)**2,2*((vx*vt)**.5-cov)],axis=1)
        np.testing.assert_allclose(terms.sum(1),mse,rtol=1e-8,atol=1e-10)
        comp=terms.mean(0)
        np.testing.assert_allclose(comp,r['components'],rtol=1e-10,atol=1e-12)
        share=100*comp/mse.mean();np.testing.assert_allclose(share.sum(),100)
        t=next(t for t in a['taylor'] if t['obs']==8 and t['variable']==var and t['method']==method)
        out={'variable':var,'method':method,'MSE':float(mse.mean()),'mean_RMSE':r['mean_RMSE'],
             'blue':float(comp[0]),'orange':float(comp[1]),'purple':float(comp[2]),
             'blue_share_pct':float(share[0]),'orange_share_pct':float(share[1]),'purple_share_pct':float(share[2]),
             'correlation':t['correlation'],'SD_ratio':t['SD_ratio']}
        rows.append(out);pair.append(out)
    c,m=pair
    delta=np.array([c[k]-m[k] for k in ['blue','orange','purple']])
    np.testing.assert_allclose(delta.sum(),c['MSE']-m['MSE'],rtol=1e-8)
    reduction={f'{k}_reduction_pct':100*(c[k]-m[k])/c[k] for k in ['blue','orange','purple','MSE','mean_RMSE']}
    contributions={f'{k}_contribution_to_total_MSE_reduction_pct':float(100*d/delta.sum()) for k,d in zip(['blue','orange','purple'],delta)}
    changes.append({'variable':var,**reduction,**contributions})
output={'rows':rows,'changes':changes,'scope':'8obs; 90000–100000 TU; seeds 0,1,2,4,5,6,7,8,9',
        'shares':'ratio of mean component to mean MSE, not mean of per-seed fractions',
        'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest()}
(B/'m30_decomposition_explanation.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
source={'label':'8obs误差分解与Taylor统计','files':['exclude_seed3_9seeds/audit.json','moments_arrays.npz'],
        'filters':['观测配置：8obs','方法：CDA8与MCPE30','保留seed：0、1、2、4、5、6、7、8、9'],
        'caveats':['剔除seed3为事后敏感性分析，原始10seed结果保留，不能隐去该筛选条件。',
                   '三色是MSE的代数分解，不是对物理原因的独立因果识别。',
                   '先逐seed计算分量再平均；占比为平均分量除以平均MSE，不是各seed占比的平均。',
                   '标准差描述集合均值状态随时间的波动，不是集合成员之间的离散度。',
                   '相关系数和标准差比使用各seed去均值后的合并二阶矩，与图中Taylor汇总点一致。'],
        'evidenceFlow':[{'kind':'validation','title':'复核','body':'从原始二阶矩重算六根柱的分量，核对分量和等于MSE、占比和等于100%，并与已交付图的记录一致。'}]}
receipt={'schemaVersion':1,'items':[{'id':'m30-error-composition','title':'MCPE30的三类误差及剩余误差占比',
          'queries':[{'id':'six-bars','source':source,'reportingPeriod':'90000–100000 TU','rows':rows,
          'columns':[{'field':k,'label':l} for k,l in [('variable','变量'),('method','方法'),('MSE','平均MSE'),
          ('blue','蓝色：均值偏差平方'),('orange','橙色：幅度不匹配'),('purple','紫色：相关不匹配项'),
          ('blue_share_pct','蓝色占比（%）'),('orange_share_pct','橙色占比（%）'),('purple_share_pct','紫色占比（%）'),
          ('correlation','合并相关系数'),('SD_ratio','合并标准差比')]]}]},
          {'id':'m30-error-reduction','title':'MCPE30相对CDA8的误差减少来源',
           'queries':[{'id':'paired-reduction','source':source,'reportingPeriod':'90000–100000 TU','rows':changes,
            'columns':list(changes[0])}]}]}
(B/'m30_decomposition_sources.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(output,ensure_ascii=False,indent=2))
