"""Unchanged replay with stable state moments, independently reconciled to RMSE."""
from pathlib import Path
import sys,json,hashlib,traceback
B=Path(__file__).resolve().parent;P=B.parent
for d in [P,P/'rmse_time_20260913',P.parent/'twin_work_3x3/python_deps',P.parent/'power_combined/python_deps']:sys.path.insert(0,str(d))
import numpy as np
from process_task import TASKS,SCHEMES,env_for,execute
from task import validate
def check(d,n,v,steps,start):
    p=d/'state_moments.txt';header=np.fromstring(p.read_text().splitlines()[0],sep=' ',dtype=np.int64)
    np.testing.assert_array_equal(header,[start,steps,steps-start])
    a=np.loadtxt(p,skiprows=1);assert a.shape==(10,7) and np.isfinite(a).all()
    np.testing.assert_array_equal(a[:,0],np.arange(1,11));mx,mt,vx,vt,cov,mse=a[:,1:].T
    assert (vx>0).all() and (vt>0).all() and (mse>=0).all()
    r=cov/np.sqrt(vx*vt);assert (np.abs(r)<=1+1e-10).all()
    bias=(mx-mt)**2;amp=(np.sqrt(vx)-np.sqrt(vt))**2;pattern=2*(np.sqrt(vx*vt)-cov)
    assert pattern.min()>-1e-10
    np.testing.assert_allclose(bias+amp+pattern,mse,rtol=1e-8,atol=1e-10)
    np.testing.assert_allclose(np.sqrt(mse),np.loadtxt(d/f'rmse_M{n:02d}_v{v:02d}.txt'),rtol=0,atol=5.1e-8)
    return a
def preflight():
    for n,v,s in [(22,3,0),(30,6,0)]:
        env=env_for(n,v,s,2500000);env['MCPE_CHECKPOINT']='checkpoint.txt'
        a=B/'preflight'/f'M{n}_v{v}'/'original';b=a.parent/'moments'
        execute(P/'exp21_new',a,env);execute(B/'exp21_moments',b,env)
        for name in ['checkpoint.txt','parameter_mean.txt','parameter_updates.txt',f'rmse_M{n:02d}_v{v:02d}.txt']:
            assert (a/name).read_bytes()==(b/name).read_bytes(),name
        check(b,n,v,2500000,2000000);print('PREFLIGHT_EXACT_MATCH',n,v,flush=True)
    (B/'PREFLIGHT_PASS').write_text('Moments-only instrumentation: original checkpoint and trajectories unchanged.\n')
def run(tid):
    assert (B/'PREFLIGHT_PASS').exists();n,v,s=TASKS[tid];d=B/'runs'/f'M{n}_v{v}'/f'seed{s}'
    try:
        execute(B/'exp21_moments',d,env_for(n,v,s))
        a=validate(d,n,v,s,10000000,9000000,10000000);check(d,n,v,10000000,9000000)
        rec=next(r for r in json.loads((P/'delivery.json').read_text())['receipts'] if (r['scheme'],r['variant'],r['seed'])==(n,v,s))
        ref=Path(rec['path']);assert hashlib.sha256(ref.read_bytes()).hexdigest()==rec['sha256']
        assert (d/ref.name).read_bytes()==ref.read_bytes(),'Original RMSE mismatch'
        if (ref.parent/'parameter_mean.txt').exists():np.testing.assert_array_equal(np.loadtxt(d/'parameter_mean.txt'),np.loadtxt(ref.parent/'parameter_mean.txt')[:1001])
        a.update(original_RMSE_exact_match=True,state_moments_sha256=hashlib.sha256((d/'state_moments.txt').read_bytes()).hexdigest())
        (d/'audit.json').write_text(json.dumps(a,indent=2));(d/'READY').write_text('Moments and original RMSE validated.\n')
        print('READY',tid,n,v,s,flush=True)
    except Exception as e:d.mkdir(parents=True,exist_ok=True);(d/'FAILED').write_text(repr(e));raise
if __name__=='__main__':
    try:
        if sys.argv[1]=='preflight':preflight()
        else:run(int(sys.argv[1]))
    except Exception:traceback.print_exc();sys.exit(1)
