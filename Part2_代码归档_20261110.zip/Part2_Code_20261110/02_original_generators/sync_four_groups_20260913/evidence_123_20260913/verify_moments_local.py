from pathlib import Path
import json, hashlib
import numpy as np
B=Path(__file__).resolve().parent
z=np.load(B/'moments_arrays.npz')
s=json.loads((B.parent/'summary.json').read_text(encoding='utf-8'))
records=[]
for key in z.files:
    a=z[key]
    assert a.shape==(10,10,6) and np.isfinite(a).all()
    mx,mt,vx,vt,cov,mse=np.moveaxis(a,-1,0)
    direct=(mx-mt)**2+vx+vt-2*cov
    np.testing.assert_allclose(direct,mse,rtol=1e-8,atol=1e-10)
    ref=np.asarray(s['RMSE_per_seed'][key])
    np.testing.assert_allclose(np.sqrt(mse),ref,rtol=0,atol=5.1e-8)
    assert (vx>0).all() and (vt>0).all()
    corr=cov/np.sqrt(vx*vt)
    assert (abs(corr)<=1+1e-10).all()
    records.append({'key':key,'RMSE_max_rounding_difference':float(abs(np.sqrt(mse)-ref).max()),'MSE_identity_max_error':float(abs(direct-mse).max())})
result={'methods_checked':len(records),'seed_variable_values_checked':len(records)*100,'records':records,'moments_arrays_sha256':hashlib.sha256((B/'moments_arrays.npz').read_bytes()).hexdigest(),'scope':'Paired original RMSE and direct bias+variance-2cov identity; all 10 seeds, 10 variables.'}
(B/'independent_moments_check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('INDEPENDENT_MOMENTS_PASS',len(records)*100)
