from pathlib import Path
import getpass, paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913/evidence_123_20260913'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),look_for_keys=False,allow_agent=False,timeout=25)
try:
    with c.open_sftp() as f:
        f.rename(R+'/plot_evidence.py',R+'/plot_evidence_geometry_check_failed.py')
        f.put(str(B/'plot_evidence.py'),R+'/plot_evidence.py')
        # Keep the receipt present throughout so the watcher cannot duplicate submission.
        with f.open(R+'/post_job.txt') as src:
            previous=src.read()
        with f.open(R+'/post_job_geometry_check_failed.txt','w') as dst:
            dst.write(previous)
    _,o,e=c.exec_command(f'cd {R}/logs && qsub ../moments.pbs > ../post_job.txt && cat ../post_job.txt',timeout=60)
    print(o.read().decode());print(e.read().decode());assert o.channel.recv_exit_status()==0
finally:c.close()
