"""重新核对现有9seed配对图，不修改原数据。"""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.stats import bootstrap
B=Path(__file__).resolve().parent
a=json.loads((B/'exclude_seed3_9seeds/audit.json').read_text())
s=json.loads((B.parent/'summary.json').read_text())
keep=a['retained_seeds'];assert keep==[0,1,2,4,5,6,7,8,9]
assert len(a['paired'])==63
for r in a['paired']:
    v,cv={5:(4,1),7:(5,2),8:(6,3)}[r['obs']]
    j={'Catm':7,'Cocean':8,'ALK':9}[r['variable']]
    base=np.asarray(s['RMSE_per_seed'][f'M22_v{cv}'])[keep,j]
    key='M'+str(r['scheme'])+'_v'+str(v)
    model=np.asarray(s['RMSE_per_seed'][key])[keep,j]
    diff=base-model
    np.testing.assert_array_equal(diff,r['seed_differences'])
    np.testing.assert_allclose(diff.mean(),r['mean_difference'],rtol=0,atol=1e-14)
    assert int((diff>0).sum())==r['seeds_improved']
    ci=bootstrap((base,model),lambda x,y,axis:np.mean(x-y,axis=axis),paired=True,
        vectorized=True,confidence_level=.95,n_resamples=19999,method='percentile',random_state=20260913).confidence_interval
    np.testing.assert_allclose([ci.low,ci.high],r['CI95'],rtol=0,atol=1e-14)
p=B/'exclude_seed3_9seeds/paired_RMSE_improvement_578obs_3x3_9seeds.png'
assert hashlib.sha256(p.read_bytes()).hexdigest()==a['images'][p.name]['sha256']
print('PASS: 63 paired means, intervals and win counts verified; seed3 excluded; PNG hash matches.')
