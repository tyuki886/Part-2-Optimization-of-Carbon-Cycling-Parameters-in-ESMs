from pathlib import Path
import getpass, paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913/evidence_123_20260913'
c=paramiko.SSHClient(); c.load_system_host_keys(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),look_for_keys=False,allow_agent=False,timeout=25)
def cmd(s):
    _,o,e=c.exec_command(s,timeout=120);a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);print(a,b,flush=True)
try:
    cmd(f'test ! -e {R}/production_job.txt && test ! -e {R}/preflight_format_failed && test ! -e {R}/exp21_moments_format_failed.f90')
    with c.open_sftp() as f:
        f.rename(R+'/exp21_moments.f90',R+'/exp21_moments_format_failed.f90')
        f.put(str(B/'exp21_moments.f90'),R+'/exp21_moments.f90')
        f.rename(R+'/preflight',R+'/preflight_format_failed')
        f.rename(R+'/preflight_job.txt',R+'/preflight_job_format_failed.txt')
    cmd(f'cd {R} && gfortran -O3 -ffree-line-length-none -I.. exp21_moments.f90 ../MCPE42_new.o ../RKmethod.o -o exp21_moments && cd logs && qsub ../preflight.pbs > ../preflight_job.txt && cat ../preflight_job.txt')
finally:c.close()
