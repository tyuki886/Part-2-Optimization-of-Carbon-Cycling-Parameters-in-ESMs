from pathlib import Path
import sys,getpass,json,time,hashlib,paramiko
B=Path(__file__).resolve().parent;P='/public/home/hou/wyh/MCPE26.0/sync_four_groups_20260913';R=P+'/'+B.name
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
DEPS=P+':'+P+'/rmse_time_20260913:/public/home/hou/wyh/MCPE26.0/twin_work_3x3/python_deps:/public/home/hou/wyh/MCPE26.0/power_combined/python_deps'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),look_for_keys=False,allow_agent=False,timeout=25)
def cmd(s):
 _,o,e=c.exec_command(s,timeout=120);a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);return a
def pbs(label,action):
 return f'''#!/bin/bash
#PBS -N {label}
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=02:00:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH={DEPS}
{PY} {action}
'''
def advance():
 code='from pathlib import Path;import json;b=Path('+repr(R)+');print(json.dumps(dict(preflight=(b/"PREFLIGHT_PASS").exists(),production=(b/"production_job.txt").read_text().strip() if (b/"production_job.txt").exists() else None,ready=len(list(b.glob("runs/*/*/READY"))),failed=[str(p) for p in b.glob("runs/*/*/FAILED")],post=(b/"post_job.txt").read_text().strip() if (b/"post_job.txt").exists() else None,paired=(b/"PAIRED_READY").exists(),moments=(b/"MOMENTS_READY").exists())))'
 state=json.loads(cmd(f"{PY} - <<'STATEPY'\n{code}\nSTATEPY"))
 if state['failed']:raise RuntimeError(state)
 if state['preflight'] and not state['production']:print('PRODUCTION',cmd(f'cd {R}/logs && qsub -t 0-249%10 ../run.pbs > ../production_job.txt && cat ../production_job.txt'),flush=True)
 if state['ready']==250 and not state['post']:print('POST',cmd(f'cd {R}/logs && qsub ../moments.pbs > ../post_job.txt && cat ../post_job.txt'),flush=True)
 if state['paired'] and not (B/'PAIRED_DOWNLOADED').exists():download('paired')
 if state['moments'] and not (B/'MOMENTS_DOWNLOADED').exists():download('moments')
 return state
def download(kind):
 with c.open_sftp() as ftp:
  ftp.get(R+'/'+kind+'_audit.json',str(B/(kind+'_audit.json')));m=json.loads((B/(kind+'_audit.json')).read_text())
  for name,info in m['images'].items():
   p=B/name;p.parent.mkdir(exist_ok=True);ftp.get(R+'/'+name,str(p));assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
  if kind=='moments':ftp.get(R+'/moments_arrays.npz',str(B/'moments_arrays.npz'))
 (B/(kind.upper()+'_DOWNLOADED')).write_text('Downloaded; visual QA pending.\n');print('DOWNLOADED',kind,flush=True)
try:
 if sys.argv[1]=='deploy':
  cmd(f'test ! -e {R} && mkdir -p {R}/logs')
  with c.open_sftp() as ftp:
   for name in ['exp21_moments.f90','moments_task.py','plot_evidence.py']:ftp.put(str(B/name),R+'/'+name)
   for name,label,action in [('preflight.pbs','EvidenceCheck','moments_task.py preflight'),('run.pbs','EvidenceMoments','moments_task.py "${PBS_ARRAYID:?}"'),('paired.pbs','EvidencePaired','plot_evidence.py paired'),('moments.pbs','EvidencePlots','plot_evidence.py moments')]:
    with ftp.open(R+'/'+name,'w') as f:f.write(pbs(label,action))
  print(cmd(f'''set -eu
cd {R}
gfortran -O3 -ffree-line-length-none -I.. exp21_moments.f90 ../MCPE42_new.o ../RKmethod.o -o exp21_moments
export PYTHONPATH={DEPS}
{PY} -m py_compile moments_task.py plot_evidence.py
cd logs
qsub ../paired.pbs > ../paired_job.txt
qsub ../preflight.pbs > ../preflight_job.txt
cat ../paired_job.txt ../preflight_job.txt
'''),flush=True)
 elif sys.argv[1] in ['watch','advance']:
  old=None
  for i in range(240 if sys.argv[1]=='watch' else 1):
   state=advance()
   if state!=old:print(json.dumps(state),flush=True);old=state
   if state['paired'] and state['moments']:break
   if sys.argv[1]=='watch':time.sleep(10)
 else:raise ValueError(sys.argv[1])
finally:c.close()
