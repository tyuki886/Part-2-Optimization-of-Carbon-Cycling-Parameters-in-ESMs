"""Paired-seed improvement, exact MSE decomposition and Taylor diagrams."""
from pathlib import Path
import sys,json,hashlib
B=Path(__file__).resolve().parent;P=B.parent
for d in [P,P.parent/'twin_work_3x3/python_deps',P.parent/'power_combined/python_deps']:sys.path.insert(0,str(d))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from scipy.stats import bootstrap
from PIL import Image
import plot_corrected as plot
NS=[12,15,18,21,24,27,30];VARS=[('Catm',7),('Cocean',8),('ALK',9)]
GROUPS=[(5,4,1),(7,5,2),(8,6,3)]
COLORS=['#111111','#0072B2','#E69F00','#009E73','#CC79A7','#D55E00','#56B4E9','#8C564B']
MARKERS=['h','o','s','^','D','v','P','X']
def setup():
    plot.configure_font(P);out=B/'figures';out.mkdir(exist_ok=True)
    return out
def save(fig,path,info,receipt):
    fig.canvas.draw();fig.savefig(path,dpi=300);plt.close(fig)
    with Image.open(path) as im:im.verify()
    with Image.open(path) as im:size=list(im.size)
    receipt[str(path.relative_to(B))]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':size,**info}
    print('FIGURE_READY',path.name,flush=True)
def paired():
    out=setup();summary=json.loads((P/'summary.json').read_text());receipt={};allrows=[]
    assert summary['RMSE_window_TU']==[90000,100000] and summary['all_seeds_retained']
    for obs,v,cv in GROUPS:
        base=np.array(summary['RMSE_per_seed'][f'M22_v{cv}']);assert base.shape==(10,10)
        fig,axes=plt.subplots(1,3,figsize=(16,5.7))
        for ax,(var,j) in zip(axes,VARS):
            means=[];lower=[];upper=[];nsuccess=[];points=[]
            for n in NS:
                a=np.array(summary['RMSE_per_seed'][f'M{n}_v{v}']);diff=base[:,j]-a[:,j]
                # Resample paired seed indices, never native timesteps.
                res=bootstrap((base[:,j],a[:,j]),lambda x,y,axis:np.mean(x-y,axis=axis),paired=True,vectorized=True,
                    confidence_level=.95,n_resamples=19999,method='percentile',random_state=20260913)
                lo,hi=res.confidence_interval;mean=diff.mean();assert lo<=mean<=hi
                means.append(mean);lower.append(lo);upper.append(hi);nsuccess.append(int((diff>0).sum()));points.append(diff)
                allrows.append({'obs':obs,'variable':var,'scheme':n,'seed_differences':diff.tolist(),'mean_difference':float(mean),'CI95':[float(lo),float(hi)],'seeds_improved':int((diff>0).sum())})
            x=np.arange(7)
            for i,diff in enumerate(points):
                sc=ax.scatter(i+np.linspace(-.16,.16,10),diff,color='#777777',s=16,alpha=.65,zorder=3)
                np.testing.assert_array_equal(np.asarray(sc.get_offsets())[:,1],diff)
            means=np.array(means);lower=np.array(lower);upper=np.array(upper)
            ax.errorbar(x,means,yerr=[means-lower,upper-means],fmt='D',color='#2166AC',capsize=4,markersize=5,lw=1.5,zorder=4)
            ax.axhline(0,color='black',lw=.8);ax.set_xticks(x);ax.set_xticklabels([str(n) for n in NS]);ax.set_title(var)
            ax.set_xlabel('MCPE scheme');ax.set_ylabel(f'RMSE(CDA{obs}) - RMSE(MCPE)');ax.grid(axis='y',alpha=.2)
            for i,k in enumerate(nsuccess):ax.text(i,.98,f'{k}/10',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=9)
            ax.margins(y=.2)
        fig.suptitle(f'Paired-seed RMSE improvement relative to CDA{obs} ({obs}obs)',fontsize=16,y=.99)
        fig.legend(handles=[Line2D([],[],marker='o',ls='',color='#777777',label='Individual paired seed'),Line2D([],[],marker='D',color='#2166AC',label='Mean difference and pointwise 95% bootstrap interval')],loc='upper center',bbox_to_anchor=(.5,.95),ncol=2,frameon=False)
        fig.text(.5,.027,'90000–100000 TU | Ensemble-mean state estimates | All 10 seeds | Positive = lower MCPE RMSE | Labels: improved seeds / 10',ha='center',fontsize=10)
        fig.text(.5,.008,'Exploratory pointwise intervals; no multiple-comparison adjustment. Bootstrap resamples paired seeds, not time steps.',ha='center',fontsize=9)
        fig.tight_layout(rect=(0,.065,1,.86));save(fig,out/f'paired_RMSE_improvement_{obs}obs.png',{'paired_seeds':10,'variables':3},receipt)
    (B/'paired_audit.json').write_text(json.dumps({'images':receipt,'values':allrows,'method':'paired percentile bootstrap; 19999 resamples; RNG seed 20260913; pointwise intervals'},indent=2))
    (B/'PAIRED_READY').write_text('3 paired-seed figures; visual QA pending.\n')
def moments(cached=False):
    out=setup();receipt={};data={};rows=[]
    cache=np.load(B/'moments_arrays.npz') if cached else None
    for obs,v,cv in GROUPS:
        for n,k in [(22,cv)]+[(n,v) for n in NS]:
            if (n,k) in data:continue
            if cache is not None:
                data[n,k]=cache[f'M{n}_v{k}'].copy()
                assert data[n,k].shape==(10,10,6) and np.isfinite(data[n,k]).all()
                continue
            zs=[]
            for s in range(10):
                d=B/'runs'/f'M{n}_v{k}'/f'seed{s}';assert (d/'READY').exists() and not (d/'FAILED').exists()
                a=np.loadtxt(d/'state_moments.txt',skiprows=1)[:,1:];assert a.shape==(10,6)
                zs.append(a)
            data[n,k]=np.array(zs)
    for obs,v,cv in GROUPS:
        keys=[(22,cv)]+[(n,v) for n in NS];labels=[f'CDA{obs}']+[f'M{n}' for n in NS]
        fig,axes=plt.subplots(1,3,figsize=(16,6))
        for ax,(var,j) in zip(axes,VARS):
            components=[]
            for key in keys:
                a=data[key][:,j,:];mx,mt,vx,vt,cov,mse=a.T
                terms=np.array([(mx-mt)**2,(np.sqrt(vx)-np.sqrt(vt))**2,2*(np.sqrt(vx*vt)-cov)])
                assert terms.min()>-1e-10;terms=np.maximum(terms,0)
                np.testing.assert_allclose(terms.sum(0),mse,rtol=1e-8,atol=1e-10);components.append(terms.mean(1))
                rows.append({'obs':obs,'variable':var,'method':labels[keys.index(key)],'mean_MSE':float(mse.mean()),'components':terms.mean(1).tolist()})
            comp=np.array(components);bottom=np.zeros(8)
            for k,c in enumerate(['#4C72B0','#DD8452','#8172B3']):
                bars=ax.bar(np.arange(8),comp[:,k],bottom=bottom,color=c,width=.72,edgecolor='white',lw=.4)
                np.testing.assert_allclose([b.get_height() for b in bars],comp[:,k],rtol=1e-10,atol=1e-12);bottom+=comp[:,k]
            ax.set_xticks(np.arange(8));ax.set_xticklabels(labels,rotation=45,ha='right',fontsize=9);ax.set_title(var);ax.set_ylabel('Mean squared error');ax.set_ylim(bottom=0);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
        fig.suptitle(f'State-estimation error decomposition ({obs}obs)',fontsize=16,y=.99)
        fig.legend(handles=[Patch(color=c,label=l) for c,l in zip(['#4C72B0','#DD8452','#8172B3'],['Squared mean bias','Variance-amplitude mismatch','Correlation mismatch'])],loc='upper center',bbox_to_anchor=(.5,.95),ncol=3,frameon=False)
        fig.text(.5,.025,'90000–100000 TU | Ensemble-mean states | Components computed per seed, then averaged over all 10 seeds',ha='center',fontsize=10)
        fig.text(.5,.006,'Stack height is mean MSE, not the square of the mean RMSE. Population moments use all native 0.01-TU steps.',ha='center',fontsize=9)
        fig.tight_layout(rect=(0,.055,1,.86));save(fig,out/f'MSE_decomposition_{obs}obs.png',{'methods':8,'components':3},receipt)
        # Single representative point from pooled within-seed centered moments; also show every seed.
        fig,axes=plt.subplots(1,3,figsize=(16,6.8),subplot_kw={'projection':'polar'})
        for ax,(var,j) in zip(axes,VARS):
            stats=[]
            for key in keys:
                a=data[key][:,j,:];vx,vt,cov=a[:,2],a[:,3],a[:,4]
                r=np.clip(cov/np.sqrt(vx*vt),-1,1);ratio=np.sqrt(vx/vt)
                pooled_r=float(np.mean(cov)/np.sqrt(np.mean(vx)*np.mean(vt)));pooled_ratio=float(np.sqrt(np.mean(vx)/np.mean(vt)))
                stats.append((r,ratio,pooled_r,pooled_ratio))
            rmax=max(1.5,1.15*max(float(s[1].max()) for s in stats))
            theta=np.linspace(0,np.pi,181);rad=np.linspace(0,rmax,150);tt,rr=np.meshgrid(theta,rad)
            centered=np.sqrt(np.maximum(0,1+rr**2-2*rr*np.cos(tt)))
            cs=ax.contour(tt,rr,centered,levels=5,colors='#BBBBBB',linewidths=.6);ax.clabel(cs,inline=True,fontsize=7,fmt='%.1f')
            ax.plot(theta,np.ones_like(theta),color='#888888',ls='--',lw=.8)
            for i,(r,ratio,pr,ps) in enumerate(stats):
                ax.scatter(np.arccos(r),ratio,s=12,color=COLORS[i],alpha=.28,marker=MARKERS[i])
                ax.plot(np.arccos(np.clip(pr,-1,1)),ps,marker=MARKERS[i],ls='',color=COLORS[i],markersize=7)
            ax.plot(0,1,marker='*',color='black',markersize=12,ls='')
            ticks=np.array([1,.9,.7,.5,0,-.5,-.7,-.9,-1])
            ax.set_thetamin(0);ax.set_thetamax(180);ax.set_thetagrids(np.degrees(np.arccos(ticks)),[f'{r:g}' for r in ticks],fontsize=8)
            ax.set_ylim(0,rmax);ax.set_title(var+' | correlation',pad=18);ax.set_rlabel_position(100);ax.tick_params(axis='y',labelsize=8);ax.grid(alpha=.3)
        fig.suptitle(f'Taylor diagrams of state estimates ({obs}obs)',fontsize=16,y=.99)
        handles=[Line2D([],[],color=c,marker=m,ls='',label=l) for c,m,l in zip(COLORS,MARKERS,labels)]
        fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.94),ncol=8,frameon=False,fontsize=10)
        fig.text(.5,.1,'Radius: standard deviation / truth SD | Angle: correlation | Grey contours: normalized centered RMSE | Truth: black star at (1, 0)',ha='center',fontsize=9)
        fig.text(.5,.07,'Faint points: 10 individual seeds; large symbols: pooled within-seed centered moments. No time-series averaging.',ha='center',fontsize=9)
        fig.text(.5,.04,'90000–100000 TU | Ensemble-mean states | Mean bias is excluded here and shown in the MSE decomposition.',ha='center',fontsize=9)
        fig.subplots_adjust(top=.80,bottom=.19,left=.055,right=.97,wspace=.3)
        save(fig,out/f'Taylor_diagram_{obs}obs.png',{'methods':8,'seeds_each':10,'representative':'pooled within-seed centered moments'},receipt)
    np.savez_compressed(B/'moments_arrays.npz',**{f'M{n}_v{v}':a for (n,v),a in data.items()})
    (B/'moments_audit.json').write_text(json.dumps({'images':receipt,'decomposition':rows,'window_TU':[90000,100000],'all_seeds_retained':True},indent=2))
    (B/'MOMENTS_READY').write_text('6 figures; moment identities checked; visual QA pending.\n')
if __name__=='__main__':
    if sys.argv[1]=='paired':paired()
    elif sys.argv[1]=='moments':moments()
    elif sys.argv[1]=='moments-cached':moments(cached=True)
