"""One scoped parameter-ensemble plotting job from existing statistics."""
from pathlib import Path
import sys,getpass,json,hashlib,time,paramiko
B=Path(__file__).resolve().parent;R='/public/home/hou/wyh/MCPE26.0/'+B.name
SUB='parameter_ensemble_20260913';OUT=B/SUB;OUT.mkdir(exist_ok=True)
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),look_for_keys=False,allow_agent=False,timeout=25)
def cmd(s):
 _,o,e=c.exec_command(s,timeout=120);a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);return a
try:
 if sys.argv[1]=='deploy':
  cmd(f'test ! -e {R}/{SUB} && test ! -e {R}/plot_parameter_ensemble.py && mkdir {R}/{SUB}')
  with c.open_sftp() as ftp:
   ftp.put(str(B/'plot_parameter_ensemble.py'),R+'/plot_parameter_ensemble.py')
   body=f'''#!/bin/bash
#PBS -N ParamEnsemble
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=00:30:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
{PY} plot_parameter_ensemble.py > {SUB}/progress.log 2>&1
'''
   with ftp.open(R+'/'+SUB+'/run.pbs','w') as f:f.write(body)
  expected=hashlib.sha256((B/'plot_parameter_ensemble.py').read_bytes()).hexdigest()
  code=f'import pathlib,hashlib;assert hashlib.sha256(pathlib.Path("plot_parameter_ensemble.py").read_bytes()).hexdigest()=="{expected}"'
  print(cmd(f"cd {R} && {PY} -c '{code}' && {PY} -m py_compile plot_parameter_ensemble.py && cd {SUB} && qsub run.pbs > job.txt && cat job.txt"),flush=True)
 elif sys.argv[1]=='watch':
  old=None
  for k in range(90):
   code='from pathlib import Path;import json;b=Path('+repr(R+'/'+SUB)+');print(json.dumps(dict(ready=(b/"READY").exists(),failed=(b/"FAILED").read_text() if (b/"FAILED").exists() else None,progress=(b/"progress.log").read_text().splitlines()[-3:] if (b/"progress.log").exists() else [],job=(b/"job.txt").read_text().strip())))'
   state=json.loads(cmd(f"{PY} - <<'STATEPY'\n{code}\nSTATEPY"))
   if state!=old:print(json.dumps(state),flush=True);old=state
   if state['failed']:raise RuntimeError(state)
   if state['ready']:
    with c.open_sftp() as ftp:
     for name in ['audit.json','READY','job.txt','progress.log','plot_arrays.npz']:ftp.get(R+'/'+SUB+'/'+name,str(OUT/name))
     m=json.loads((OUT/'audit.json').read_text())
     for name,info in m['images'].items():
      p=OUT/name;p.parent.mkdir(exist_ok=True);ftp.get(R+'/'+SUB+'/'+name,str(p));assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
    print('DOWNLOADED_14_PARAMETER_PNG',flush=True);break
   time.sleep(10)
 else:raise ValueError(sys.argv[1])
finally:c.close()
