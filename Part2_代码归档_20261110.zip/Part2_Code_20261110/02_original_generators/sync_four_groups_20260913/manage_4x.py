from pathlib import Path
import sys,getpass,json,hashlib
import paramiko
B=Path(__file__).resolve().parent;R='/public/home/hou/wyh/MCPE26.0/'+B.name
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=30,look_for_keys=False,allow_agent=False)
def run(s):
    _,o,e=c.exec_command(s,timeout=120);a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);return a
try:
    action=sys.argv[1]
    with c.open_sftp() as ftp:
        if action=='submit':
            run(f'test ! -e {R}/psd4x_job.json')
            ftp.put(str(B/'recompute_4x.py'),R+'/recompute_4x.py')
            h=hashlib.sha256((B/'recompute_4x.py').read_bytes()).hexdigest();assert run(f'sha256sum {R}/recompute_4x.py').split()[0]==h
            job=run(f'cd {R}/logs && qsub -N PSD4x -q new -l nodes=1:ppn=1 -l walltime=00:30:00 -j oe <<\'EOF\'\n#!/bin/bash\nset -eu\ncd {R}\nexport OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1\n{PY} recompute_4x.py > psd4x.log 2>&1\nEOF').strip()
            meta=json.dumps({'job':job,'script_sha256':h});(B/'psd4x_job.json').write_text(meta)
            with ftp.open(R+'/psd4x_job.json','w') as f:f.write(meta)
            print(job,flush=True)
        elif action in ['status','collect']:
            job=json.loads((B/'psd4x_job.json').read_text())['job']
            print(run(f'qstat {job} 2>/dev/null || true; tail -n 8 {R}/psd4x.log; test ! -e {R}/psd_4x_20260914/DONE || cat {R}/psd_4x_20260914/DONE'),flush=True)
            if action=='collect':
                run(f'test -f {R}/psd_4x_20260914/DONE');out=B/'psd_4x_20260914';out.mkdir(exist_ok=True)
                for n in ['plot_data.json','seed_spectra.npz','audit.json','DONE']:
                    ftp.get(R+'/psd_4x_20260914/'+n,str(out/n))
                    assert run(f'sha256sum {R}/psd_4x_20260914/{n}').split()[0]==hashlib.sha256((out/n).read_bytes()).hexdigest()
                print('DOWNLOADED_HASH_VERIFIED')
        # Collect the already submitted independent carbon-feedback experiment if ready.
        rf='/public/home/hou/wyh/MCPE26.0/carbon_feedback_off_20260914';lf=B.parent/'carbon_feedback_off_20260914'/'analysis'
        print(run(f'tail -n 4 {rf}/analysis.log'),flush=True)
        if run(f'if test -e {rf}/analysis/ANALYSIS_DONE; then echo yes; fi').strip()=='yes':
            lf.mkdir(exist_ok=True)
            for n in ['spectra.npz','audit.json','ANALYSIS_DONE']:ftp.get(rf+'/analysis/'+n,str(lf/n))
            audit=json.loads((lf/'audit.json').read_text());assert audit['spectra_sha256']==hashlib.sha256((lf/'spectra.npz').read_bytes()).hexdigest()
            print('FEEDBACK_ANALYSIS_DOWNLOADED_HASH_VERIFIED',flush=True)
finally:c.close()
