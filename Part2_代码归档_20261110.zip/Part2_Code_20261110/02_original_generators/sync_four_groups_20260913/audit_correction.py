"""Read-only audit of delivered correction figures; Decimal arithmetic independent of plot helpers."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,hashlib,getpass,os,sys,io,contextlib
import paramiko
import numpy as np
B=Path(__file__).resolve().parent;A=B/'correction_audit';A.mkdir(exist_ok=True)
SCHEMES=[12,15,18,21,24,27,30];VARS=['x1','x2','x3','w','eta','ice','TL','Catm','Cocean','ALK']
R='/public/home/hou/wyh/MCPE26.0/'+B.name
getcontext().prec=40
def fetch():
    code='''from pathlib import Path
import json,hashlib
B=Path(%r)
rows=[]
for n in [12,15,18,21,24,27,30]:
 for v in [4,5,6]:
  for seed in range(10):
   d=B/'runs'/('M%%d_v%%d'%%(n,v))/('seed%%d'%%seed)
   p=d/('rmse_M%%02d_v%%02d.txt'%%(n,v))
   assert (d/'READY').exists() and not (d/'FAILED').exists()
   raw=p.read_bytes()
   rows.append(dict(scheme=n,variant=v,seed=seed,path=str(p),text=raw.decode(),sha256=hashlib.sha256(raw).hexdigest(),scalars=(d/'audit_scalars.txt').read_text()))
print(json.dumps(rows))
''' % R
    c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
    try:
        _,o,e=c.exec_command("/public/home/hou/miniconda3/envs/yuki/bin/python - <<'AUDITPY'\n"+code+"\nAUDITPY",timeout=120)
        a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b)
        raw=json.loads(a);assert len(raw)==210
        (A/'raw_rmse.json').write_text(json.dumps(raw,indent=2))
    finally:c.close()
def audit():
    raw=json.loads((A/'raw_rmse.json').read_text());delivery=json.loads((B/'delivery.json').read_text());summary=json.loads((B/'summary.json').read_text())
    expected={r['path']:r['sha256'] for r in delivery['receipts']};values={}
    for r in raw:
        n,v,s=r['scheme'],r['variant'],r['seed'];key=(n,v,s)
        assert key not in values and r['sha256']==expected[r['path']]
        a=[Decimal(x) for x in r['text'].split()];assert len(a)==10 and all(x.is_finite() and x>0 for x in a)
        np.testing.assert_allclose([float(x) for x in a],summary['RMSE_per_seed'][f'M{n}_v{v}'][s],rtol=0,atol=1e-14)
        scal=list(map(int,r['scalars'].splitlines()[0].split()))
        assert scal==[15000000 if v==6 else 10000000,9000000,10000000,1000000,0]
        values[key]=a
        p=A/'fixtures'/f'S{n}/seed{s}'/f'rmse_M{n:02d}_v{v:02d}.txt';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(r['text'])
    results=[];reversals=[]
    for v in [4,5,6]:
        for n in SCHEMES[1:]:
            for j,var in enumerate(VARS):
                base=[values[12,v,s][j] for s in range(10)];test=[values[n,v,s][j] for s in range(10)]
                each=[(b-m)/b*100 for b,m in zip(base,test)]
                mean_percent=sum(each)/10
                percent_of_means=(sum(base)-sum(test))/sum(base)*100
                weighted=sum((b/sum(base))*p for b,p in zip(base,each))
                assert abs(weighted-percent_of_means)<Decimal('1e-30')
                item=dict(scheme=n,obs={4:5,5:7,6:8}[v],variable=var,baseline_mean=float(sum(base)/10),scheme_mean=float(sum(test)/10),
                    mean_seed_percent=float(mean_percent),percent_from_mean_RMSE=float(percent_of_means),seeds_improved=sum(m<b for b,m in zip(base,test)),
                    seed_baseline=[float(x) for x in base],seed_scheme=[float(x) for x in test],seed_percent=[float(x) for x in each])
                results.append(item)
                if mean_percent*percent_of_means<0:reversals.append(item)
    # Run only the actual unmodified plot construction; intercept saves in memory.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    oldsave=plt.Figure.savefig;bindings=[]
    def capture(fig,path,*args,**kwargs):
        obs=int(Path(path).name.split('_')[-1].split('obs')[0]);assert len(fig.axes)==10
        for j,ax in enumerate(fig.axes):
            assert len(ax.patches)==6
            for n,p in zip(SCHEMES[1:],ax.patches):
                row=next(x for x in results if x['scheme']==n and x['obs']==obs and x['variable']==VARS[j])
                assert abs(p.get_height()-row['mean_seed_percent'])<1e-9
                bindings.append(dict(obs=obs,scheme=n,variable=VARS[j],actual_bar=p.get_height(),independent_decimal=row['mean_seed_percent']))
    source=(B/'plot_corr.py').read_text(encoding='utf-8')
    code=source[:source.index('# ============ 修正率表')]
    env={k:os.environ.get(k) for k in ['MCPE_RESULTS_DIR','MCPE_FIGURES_DIR','MCPE_TAG','MCPE_CORR_TITLE_TEMPLATE']}
    os.environ.update(MCPE_RESULTS_DIR=str(A/'fixtures'),MCPE_FIGURES_DIR=str(A/'unused_output'),MCPE_TAG='sync',MCPE_CORR_TITLE_TEMPLATE='RMSE correction rate vs MCPE12 ({obs}obs)')
    plt.Figure.savefig=capture
    try:
        with contextlib.redirect_stdout(io.StringIO()):exec(compile(code,str(B/'plot_corr.py'),'exec'),{'__file__':str(B/'plot_corr.py')})
    finally:
        plt.Figure.savefig=oldsave;plt.close('all')
        for k,val in env.items():
            if val is None:os.environ.pop(k,None)
            else:os.environ[k]=val
    assert len(bindings)==180
    for name,info in delivery['images'].items():
        if name.startswith('correction_rate/'):
            assert hashlib.sha256((B/'figures'/name).read_bytes()).hexdigest()==info['sha256']
    report=dict(raw_runs_verified=210,bars_checked=180,figure_formula='mean_s[100*(RMSE12_s-RMSEn_s)/RMSE12_s]',
      alternative_formula='100*(mean_s(RMSE12_s)-mean_s(RMSEn_s))/mean_s(RMSE12_s)',
      sign_reversal_count=len(reversals),sign_reversals=reversals,values=results,bar_bindings=bindings,delivered_figures_changed=False)
    (A/'audit.json').write_text(json.dumps(report,indent=2))
    print('RAW_RUNS_VERIFIED',210,'BARS_CHECKED',len(bindings),'SIGN_REVERSALS',len(reversals))
    print('8obs ALK: scheme, baseline mean, scheme mean, plotted %, mean-RMSE %, seeds improved')
    for x in results:
        if x['obs']==8 and x['variable']=='ALK':print(x['scheme'],x['baseline_mean'],x['scheme_mean'],x['mean_seed_percent'],x['percent_from_mean_RMSE'],x['seeds_improved'])
    x=next(x for x in results if x['obs']==8 and x['scheme']==18 and x['variable']=='ALK')
    print('MCPE18 ALK per seed: seed, baseline, scheme, percent')
    for s,(b,m,p) in enumerate(zip(x['seed_baseline'],x['seed_scheme'],x['seed_percent'])):print(s,b,m,p)
    print('SIGN_REVERSALS',[(x['obs'],x['scheme'],x['variable']) for x in reversals])
if __name__=='__main__':
    if sys.argv[1]=='fetch':fetch()
    elif sys.argv[1]=='audit':audit()
