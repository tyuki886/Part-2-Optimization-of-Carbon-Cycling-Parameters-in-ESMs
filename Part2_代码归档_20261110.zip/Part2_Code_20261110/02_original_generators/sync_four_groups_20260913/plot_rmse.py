# -*- coding: utf-8 -*-
"""C-80 标准出图（C-79 修订版：碳 top10 回归 W500 旧名单）（样式照 C-66 plot_c66_15figs.py，2026-08-08 用户钦定格式）：
15 方案（MCPE6-20）× 每图 2x5=10 子图 × 7 柱（CTL/CDA5/CDA7/CDA8/MCPE-5obs/7obs/8obs）
CTL = results_C80/ctl/seed{sd}/rmse_M10_v00.txt
口径：10 seed 均值（全样本，不剔除任何 seed）；窗口 90000-100000 TU（逐点平均 RMSE）
输出：results_C80/figures/rmse_C80_MCPE{ns}.png（dpi=300）+ 汇总图 rmse_C80_summary.png
运行: python3 plot_c79_15figs.py（超算 BASE 目录）
"""
import os
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path(os.environ.get('MCPE_RESULTS_DIR', str(ROOT / 'results_C80')))
OUT = Path(os.environ.get('MCPE_FIGURES_DIR', str(BASE / 'figures')))
OUT.mkdir(parents=True, exist_ok=True)
TAG = os.environ.get('MCPE_TAG', 'C80')
LABEL = os.environ.get('MCPE_LABEL', 'C-80')
TITLE_TEMPLATE = os.environ.get('MCPE_RMSE_TITLE_TEMPLATE')

ST = ['x1', 'x2', 'x3', 'w', 'eta', 'ice', 'TL', 'Catm', 'Cocean', 'ALK']
LB = ['CTL', 'CDA5', 'CDA7', 'CDA8', 'MCPE-5obs', 'MCPE-7obs', 'MCPE-8obs']
CL = ['#7F7F7F', '#5B8FF9', '#4A78D1', '#2F5597', '#E6A23C', '#5CB85C', '#C44E52']
NS = [12,15,18,21,24,27,30]   # 15 方案 MCPE6-20

def load(p):
    if not Path(p).exists():
        return None
    d = np.loadtxt(p, ndmin=1)
    return d if d.size == 10 else None

def all10(pat):
    """全部 10 seed 矩阵（10x10），蒙特卡洛全样本（不剔除任何 seed）"""
    rows = []
    for sd in range(10):
        d = load(pat.format(sd=sd))
        if d is None:
            raise SystemExit(f'MISSING: {pat.format(sd=sd)}')
        rows.append(d)
    return np.vstack(rows)

# ---- 基准：CTL（无同化基线）+ CDA5/7/8（纯同化）----
SB = []
A = all10(str(BASE / 'ctl/seed{sd}/rmse_M10_v00.txt'))
SB.append(np.mean(A, axis=0))
print('CTL  :', ' '.join(f'{x:.3f}' for x in SB[0]))
for v in (1, 2, 3):
    A = all10(str(BASE / f'CDA/seed{{sd}}/rmse_M20_v0{v}.txt'))
    SB.append(np.mean(A, axis=0))

# ---- MCPE：15 方案 × 3 变体（均值，全样本）----
M = {}
for ns in NS:
    for o, v in enumerate([4, 5, 6]):
        A = all10(str(BASE / f'S{ns}/seed{{sd}}/rmse_M{ns:02d}_v0{v}.txt'))
        M[(ns, o)] = np.mean(A, axis=0)

print('CDA5 :', ' '.join(f'{x:.3f}' for x in SB[1]))
print('CDA7 :', ' '.join(f'{x:.3f}' for x in SB[2]))
print('CDA8 :', ' '.join(f'{x:.3f}' for x in SB[3]))

# ============ 十五张方案图（每图 2x5=10 子图，7 柱，无误差棒） ============
for ns in NS:
    fig, axes = plt.subplots(2, 5, figsize=(22, 10))
    axes = axes.flatten()
    for si in range(10):
        ax = axes[si]
        meds = [SB[b][si] for b in range(4)]
        for o in range(3):
            meds.append(M[(ns, o)][si])
        x = np.arange(7)
        ax.bar(x, meds, color=CL)
        for i, b in enumerate(ax.patches):
            h = b.get_height()
            ax.text(b.get_x() + b.get_width()/2, h + 0.02*max(max(meds), 0.01),
                    f'{h:.3f}', ha='center', fontsize=6, rotation=90)
        ax.set_xticks(x)
        ax.set_xticklabels(LB, rotation=45, ha='right', fontsize=7)
        ax.set_title(ST[si], fontsize=11)
        ax.grid(axis='y', alpha=0.3)
    title = (TITLE_TEMPLATE.format(ns=ns) if TITLE_TEMPLATE
             else f'{LABEL} MCPE{ns} RMSE by method (90000-100000 TU, mean of 10 seeds)')
    fig.suptitle(title, fontsize=14, fontweight='bold')
    plt.tight_layout()
    fig.savefig(OUT / f'rmse_{TAG}_MCPE{ns}.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f'Saved: rmse_{TAG}_MCPE{ns}.png')

# ============ 汇总图：10 变量平均 RMSE 随方案数（MCPE-S5/S7/S8 + 参考线） ============
if os.environ.get('MCPE_SKIP_SUMMARY') == '1':
    print('Summary figure skipped by MCPE_SKIP_SUMMARY.')
    raise SystemExit(0)

fig, ax = plt.subplots(figsize=(11, 6.5))
var_mean = lambda pat: np.mean(all10(pat), axis=0).mean()
for o, (l, c, mk) in enumerate([('MCPE-5obs', '#E6A23C', 'o'),
                                ('MCPE-7obs', '#5CB85C', 's'),
                                ('MCPE-8obs', '#C44E52', '^')]):
    ys = [var_mean(str(BASE / f'S{ns}/seed{{sd}}/rmse_C39_v0{o+4}.txt')) for ns in NS]
    ax.plot(NS, ys, label=l, color=c, marker=mk, lw=2, ms=6)
ref = [('CTL', SB[0].mean(), '#7F7F7F', '--'),
       ('CDA5', SB[1].mean(), '#5B8FF9', ':'),
       ('CDA7', SB[2].mean(), '#4A78D1', ':'),
       ('CDA8', SB[3].mean(), '#2F5597', ':')]
for l, y, c, s in ref:
    ax.axhline(y, color=c, ls=s, lw=1.5, label=f'{l} = {y:.4f}')
ax.set_xticks(NS)
ax.set_xlabel('MCPE scheme (number of estimated params)')
ax.set_ylabel('Mean RMSE over 10 state variables')
ax.set_title(f'{LABEL}: mean RMSE vs scheme size (90000-100000 TU, mean of 10 seeds)')
ax.legend(fontsize=9)
ax.grid(alpha=0.3)
plt.tight_layout()
fig.savefig(OUT / f'rmse_{TAG}_summary.png', dpi=300, bbox_inches='tight')
plt.close()
print(f'Saved: rmse_{TAG}_summary.png')
print('All figures saved to:', OUT)
