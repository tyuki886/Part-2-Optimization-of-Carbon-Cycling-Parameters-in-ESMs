program test_config
use MCPE42
implicit none
integer::n,k,j
integer,allocatable::r(:)
integer(kind=8),allocatable::c(:,:),s(:,:),first(:),last(:)
real(kind=dp),allocatable::w(:,:)
call configure_parameter_channels()
do n=12,30,3
 r=scheme_est_rows(n)
 allocate(c(size(r),8),s(size(r),8),first(size(r)),last(size(r)),w(size(r),8))
 call quota_channels(n,8,r,c,s,first,last,w)
 do k=1,size(r)
  do j=1,8
   write(*,'(7I14)')n,r(k),j,s(k,j),c(k,j),first(k),last(k)
  enddo
 enddo
 deallocate(r,c,s,first,last,w)
enddo
end program
