"""Scoped upload, one PBS postprocessing job, and verified PNG download."""
from pathlib import Path
import sys,getpass,json,hashlib,time
import paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/'+B.name
SUB='full_record_psd_20260913';OUT=B/SUB;OUT.mkdir(exist_ok=True)
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
def cmd(code):
    _,o,e=c.exec_command(code,timeout=90);a=o.read().decode();b=e.read().decode()
    assert o.channel.recv_exit_status()==0,(a,b)
    return a
try:
    if sys.argv[1]=='deploy':
        cmd(f'test ! -e {R}/{SUB} && test ! -e {R}/full_record_psd.py && mkdir {R}/{SUB}')
        with c.open_sftp() as ftp:
            ftp.put(str(B/'full_record_psd.py'),R+'/full_record_psd.py')
            body=f'''#!/bin/bash
#PBS -N FullRecordPSD
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=00:30:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
{PY} full_record_psd.py > {SUB}/progress.log 2>&1
'''
            with ftp.open(R+'/'+SUB+'/run.pbs','w') as f:f.write(body)
        expected=hashlib.sha256((B/'full_record_psd.py').read_bytes()).hexdigest()
        code=f'import pathlib,hashlib;assert hashlib.sha256(pathlib.Path("full_record_psd.py").read_bytes()).hexdigest()=="{expected}"'
        print(cmd(f"cd {R} && {PY} -c '{code}' && {PY} -m py_compile full_record_psd.py && cd {SUB} && qsub run.pbs > job.txt && cat job.txt"),flush=True)
    elif sys.argv[1]=='watch':
        prev=None
        for attempt in range(120):
            code='from pathlib import Path;import json;b=Path('+repr(R+'/'+SUB)+');print(json.dumps(dict(ready=(b/"READY").exists(),failed=(b/"FAILED").read_text() if (b/"FAILED").exists() else None,progress=(b/"progress.log").read_text().splitlines()[-2:] if (b/"progress.log").exists() else [],job=(b/"job.txt").read_text().strip())))'
            state=json.loads(cmd(f"{PY} - <<'STATEPY'\n{code}\nSTATEPY"))
            if state!=prev:print(json.dumps(state),flush=True);prev=state
            if state['failed']:raise RuntimeError(state)
            if state['ready']:
                with c.open_sftp() as ftp:
                    for name in ['audit.json','READY','job.txt','plot_arrays.npz','progress.log']:
                        ftp.get(R+'/'+SUB+'/'+name,str(OUT/name))
                    meta=json.loads((OUT/'audit.json').read_text());(OUT/'figures').mkdir(exist_ok=True)
                    for name,info in meta['images'].items():
                        p=OUT/'figures'/name;ftp.get(R+'/'+SUB+'/figures/'+name,str(p))
                        assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
                print('DOWNLOADED_7_PNG',flush=True);break
            time.sleep(10)
        else:print('PENDING; no resubmission',flush=True)
    else:raise ValueError(sys.argv[1])
finally:c.close()
