"""Audit-only formatting repair: inactive-channel sentinel needs 19 printed digits."""
from pathlib import Path
import paramiko,getpass,json,hashlib
B=Path(__file__).resolve().parent;R='/public/home/hou/wyh/MCPE26.0/'+B.name
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),look_for_keys=False,allow_agent=False,timeout=25)
try:
    with c.open_sftp() as ftp:
        ftp.rename(R+'/manifest.json',R+'/manifest_initial_io.json')
        for name in ['exp21_new.f90','prepare.py','manifest.json']:ftp.put(str(B/name),R+'/'+name)
    _,o,e=c.exec_command(f'''set -eu
cd {R}
gfortran -O3 -ffree-line-length-none exp21_new.f90 MCPE42_new.o RKmethod.o -o exp21_new_checked
mv -f exp21_new_checked exp21_new
echo SCHEDULE_IO_WIDTH_FIXED
df -h .
''',timeout=120)
    a=o.read().decode();b=e.read().decode();assert o.channel.recv_exit_status()==0,(a,b);print(a)
finally:c.close()
