"""修正初始参数散度后的持续同化谱诊断；只读审计结果，不重算谱。"""
from pathlib import Path
import argparse
import ast
import csv
import hashlib
import json
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parent / 'twin_work_3x3/python_deps'))
sys.path.insert(0, str(BASE.parent / 'power_combined/python_deps'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import MaxNLocator

METHODS = ['CTL', 'CDA8', 'MCPE12', 'MCPE14', 'MCPE16']
LABELS = ['Truth'] + METHODS
VARIABLES = ['x2', 'w', 'eta', 'TL', 'Catm', 'Cocean', 'ALK']
STYLES = {
    'Truth': dict(color='#222222', ls='-', marker=None),
    'CTL': dict(color='#4C72B0', ls='--', marker=None),
    'CDA8': dict(color='#B48A27', ls=':', marker='x'),
    'MCPE12': dict(color='#C44E52', ls='-', marker='o'),
    'MCPE14': dict(color='#64833C', ls=(0, (6, 2)), marker='s'),
    'MCPE16': dict(color='#C36791', ls=(0, (5, 2, 1, 2)), marker='^'),
}
VIEW_RANGES = {'x2': (50000, 50010), 'w': (50000, 50100),
               'eta': (50000, 51000), 'TL': (50000, 50100),
               'Catm': (50000, 51000), 'Cocean': (50000, 100000),
               'ALK': (50000, 100000)}


def original_config(base):
    """仅读取原配置字面量，避免导入 SciPy 或执行旧绘图脚本。"""
    namespace = {'__builtins__': {}, 'dict': dict}
    tree = ast.parse((base / 'original_plot_psd_v10v7.py').read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, ast.Assign):
            names = {t.id for target in node.targets for t in ast.walk(target)
                     if isinstance(t, ast.Name)}
            if names and names <= {'CFG', 'XLIM'}:
                exec(compile(ast.Module(body=[node], type_ignores=[]), 'config', 'exec'), namespace)
    assert list(namespace['CFG']) == VARIABLES
    return namespace['CFG'], namespace['XLIM']


def configure_font(base):
    candidates = [base.parent / 'power_combined/times.ttf',
                  Path('C:/Windows/Fonts/times.ttf')]
    font = next((p for p in candidates if p.is_file()), None)
    if font is not None:
        font_manager.fontManager.addfont(str(font))
    font_manager.findfont('Times New Roman', fallback_to_default=False)
    plt.rcParams.update({'font.family': 'Times New Roman', 'font.size': 11,
        'mathtext.fontset': 'stix', 'pdf.fonttype': 42, 'ps.fonttype': 42,
        'axes.titlesize': 13, 'axes.labelsize': 11, 'xtick.labelsize': 10,
        'ytick.labelsize': 10, 'axes.linewidth': .8,
        'savefig.facecolor': 'white', 'figure.facecolor': 'white'})


def finite(name, values, nonnegative=False):
    values = np.asarray(values)
    if not np.isfinite(values).all():
        raise ValueError('Nonfinite array: ' + name)
    if nonnegative and np.any(values < 0):
        raise ValueError('Negative power/RMSE: ' + name)
    return values


def seven_panel(title, subtitle, description):
    fig = plt.figure(figsize=(14, 13.5))
    outer = fig.add_gridspec(1, 2, left=.078, right=.976, bottom=.075,
                            top=.855, wspace=.23)
    left = outer[0, 0].subgridspec(4, 1, hspace=.58)
    right = outer[0, 1].subgridspec(3, 1, hspace=.40)
    axes = {}
    for names, grid in ((VARIABLES[:4], left), (VARIABLES[4:], right)):
        for i, var in enumerate(names):
            axes[var] = fig.add_subplot(grid[i, 0])
    fig.suptitle(title, y=.981, fontsize=16)
    fig.text(.5, .955, subtitle, ha='center', fontsize=12)
    fig.text(.5, .932, description, ha='center', fontsize=10.7)
    return fig, axes


def shared_legend(fig, handles, labels):
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(.52, .912),
               ncol=len(labels), frameon=False, fontsize=11,
               handlelength=3.4, columnspacing=1.45)


def draw_line(ax, x, y, label, index, markers=True):
    style = STYLES[label].copy()
    if not markers:
        style['marker'] = None
    stride = max(2, len(x) // 11)
    line, = ax.plot(x, y, linewidth=1.25, markersize=3.8,
                    markerfacecolor='none', markeredgewidth=.8,
                    markevery=(index % stride, stride), label=label, **style)
    np.testing.assert_array_equal(line.get_xdata(), x)
    np.testing.assert_array_equal(line.get_ydata(), y)
    return line


def axis_style(ax, var, xlabel, ylabel, spectrum=False):
    ax.set(title=var, xlabel=xlabel, ylabel=ylabel)
    ax.grid(True, alpha=.23, linestyle=':', linewidth=.7)
    ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0))
    if not spectrum:
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.ticklabel_format(axis='x', style='plain', useOffset=False)


def save_figure(fig, dest, stem):
    """自动检查文字在画布内；正式交付仍须 PNG 目检。"""
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    # Matplotlib 保留视窗外的自动刻度对象，但实际不会绘制这些文字。
    outside_ticks = set()
    for ax in fig.axes:
        for axis in (ax.xaxis, ax.yaxis):
            lo, hi = sorted(axis.get_view_interval())
            for tick in axis.get_major_ticks() + axis.get_minor_ticks():
                if tick.get_loc() < lo - 1e-9 or tick.get_loc() > hi + 1e-9:
                    outside_ticks.update((id(tick.label1), id(tick.label2)))
    for artist in fig.findobj(matplotlib.text.Text):
        if artist.get_visible() and artist.get_text() and id(artist) not in outside_ticks:
            box = artist.get_window_extent(renderer)
            if box.width and box.height:
                assert box.x0 >= -2 and box.y0 >= -2, (stem, artist.get_text(), box)
                assert box.x1 <= width + 2 and box.y1 <= height + 2, (stem, artist.get_text(), box)
    for ext in ('png', 'pdf'):
        fig.savefig(dest / (stem + '.' + ext), dpi=300, facecolor='white')
    plt.close(fig)


def spectrum_figure(dest, cfg, xlim, frequencies, means, mode):
    specs = {
        'native': ('Native-step power spectra of ensemble-mean states',
            '50000–100000 TU; mean of 10 seed spectra; native sampling: 0.01 TU',
            'CDA8: state assimilation only; MCPE: ongoing state and parameter estimation',
            'Power spectrum', LABELS,
            'Ensemble mean first, spectrum second; this is not the mean of member spectra.',
            'Welch/periodogram estimates with mean removal; low-frequency resolution remains window-limited.'),
        'error': ('Native-step spectra of paired state errors',
            '50000–100000 TU; mean of 10 seed spectra; native sampling: 0.01 TU',
            'Error = analysis ensemble mean minus simultaneous Truth; spectrum calculated after differencing',
            'Error power spectrum', METHODS,
            'Mean error is removed by spectral processing; bias and RMSE are reported separately.',
            'These are spectra of paired errors, not differences between two power spectra.'),
        'member': ('Coarse-sampled power spectra averaged over ensemble members',
            '50000–100000 TU; 20 member spectra averaged within each of 10 seeds',
            'Sampling: x2 = 0.1 TU; w, eta, TL, Catm = 1 TU; Cocean, ALK = 10 TU',
            'Power spectrum', LABELS,
            'Spectrum first, member/seed averaging second; Truth uses the same coarse sampling.',
            'Coarse sampling omits intervening evolution; this figure is not a native-step member spectrum.'),
    }
    title, subtitle, description, ylabel, labels, note1, note2 = specs[mode]
    fig, axes = seven_panel(title, subtitle, description)
    details = {}
    for var, ax in axes.items():
        f = frequencies[var]
        handles = [draw_line(ax, f, means[label][var], label, i)
                   for i, label in enumerate(labels)]
        ymax = max(float(means[label][var].max()) for label in labels)
        ax.set(xlim=xlim, ylim=(0, ymax * 1.12 if ymax > 0 else 1))
        axis_style(ax, var, cfg[var]['xlab'], ylabel, spectrum=True)
        assert len(ax.lines) == len(labels)
        details[var] = {'frequency_points': len(f), 'frequency_min': float(f[0]),
                        'frequency_max': float(f[-1]), 'ymax': ymax}
    shared_legend(fig, handles, labels)
    fig.text(.5, .032, note1, ha='center', fontsize=9.7)
    fig.text(.5, .015, note2, ha='center', fontsize=9.2)
    stem = 'evidence_20260908_assim50000-100000_' + mode + '_spectra_overlay'
    save_figure(fig, dest, stem)
    return {'stem': stem, 'variables': details, 'labels': labels}


def time_figure(dest, data):
    fig, axes = seven_panel('State trajectories for seed 0',
        ', '.join(LABELS) + '; fixed diagnostic windows',
        'Analysis ensemble means; native-step points except Cocean and ALK (10 TU for display only)')
    details = {}
    for var, ax in axes.items():
        t = data['CTL'][0]['view_t_' + var]
        truth = data['CTL'][0]['view_truth_' + var]
        handles = [draw_line(ax, t, truth, 'Truth', 0, markers=False)]
        for i, method in enumerate(METHODS):
            d = data[method][0]
            np.testing.assert_array_equal(d['view_t_' + var], t)
            np.testing.assert_array_equal(d['view_truth_' + var], truth)
            handles.append(draw_line(ax, t, d['view_analysis_' + var], method, i + 1))
        first = 50010 if var in ('Cocean', 'ALK') else 50000.01
        np.testing.assert_allclose([t[0], t[-1]], [first, VIEW_RANGES[var][1]], rtol=0, atol=1e-9)
        ax.set_xlim(*VIEW_RANGES[var])
        axis_style(ax, var, 'Time (TU)', 'Model value')
        details[var] = {'window_TU': VIEW_RANGES[var], 'display_points': len(t)}
    shared_legend(fig, handles, LABELS)
    fig.text(.5, .031, 'A preselected single-seed illustration, not an ensemble statistic or a best-case seed.',
             ha='center', fontsize=9.6)
    fig.text(.5, .014, 'The windows differ to show fast and slow variability; full-window RMSE uses all native steps.',
             ha='center', fontsize=9.5)
    stem = 'evidence_20260908_assim_seed0_state_trajectories'
    save_figure(fig, dest, stem)
    return {'stem': stem, 'variables': details, 'labels': LABELS}


def catm_phase_figure(dest, data):
    fig, axes = plt.subplots(5, 1, figsize=(12, 12.5), sharex=True,
                             gridspec_kw={'hspace': .32})
    fig.subplots_adjust(left=.095, right=.974, bottom=.083, top=.855)
    fig.suptitle('Catm forecast and analysis trajectories', y=.981, fontsize=16)
    fig.text(.5, .952, 'Seed 0; 50000–50010 TU; all native steps (0.01 TU)',
             ha='center', fontsize=12)
    fig.text(.5, .929, 'Forecast: before the state update; analysis: after the state update',
             ha='center', fontsize=11)
    low, high = float('inf'), float('-inf')
    for method in METHODS:
        d = data[method][0]
        for field in ('truth', 'analysis', 'forecast'):
            arr = d['Catm_zoom_' + field]
            low, high = min(low, float(arr.min())), max(high, float(arr.max()))
    handles = None
    for method, ax in zip(METHODS, axes):
        d = data[method][0]
        t = d['Catm_zoom_t']
        np.testing.assert_allclose([t[0], t[-1]], [50000.01, 50010], rtol=0, atol=1e-9)
        color = STYLES[method]['color']
        h0, = ax.plot(t, d['Catm_zoom_truth'], color=STYLES['Truth']['color'], lw=1.25)
        h1, = ax.plot(t, d['Catm_zoom_forecast'], color=color, lw=1.25, ls='--')
        h2, = ax.plot(t, d['Catm_zoom_analysis'], color=color, lw=1.25, ls='-')
        integer_t = np.flatnonzero(np.isclose(t, np.rint(t), rtol=0, atol=1e-8))
        ax.plot(t[integer_t], d['Catm_zoom_analysis'][integer_t], color=color,
                marker='o', markerfacecolor='none', markeredgewidth=.8,
                markersize=4, linestyle='none')
        for line, field in ((h0, 'truth'), (h1, 'forecast'), (h2, 'analysis')):
            np.testing.assert_array_equal(line.get_ydata(), d['Catm_zoom_' + field])
        handles = [h0, h1, h2]
        pad = max((high - low) * .08, 1e-10)
        ax.set(xlim=(50000, 50010), ylim=(low - pad, high + pad))
        axis_style(ax, method, '', 'Catm')
    axes[-1].set_xlabel('Time (TU)')
    fig.legend(handles, ['Truth', 'Forecast ensemble mean', 'Analysis ensemble mean'],
               loc='upper center', bbox_to_anchor=(.5, .909), ncol=3,
               frameon=False, fontsize=11, handlelength=3.3)
    fig.text(.5, .041, 'Open circles identify 1-TU sampling times used in the previous Catm spectrum.',
             ha='center', fontsize=10)
    fig.text(.5, .023, 'They coincide with Catm observation updates in CDA8/MCPE; CTL has no assimilation.',
             ha='center', fontsize=10)
    stem = 'evidence_20260908_assim_seed0_Catm_forecast_analysis'
    save_figure(fig, dest, stem)
    return {'stem': stem, 'window_TU': [50000, 50010], 'labels': METHODS}


def file_hash(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load_validated(base):
    """严格消费分析契约；任一结果缺失或审计失败都不出正式合图。"""
    data, audits = {m: [] for m in METHODS}, {m: [] for m in METHODS}
    initial_hashes, truth_hashes, source_hashes = {}, {}, None
    for method in METHODS:
        for seed in range(10):
            folder = base / 'runs' / method / ('seed' + str(seed))
            assert (folder / 'READY').is_file(), 'Missing READY: ' + str(folder)
            assert not (folder / 'SMOKE_READY').exists(), 'Smoke result is not production data'
            audit = json.loads((folder / 'audit.json').read_text(encoding='utf-8'))
            assert audit['schema_version'] == 1 and audit['smoke'] is False
            assert audit['label'] == method and audit['seed'] == seed
            assert audit['window_TU'] == [50000, 100000]
            assert audit['native_window_convention'] == '(start,end]'
            assert audit['native_samples'] == 5000000
            assert audit['ensemble_members'] == 20
            assert audit['variables_order'] == VARIABLES
            assert audit['metric_columns'] == ['rmse', 'bias', 'centered_rmse']
            assert audit['rmse_crosscheck_passed'] is True
            h = audit['initial_members_sha256']
            assert len(h) == 64
            if seed in initial_hashes:
                assert h == initial_hashes[seed], 'Initial parameters differ across methods'
            else:
                initial_hashes[seed] = h
            if source_hashes is None:
                source_hashes = audit['source_sha256']
            else:
                assert source_hashes == audit['source_sha256'], 'Analysis source differs across runs'
            states = np.asarray(audit['state_update_counts'])
            counts = np.asarray(audit['parameter_update_counts'])
            selected = np.asarray(audit['selected_parameter_rows'], dtype=int) - 1
            np.testing.assert_array_equal(states, audit['expected_state_update_counts'])
            assert states.shape == (10,) and counts.shape == (45,)
            assert audit['all_selected_effective_all'] is True
            assert audit['all_selected_effective_window'] is True
            if method in ('CTL', 'CDA8'):
                assert len(selected) == 0 and not counts.any()
                assert not np.asarray(audit['parameter_effective_all']).any()
                assert not np.asarray(audit['parameter_effective_window']).any()
            else:
                assert len(selected) == int(method[4:])
                assert len(set(selected.tolist())) == len(selected)
                assert audit['last_parameter_update_TU'] > 50000
                assert (np.asarray(audit['initial_parameter_sample_std'])[selected] > 0).all()
                assert (np.asarray(audit['parameter_effective_all'])[selected] > 0).all()
                assert (np.asarray(audit['parameter_effective_window'])[selected] > 0).all()
                assert (np.asarray(audit['parameter_max_increment_window'])[selected] > 0).all()
            assert np.count_nonzero(states) == (0 if method == 'CTL' else 8)
            with np.load(folder / 'analysis.npz', allow_pickle=False) as z:
                d = {k: finite(k, z[k]).copy() for k in z.files}
            for phase in ('analysis', 'forecast'):
                metric = d['metrics_' + phase]
                assert metric.shape == (7, 3)
                finite(phase + '_rmse', metric[:, (0, 2)], nonnegative=True)
                np.testing.assert_allclose(metric[:, 0] ** 2,
                    metric[:, 1] ** 2 + metric[:, 2] ** 2, rtol=3e-11, atol=1e-20)
                np.testing.assert_array_equal(metric, audit['metrics_' + phase])
            assert d['legacy_rmse10'].shape == (10,)
            np.testing.assert_allclose(d['metrics_analysis'][:, 0],
                d['legacy_rmse10'][[1, 3, 4, 6, 7, 8, 9]], rtol=0, atol=5.01e-7)
            for var in VARIABLES:
                va = audit['variables'][var]
                assert va['member_mean_matches_legacy'] is True
                assert va['legacy_matches_native_analysis'] is True
                for flavor in ('native', 'legacy'):
                    key = flavor + '_' + var
                    th = va[flavor + '_truth_sha256']
                    assert len(th) == 64
                    if key in truth_hashes:
                        assert truth_hashes[key] == th, 'Truth trajectory differs: ' + key
                    else:
                        truth_hashes[key] = th
                    f = d[flavor + '_f_' + var]
                    assert f.ndim == 1 and len(f) >= 2 and (np.diff(f) > 0).all()
                    assert f[0] >= 0 and f[-1] <= 1.5 + 1e-12
                    if flavor == 'native':
                        assert va['native']['sample_interval_TU'] == .01
                        assert va['native']['samples'] == 5000000
                        fields = ['native_truth', 'native_analysis', 'native_forecast',
                                  'error_analysis', 'error_forecast']
                    else:
                        interval = .1 if var == 'x2' else (10 if var in ('Cocean', 'ALK') else 1)
                        assert va['legacy']['sample_interval_TU'] == interval
                        fields = ['legacy_truth', 'legacy_mean', 'member_mean']
                    for prefix in fields:
                        value = finite(prefix + '_' + var, d[prefix + '_' + var], nonnegative=True)
                        assert value.shape == f.shape
                np.testing.assert_array_equal(d['member_f_' + var], d['legacy_f_' + var])
                members = finite('member_powers_' + var, d['member_powers_' + var], nonnegative=True)
                assert members.shape == (20, len(d['member_f_' + var]))
                np.testing.assert_array_equal(members.mean(axis=0), d['member_mean_' + var])
                if data['CTL']:
                    reference = data['CTL'][0]
                    for prefix in ('native_f', 'legacy_f', 'member_f', 'native_truth', 'legacy_truth'):
                        np.testing.assert_array_equal(d[prefix + '_' + var], reference[prefix + '_' + var])
            data[method].append(d)
            audits[method].append(audit)
    assert len(set(initial_hashes.values())) == 10, 'Seeds must have distinct initial ensembles'
    assert sum(len(v) for v in data.values()) == 50
    return data, audits, {'initial_members_by_seed': initial_hashes,
                          'truth_trajectory_hashes': truth_hashes,
                          'analysis_source_hashes': source_hashes}


def aggregate(data):
    """保留逐 seed 谱，再形成平均；不平均时间序列。"""
    combined, frequencies, means = {}, {}, {}
    for mode, prefix, freq_prefix, truth_prefix in (
            ('native', 'native_analysis', 'native_f', 'native_truth'),
            ('error', 'error_analysis', 'native_f', None),
            ('member', 'member_mean', 'member_f', 'legacy_truth')):
        frequencies[mode] = {}
        labels = METHODS if mode == 'error' else LABELS
        means[mode] = {label: {} for label in labels}
        for var in VARIABLES:
            f = data['CTL'][0][freq_prefix + '_' + var]
            frequencies[mode][var] = f
            combined[mode + '_f_' + var] = f
            if truth_prefix is not None:
                truth = data['CTL'][0][truth_prefix + '_' + var]
                means[mode]['Truth'][var] = truth
                combined[mode + '_Truth_' + var] = truth
            for method in METHODS:
                stack = np.stack([d[prefix + '_' + var] for d in data[method]])
                assert stack.shape == (10, len(f))
                means[mode][method][var] = stack.mean(axis=0)
                combined[mode + '_' + method + '_' + var] = stack
    # 原粗采样集合均值谱和预报/误差谱保留机器数据，避免产出重复合图。
    for method in METHODS:
        for var in VARIABLES:
            for prefix in ('legacy_mean', 'native_forecast', 'error_forecast'):
                combined[prefix + '_' + method + '_' + var] = np.stack([
                    d[prefix + '_' + var] for d in data[method]])
            combined['member_powers_' + method + '_' + var] = np.stack([
                d['member_powers_' + var] for d in data[method]])
        for phase in ('analysis', 'forecast'):
            combined['metrics_' + phase + '_' + method] = np.stack([
                d['metrics_' + phase] for d in data[method]])
    return frequencies, means, combined


def export_metrics(dest, data):
    fieldnames = ['method', 'phase', 'seed', 'variable', 'rmse', 'bias', 'centered_rmse',
                  'window_start_TU', 'window_end_TU', 'sample_interval_TU',
                  'native_samples', 'ensemble_statistic', 'seed_statistic']
    metric_means = {phase: {} for phase in ('analysis', 'forecast')}
    with (dest / 'state_metrics.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for method in METHODS:
            for phase in ('analysis', 'forecast'):
                values = np.stack([d['metrics_' + phase] for d in data[method]])
                average = values.mean(axis=0)
                metric_means[phase][method] = average.tolist()
                for seed, array in list(enumerate(values)) + [('mean', average)]:
                    for i, var in enumerate(VARIABLES):
                        writer.writerow({'method': method, 'phase': phase, 'seed': seed, 'variable': var,
                            'rmse': format(float(array[i, 0]), '.17g'),
                            'bias': format(float(array[i, 1]), '.17g'),
                            'centered_rmse': format(float(array[i, 2]), '.17g'),
                            'window_start_TU': 50000, 'window_end_TU': 100000,
                            'sample_interval_TU': .01, 'native_samples': 5000000,
                            'ensemble_statistic': 'ensemble mean state',
                            'seed_statistic': 'arithmetic mean of per-seed metrics' if seed == 'mean' else 'individual seed'})
    lines = ['# 三个碳循环变量的 RMSE', '',
        '50000–100000 TU，逐步（0.01 TU）分析集合均值相对 Truth 的 RMSE，再对 10 个 seed 的 RMSE 取算术平均。窗口为 (50000,100000] TU；数值不带 ±。', '',
        '| Scheme | Catm | Cocean | ALK |', '|---|---:|---:|---:|']
    for method in METHODS:
        array = np.asarray(metric_means['analysis'][method])
        lines.append('| ' + method + ' | ' + ' | '.join(f'{array[i, 0]:.4f}' for i in (4, 5, 6)) + ' |')
    lines += ['', '预报、分析的偏差及去偏差 RMSE 保存在 state_metrics.csv；误差功率谱去除了均值，不能单独反映平均偏差。', '']
    (dest / 'RMSE_table.md').write_text('\n'.join(lines), encoding='utf-8')
    return metric_means


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=BASE)
    args = parser.parse_args()
    base = args.base.resolve()
    dest = base / 'figures'
    assert not (dest / 'COMPLETE').exists(), 'Verified figures already exist; refusing to overwrite'
    configure_font(base)
    cfg, xlim = original_config(base)
    data, audits, verified = load_validated(base)
    frequencies, means, combined = aggregate(data)
    dest.mkdir(parents=True, exist_ok=True)
    chart_map = []
    for mode in ('native', 'error', 'member'):
        chart_map.append(spectrum_figure(dest, cfg, xlim, frequencies[mode], means[mode], mode))
    chart_map.append(time_figure(dest, data))
    chart_map.append(catm_phase_figure(dest, data))
    metric_means = export_metrics(dest, data)
    np.savez_compressed(dest / 'all_seed_diagnostics.npz', **combined)
    summary = {'schema_version': 1, 'experiment': base.name,
        'window_TU': [50000, 100000], 'native_window_convention': '(start,end]',
        'methods': METHODS, 'seeds': 10, 'ensemble_members': 20, 'verified_runs': 50,
        'variables_order': VARIABLES, 'metric_columns': ['rmse', 'bias', 'centered_rmse'],
        'metric_means': metric_means, 'seed_statistic': 'mean of individual seed spectra/metrics, never spectrum of a seed-averaged trajectory',
        'native_spectrum': 'power of native-step analysis ensemble mean; ensemble mean before spectral calculation',
        'error_spectrum': 'power of paired analysis ensemble mean minus Truth; not difference of spectra',
        'member_spectrum': 'coarse-sampled member spectra averaged within each seed, then across seeds',
        'mean_removal_caveat': 'All spectra remove mean and segment constants; assess mean bias separately',
        'sampling_caveat': 'Native mean spectra use 0.01 TU; coarse member spectra retain legacy sampling and can miss intervening evolution',
        'resolution_caveat': 'No interpolation or zero padding; Cocean/ALK low-frequency resolution remains limited by the 50000-TU window',
        'state_phase': 'analysis after updates when scheduled, forecast at other steps; no updates at the terminal 100000-TU endpoint',
        'parameter_initialization': 'Actual C80 top20 initialized with nonzero spread; selected parameters passed effective-update audit',
        'claims': 'No performance improvement is presumed; overlapping spectra are retained without artificial offsets',
        'chart_map': chart_map, 'run_audits': audits, 'cross_run_validation': verified,
        'plot_source_sha256': file_hash(base / 'plot_corrected.py'),
        'automated_layout_check': 'All rendered text inside canvas; actual PNG visual review required before delivery'}
    summary['output_sha256'] = {p.name: file_hash(p) for p in sorted(dest.iterdir()) if p.is_file()}
    (dest / 'corrected_summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False), encoding='utf-8')
    (dest / 'COMPLETE').write_text('50 production runs validated; numerical and automated layout QA passed\n', encoding='ascii')
    print('CORRECTED_FIGURES_DONE', dest, flush=True)


if __name__ == '__main__':
    main()
