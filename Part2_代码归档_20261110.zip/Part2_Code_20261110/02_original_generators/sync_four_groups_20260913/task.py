"""Independent production and channel-event validation for the seven synchronous quotas."""
from pathlib import Path
import json,os,sys,hashlib
import numpy as np
from checked_exec import checked
B=Path(__file__).resolve().parent
C=json.loads((B/'config.json').read_text())
TIMING=B.parent/'entry_timing_balanced_20260913'
OLD=B.parent/'three_channel_complete578_20260913'
OLDPSD=B.parent/'three_channel_figures_psd150k_20260913'
REF=B.parent/'three_channel_full22_20260912/runs'
SCHEMES=C['schemes']
def folder(n,v,seed):return B/'runs'/f'M{n}_v{v}'/f'seed{seed}'
def baseline(v,seed):return REF/f'CDA8{seed}' if v==3 else OLD/'runs'/f'{300+10*v+seed:03d}'
def schedule(n,no,steps):
    cfg=C['configs']['sync'][str(n)];rows=[];channels=[]
    for p in cfg['unique_parameters']:
        row=C['row45'][p];se=cfg['entries_steps'][p][:no];cy=cfg['cycles_steps'][p][:no]
        first=min((x for x in se if x>=0),default=np.iinfo(np.int64).max)
        rows.append([row,first,steps+1]+cy)
        channels.extend([[row,j+1,se[j],cy[j],steps+1] for j in range(no)])
    return rows,channels

def validate(d,n,v,seed,steps,start,end):
    no={0:0,1:5,2:7,3:8,4:5,5:7,6:8}[v]
    scal=(d/'audit_scalars.txt').read_text().splitlines()
    np.testing.assert_array_equal(np.fromstring(scal[0],sep=' ',dtype=np.int64),[steps,start,end,end-start,0])
    state=np.zeros(8,dtype=np.int64)
    for j,o in enumerate(C['observations'][:no]):
        freq=round(C['obs_frequency_TU'][o]*100)
        state[j]=max(0,steps//freq-(1000000+freq-1)//freq+1)
    np.testing.assert_array_equal(np.fromstring(scal[1],sep=' ',dtype=np.int64),state)
    count=np.zeros((45,8),dtype=np.int64);first=np.full((45,8),-1,dtype=np.int64);last=first.copy()
    if v>=4:
        rows,channels=schedule(n,no,steps)
        np.testing.assert_array_equal(np.loadtxt(d/'schedule.txt',dtype=np.int64),rows)
        np.testing.assert_array_equal(np.loadtxt(d/'channel_schedule.txt',dtype=np.int64),channels)
        for row,j,se,cy,en in channels:
            if cy<=0:assert se==-1;continue
            freq=round(C['obs_frequency_TU'][C['observations'][j-1]]*100)
            a=((se+cy+freq-1)//freq)*freq;period=((cy+freq-1)//freq)*freq
            if a<=steps:
                num=(steps-a)//period+1
                count[row-1,j-1]=num;first[row-1,j-1]=a;last[row-1,j-1]=a+(num-1)*period
    u=np.loadtxt(d/'parameter_updates.txt',dtype=np.int64).reshape(45,8,5)
    for j,x in enumerate([count,first,last],2):np.testing.assert_array_equal(u[:,:,j],x)
    init=np.loadtxt(d/'initial_parameters.txt');final=np.loadtxt(d/'final_parameters.txt')
    assert init.shape==final.shape==(45,4) and np.isfinite(init).all() and np.isfinite(final).all()
    assert (d/'initial_parameters.txt').read_bytes()==(REF/f'CDA8{seed}'/'initial_parameters.txt').read_bytes()
    np.testing.assert_array_equal(init[~count.any(1)],final[~count.any(1)])
    h=np.loadtxt(d/'parameter_mean.txt');assert h.shape[1]==91 and np.isfinite(h).all()
    assert h[0,0]==0 and h[-1,0]==steps/100
    np.testing.assert_allclose(h[-1,1:46],final[:,2],rtol=1e-14)
    r=np.loadtxt(d/f'rmse_M{n:02d}_v{v:02d}.txt');assert r.shape==(10,) and np.isfinite(r).all() and (r>=0).all()
    return dict(scheme=n,variant=v,seed=seed,steps=steps,rmse=r.tolist(),RMSE_window_TU=[start/100,end/100],RMSE_samples=end-start,
      update_count=int(count.sum()),initial_sha256=hashlib.sha256((d/'initial_parameters.txt').read_bytes()).hexdigest())

def run(d,n,v,seed,steps=None,start=9000000,end=10000000,psd_start=10000000,record=None):
    if steps is None:steps=15000000 if v==6 else 10000000
    if record is None:record=v==6 and steps==15000000
    d.mkdir(parents=True,exist_ok=False)
    env={k:v for k,v in os.environ.items() if not k.startswith('MCPE_')}
    env.update(MCPE_SCHEME=str(n),MCPE_VARIANT=str(v),MCPE_SEED=str(seed),MCPE_ENTRY_ARM='sync',
     MCPE_FREQ='1,4,20',MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS=str(steps),MCPE_EVAL=str(start),MCPE_EVAL_END=str(end),
     MCPE_SAVE_PARAM_MEAN='1',MCPE_PSD='1' if record else '0',MCPE_PSD_START=str(psd_start),
     OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    if steps not in [10000000,15000000] or start!=9000000 or end!=10000000:env['MCPE_SMOKE']='1'
    if 'preflight' in d.parts:env['MCPE_CHECKPOINT']='checkpoint.txt'
    try:
        receipt=checked(B/'exp21_new',d,env,'run')
        a=validate(d,n,v,seed,steps,start,end);a['execution']=receipt
        if v==6 and n<=24 and steps>=10000000 and start==9000000:
            old=TIMING/'runs'/f'{SCHEMES.index(n)*10+seed:03d}'
            assert (d/f'rmse_M{n:02d}_v06.txt').read_bytes()==(old/f'rmse_M{n:02d}_v06.txt').read_bytes()
            np.testing.assert_array_equal(np.loadtxt(d/'parameter_mean.txt')[:1001],np.loadtxt(old/'parameter_mean.txt'))
            a['original_sync_prefix_exact_match']=True
        if record:
            path=d/'spectral_member1.bin';num=(steps-psd_start)//10+1
            assert path.stat().st_size==num*15*8
            data=np.memmap(path,dtype='<f8',mode='r',shape=(num,15));assert np.isfinite(data).all()
            np.testing.assert_allclose(data[:,0],np.arange(psd_start,steps+1,10)/100,atol=1e-10,rtol=0)
            a['truth_sha256']=hashlib.sha256(np.ascontiguousarray(data[:,1:8]).tobytes()).hexdigest()
            a['spectral_rows']=num
            if steps==15000000 and psd_start==10000000:
                from spectra import analyze
                analyze(d)
                ref=json.loads((OLDPSD/'runs/CTL'/f'seed{seed}'/'audit.json').read_text())
                assert a['truth_sha256']==ref['truth_sha256']
        (d/'audit.json').write_text(json.dumps(a,indent=2));(d/'READY').touch()
        print('READY',n,v,seed,steps,flush=True)
    except Exception as e:(d/'FAILED').write_text(repr(e));raise

def preflight():
    env=os.environ.copy();env.update(MCPE_ENTRY_ARM='sync',MCPE_PARAM_CHANNELS='x123_w_TL')
    checked(B/'test_config',B,env,'config')
    got=np.loadtxt(B/'config.log',dtype=np.int64);expected=[]
    for n in SCHEMES:
        rows,ch=schedule(n,8,10000000);first={r[0]:r[1] for r in rows}
        for row,j,se,cy,en in ch:expected.append([n,row,j,se,cy,first[row],en])
    np.testing.assert_array_equal(got,expected)
    from spectra import selftest
    selftest()
    # Prefix replay and recorder-no-effect checks use a real old synchronous scheme.
    run(B/'preflight/replay',12,6,0,10000000,record=False)
    run(B/'preflight/recorder',12,6,0,10000000,psd_start=9950000,record=True)
    for f in ['checkpoint.txt','parameter_mean.txt','final_parameters.txt','parameter_updates.txt','rmse_M12_v06.txt']:
        assert (B/'preflight/replay'/f).read_bytes()==(B/'preflight/recorder'/f).read_bytes(),f
    # Exercise the newly included last rank and absent observation channels.
    for v in [4,5,6]:run(B/'preflight'/f'last_rank_v{v}',30,v,0,record=False,steps=8002000,start=8000000,end=8002000)
    # Before entry, exact state compatibility with all three CDA systems.
    for v in [4,5,6]:
        for n,vv,label in [(30,v,'MCPE'),(22,v-3,'CDA')]:
            run(B/'preflight'/f'before_{label}_{v}',n,vv,0,steps=1999900,start=1999000,end=1999900,record=False)
        assert (B/'preflight'/f'before_MCPE_{v}/checkpoint.txt').read_bytes()==(B/'preflight'/f'before_CDA_{v}/checkpoint.txt').read_bytes()
    # Prove reused PSD baselines are identical in the extended driver (one full seed each).
    for v,label in [(0,'CTL'),(3,'CDA8')]:
        d=B/'preflight'/f'baseline_{label}';run(d,22,v,0,steps=15000000,record=True)
        old=OLDPSD/'runs'/label/'seed0'
        for f in ['spectral_member1.bin','parameter_mean.txt','final_parameters.txt','parameter_updates.txt']:
            assert hashlib.sha256((d/f).read_bytes()).digest()==hashlib.sha256((old/f).read_bytes()).digest(),f
    (B/'PREFLIGHT_PASS').write_text('Quota tables; old sync prefix; non-perturbing spectral recorder; absent channels; last rank; pre-entry state; exact CTL/CDA8 PSD reuse passed.\n')

def production(i):
    assert (B/'PREFLIGHT_PASS').exists() and 0<=i<210
    n=SCHEMES[i//30];v=4+(i//10)%3;seed=i%10
    run(folder(n,v,seed),n,v,seed)

if __name__=='__main__':
    if sys.argv[1]=='preflight':preflight()
    else:production(int(sys.argv[1]))
