"""Read-only reanalysis of saved member-1 trajectories; no integration or curve perturbations."""
from pathlib import Path
import json,hashlib
import numpy as np
import spectra
import plot_corrected as plot
B=Path(__file__).resolve().parent
O=B/'psd_4x_20260914';O.mkdir(exist_ok=True)
cfg,xlim=plot.original_config(B)
roots={'MCPE30':B/'runs'/'M30_v6','CTL':B.parent/'three_channel_figures_psd150k_20260913'/'runs'/'CTL','CDA8':B.parent/'three_channel_figures_psd150k_20260913'/'runs'/'CDA8'}
curves={v:{m:[] for m in ['Truth','CTL','CDA8','MCPE30']} for v in plot.VARIABLES}
freq={};hashes={};ref={};metadata=[]
for method,root in roots.items():
    for seed in range(10):
        d=root/f'seed{seed}';p=d/'spectral_member1.bin'
        assert (d/'READY').exists() and p.stat().st_size==500001*15*8
        a=np.memmap(p,dtype='<f8',mode='r',shape=(500001,15))
        assert np.isfinite(a).all()
        np.testing.assert_allclose(a[:,0],100000+np.arange(500001)*.1,rtol=0,atol=1e-7)
        meta={'method':method,'seed':seed,'file':str(p),'variables':{}}
        for j,v in enumerate(plot.VARIABLES):
            c=cfg[v];stride=int(round(10/c['fs']));t=np.asarray(a[::stride,1+j]);y=np.asarray(a[::stride,8+j])
            h=hashlib.sha256(t.tobytes()).hexdigest()
            if v in hashes:assert hashes[v]==h,('truth differs',method,seed,v)
            else:hashes[v]=h
            f,pt=spectra.psd(t,c,4);g,py=spectra.psd(y,c,4);np.testing.assert_array_equal(f,g)
            mask=(f>=xlim[0])&(f<=xlim[1]);f=f[mask];pt=pt[mask];py=py[mask]
            if v in freq:np.testing.assert_array_equal(freq[v],f)
            freq[v]=f;curves[v][method].append(py)
            if method=='MCPE30':curves[v]['Truth'].append(pt)
            # Reproduce existing original spectra before trusting the new calculation.
            old=np.load(d/'spectra.npz');f1,p1=spectra.psd(y,c,1);mask1=(f1>=xlim[0])&(f1<=xlim[1])
            np.testing.assert_allclose(p1[mask1],old[v+'_1_member1'],rtol=1e-11,atol=1e-14)
            meta['variables'][v]={'samples':len(t),'truth_sha256':h,'segment_TU':len(t)/c['fs'] if c['nperseg']=='full' else c['nperseg']*4/c['fs'],'points':len(f)}
        metadata.append(meta);print(method,seed,'PASS',flush=True)
        del a
result={v:{'frequency':freq[v].tolist(),**{m:np.mean(ys,axis=0).tolist() for m,ys in ds.items()}} for v,ds in curves.items()}
(O/'plot_data.json').write_text(json.dumps(result),encoding='utf-8')
arrays={v+'_'+m:np.array(ys) for v,ds in curves.items() for m,ys in ds.items()}
np.savez_compressed(O/'seed_spectra.npz',**arrays)
(O/'audit.json').write_text(json.dumps({'window_TU':[100000,150000],'seeds':10,'member':1,'factor':4,'original_spectra_reproduction':'PASS','truth_hashes_consistent':True,'extra_smoothing':False,'artificial_perturbations':False,'records':metadata},indent=2),encoding='utf-8')
(O/'DONE').write_text('PASS\n')
