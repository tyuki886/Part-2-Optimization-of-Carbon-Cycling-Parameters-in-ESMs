"""24 source-checked English PNGs; preserve original scientific figure templates."""
from pathlib import Path
import os,json,hashlib,math,runpy,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from PIL import Image
from task import B,C,SCHEMES,folder,baseline,OLDPSD,validate
import plot_corrected as plot
OUT=B/'figures'
def main():
    assert (B/'PREFLIGHT_PASS').exists()
    OUT.mkdir(exist_ok=True);values={};receipts=[];figures={};arrays={}
    font_manager.fontManager.addfont(str(B/'times.ttf'));plot.configure_font(B)
    for n in SCHEMES:
        for v in [4,5,6]:
            for seed in range(10):
                d=folder(n,v,seed);assert (d/'READY').exists() and not (d/'FAILED').exists()
                steps=15000000 if v==6 else 10000000
                a=validate(d,n,v,seed,steps,9000000,10000000)
                values[n,v,seed]=np.array(a['rmse'])
                src=d/f'rmse_M{n:02d}_v{v:02d}.txt'
                target=B/'results'/f'S{n}/seed{seed}'/src.name
                target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
                receipts.append(dict(path=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest(),scheme=n,variant=v,seed=seed))
    for v in range(4):
        for seed in range(10):
            d=baseline(v,seed);assert (d/'READY').exists()
            src=d/f'rmse_M22_v{v:02d}.txt';r=np.loadtxt(src)
            assert r.shape==(10,) and np.isfinite(r).all() and (r>=0).all()
            scal=np.fromstring((d/'audit_scalars.txt').read_text().splitlines()[0],sep=' ',dtype=np.int64)
            np.testing.assert_array_equal(scal,[10000000,9000000,10000000,1000000,0])
            values[22,v,seed]=r
            target=B/'results'/(f'ctl/seed{seed}/rmse_M10_v00.txt' if v==0 else f'CDA/seed{seed}/rmse_M20_v{v:02d}.txt')
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
            receipts.append(dict(path=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest(),scheme=22,variant=v,seed=seed))
    os.environ.update(MCPE_RESULTS_DIR=str(B/'results'),MCPE_FIGURES_DIR=str(OUT/'RMSE'),MCPE_TAG='sync',MCPE_SKIP_SUMMARY='1',
     MCPE_RMSE_TITLE_TEMPLATE='MCPE{ns} RMSE',MCPE_CORR_TITLE_TEMPLATE='RMSE correction rate vs MCPE12 ({obs}obs)')
    oldsave=plt.Figure.savefig
    def checked_save(fig,path,*args,**kwargs):
        name=Path(path).name
        assert len(fig.axes)==10
        if name.startswith('rmse_'):
            n=int(name.split('MCPE')[1].split('.')[0])
            for j,ax in enumerate(fig.axes):
                expected=[np.mean([values[22,v,s][j] for s in range(10)]) for v in range(4)]
                expected += [np.mean([values[n,v,s][j] for s in range(10)]) for v in [4,5,6]]
                assert len(ax.patches)==7
                np.testing.assert_allclose([p.get_height() for p in ax.patches],expected,atol=1e-14,rtol=0)
                assert [t.get_text() for t in ax.get_xticklabels()]==['CTL','CDA5','CDA7','CDA8','MCPE-5obs','MCPE-7obs','MCPE-8obs']
        else:
            obs=int(name.split('_')[-1].split('obs')[0]);v={5:4,7:5,8:6}[obs]
            fig.canvas.draw();renderer=fig.canvas.get_renderer()
            for j,ax in enumerate(fig.axes):
                assert all(values[12,v,s][j]>0 for s in range(10))
                expected=[np.mean([100*(values[12,v,s][j]-values[n,v,s][j])/values[12,v,s][j] for s in range(10)]) for n in SCHEMES[1:]]
                np.testing.assert_allclose([p.get_height() for p in ax.patches],expected,rtol=1e-12,atol=1e-10)
                boxes=[t.get_window_extent(renderer) for t in ax.get_xticklabels()]
                assert all(b.x0>a.x1 for a,b in zip(boxes,boxes[1:]))
        result=oldsave(fig,path,*args,**kwargs)
        figures[str(Path(path).relative_to(OUT))]=dict(bound_values_checked=True)
        return result
    plt.Figure.savefig=checked_save
    try:
        try:runpy.run_path(str(B/'plot_rmse.py'))
        except SystemExit as e:
            if e.code not in [None,0]:raise
        os.environ['MCPE_FIGURES_DIR']=str(OUT/'correction_rate')
        result=runpy.run_path(str(B/'plot_corr.py'));assert np.isfinite(result['corr']).all()
    finally:plt.Figure.savefig=oldsave;plt.close('all')
    # Unique parameter ensembles appear once. Shared-channel entry marks remain separate.
    out=OUT/'parameter_means';out.mkdir(exist_ok=True)
    for n in SCHEMES:
        cfg=C['configs']['sync'][str(n)];names=cfg['unique_parameters']
        display=[p for p in names if p in C['groups'][0]]+[p for p in names if p not in C['groups'][0]]
        hs=[];truth=None
        for seed in range(10):
            d=folder(n,6,seed);h=np.loadtxt(d/'parameter_mean.txt')[:1001];init=np.loadtxt(d/'initial_parameters.txt')
            assert h.shape==(1001,91) and np.isfinite(h).all()
            np.testing.assert_array_equal(h[:,0],np.arange(0,100001,100))
            if truth is None:truth=init[:,1]
            else:np.testing.assert_array_equal(truth,init[:,1])
            hs.append(h[:,1:46])
        hs=np.array(hs);mean=hs.mean(0);t=h[:,0];arrays[f'M{n}_seed_means']=hs;arrays[f'M{n}_truth']=truth;arrays['time_TU']=t
        nr=math.ceil(len(display)/4);fig,axes=plt.subplots(nr,4,figsize=(16,3.2*nr),squeeze=False)
        for ax,p in zip(axes.flat,display):
            row=C['row45'][p]-1;assert truth[row]!=0
            line,=ax.plot(t,mean[:,row]/truth[row],color='#2166AC' if p in C['groups'][0] else '#B2182B',lw=1.3)
            np.testing.assert_array_equal(line.get_ydata(),mean[:,row]/truth[row])
            ax.axhline(1,color='black',ls='--',lw=1)
            for slot in cfg['slots']:
                if slot['name']==p:ax.axvline(slot['entry_TU'],color='#777777',ls=[':',':','-.'][slot['group']],lw=1)
            ax.set(title=p,xlabel='Time (TU)',ylabel='Normalized parameter mean',xlim=(0,100000))
            ax.set_xticks([0,20000,40000,60000,80000,100000]);ax.tick_params(axis='x',labelsize=8);ax.grid(alpha=.2)
        for ax in list(axes.flat)[len(display):]:ax.set_visible(False)
        handles=[Line2D([],[],color='#2166AC',lw=1.3,label='Ensemble mean / truth'),Line2D([],[],color='black',ls='--',label='Truth'),
                 Line2D([],[],color='#777777',ls=':',label='Water or Catm/Cocean entry'),Line2D([],[],color='#777777',ls='-.',label='ALK entry')]
        fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.955),ncol=4,frameon=False,fontsize=10)
        fig.suptitle(f'MCPE{n} parameter mean (8obs; mean of 10 seeds)',fontsize=16,y=.985)
        fig.text(.5,.015,'20 members per seed | Recorded every 100 TU | No temporal smoothing | Shared parameters shown once',ha='center',fontsize=10)
        fig.tight_layout(rect=(0,.035,1,.91));path=out/f'parameter_mean_MCPE{n}_8obs.png';fig.savefig(path,dpi=300);plt.close(fig)
        figures[str(path.relative_to(OUT))]=dict(bound_values_checked=True,parameters=display,group_slots=n,unique_parameters=len(display))
    np.savez_compressed(out/'plot_source_arrays.npz',**arrays)
    # Exact original one-factor PSD, separate comparison for each of the seven schemes.
    config,xlim=plot.original_config(B);methods=['CTL','CDA8']+[f'MCPE{n}' for n in SCHEMES]
    allspec={};freqs={};truthspec=None;truth_hash=None
    for method in methods:
        rows=[]
        for seed in range(10):
            d=OLDPSD/'runs'/method/f'seed{seed}' if method in ['CTL','CDA8'] else folder(int(method[4:]),6,seed)
            assert (d/'READY').exists();a=json.loads((d/'audit.json').read_text());z=dict(np.load(d/'spectra.npz'))
            if truth_hash is None:truth_hash=a['truth_sha256']
            assert a['truth_sha256']==truth_hash
            current={k:v for k,v in z.items() if '_1_' in k}
            if truthspec is None:truthspec={k:v for k,v in current.items() if k.endswith('_truth')}
            for k,x in truthspec.items():np.testing.assert_array_equal(current[k],x)
            for k,x in current.items():
                if k.endswith('_frequency'):
                    if k in freqs:np.testing.assert_array_equal(freqs[k],x)
                    else:freqs[k]=x
            rows.append(current)
        allspec[method]={k:np.mean([z[k] for z in rows],axis=0) for k in rows[0] if k.endswith('_member1')}
    data={};limits={}
    for var in plot.VARIABLES:
        key=var+'_1';d={'frequency':freqs[key+'_frequency'].tolist(),'Truth':truthspec[key+'_truth'].tolist()}
        d.update({m:allspec[m][key+'_member1'].tolist() for m in methods});data[var]=d
        limits[var]=1.1*max(max(d[m]) for m in ['Truth']+methods)
    out=OUT/'power_spectra';out.mkdir(exist_ok=True)
    styles={'Truth':dict(color='#111111',ls='-',marker=None),'CTL':dict(color='#777777',ls=(0,(6,3)),marker=None),
            'CDA8':dict(color='#0072B2',ls=(0,(1,1.8)),marker='x'),'MCPE':dict(color='#D64000',ls='-',marker='o')}
    for n in SCHEMES:
        labels=['Truth','CTL','CDA8',f'MCPE{n}']
        fig,axes=plot.seven_panel(f'Power spectra: CTL, Truth, CDA8 and MCPE{n}',
          '100000–150000 TU | Mean PSD over 10 seeds | Fixed member 1',
          'Original Welch segment length | State assimilation and parameter estimation continue')
        plot.shared_legend(fig,[Line2D([],[],lw=1.5,markersize=5,markerfacecolor='white',**styles[m if m in styles else 'MCPE']) for m in labels],labels)
        for var,ax in axes.items():
            d=data[var];f=np.array(d['frequency'])
            for i,m in enumerate(labels):
                y=np.array(d[m]);stride=max(7,len(f)//9)
                line,=ax.plot(f,y,lw=1.5,markersize=4.7,markerfacecolor='white',markeredgewidth=.9,markevery=list(range(i%stride,len(f),stride)),**styles[m if m in styles else 'MCPE'])
                np.testing.assert_array_equal(line.get_ydata(),y)
            ax.set_xlim(*xlim);ax.set_ylim(0,limits[var]);plot.axis_style(ax,var,config[var]['xlab'],'PSD',spectrum=True)
            ax.set_title(var+' | full record' if config[var]['nperseg']=='full' else f"{var} | segment = {config[var]['nperseg']/config[var]['fs']:g} TU",fontsize=12)
        fig.text(.5,.032,'PSD per displayed frequency unit; no time-series or member averaging.',ha='center',fontsize=9.3)
        fig.text(.5,.016,'Cocean and ALK: full-record spectra, 8 displayed frequency bins.',ha='center',fontsize=9.3)
        path=out/f'power_spectra_MCPE{n}_vs_CTL_Truth_CDA8.png';fig.savefig(path,dpi=300);plt.close(fig)
        figures[str(path.relative_to(OUT))]=dict(bound_values_checked=True,window_TU=[100000,150000],factor=1)
    (out/'plot_data.json').write_text(json.dumps(data))
    assert len(figures)==24 and len(list(OUT.rglob('*.png')))==24
    for name,info in figures.items():
        p=OUT/name
        with Image.open(p) as im:im.verify()
        with Image.open(p) as im:info['size']=list(im.size);assert im.width>=3800 and im.height>=2300
        info['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    summary=dict(schemes=SCHEMES,RMSE_window_TU=[90000,100000],all_seeds_retained=True,RMSE_per_seed={},RMSE_mean={})
    for n,v,s in values:
        k=f'M{n}_v{v}'
        if k not in summary['RMSE_mean']:
            a=np.array([values[n,v,seed] for seed in range(10)]);summary['RMSE_per_seed'][k]=a.tolist();summary['RMSE_mean'][k]=a.mean(0).tolist()
    (B/'summary.json').write_text(json.dumps(summary,indent=2))
    (B/'delivery.json').write_text(json.dumps(dict(images=figures,receipts=receipts,visual_QA='pending',new_runs=210,reused_RMSE_baselines=40,reused_PSD_baselines=20),indent=2))
    (B/'FIGURES_READY').write_text('24 English PNGs; numerical bindings verified; visual QA pending.\n')
if __name__=='__main__':
    try:main()
    except Exception as e:(B/'POST_FAILED').write_text(repr(e));raise
