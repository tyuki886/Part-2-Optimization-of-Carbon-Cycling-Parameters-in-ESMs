from pathlib import Path
import getpass,json,hashlib,sys,time
import paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/'+B.name
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
DEPS='/public/home/hou/wyh/MCPE26.0/twin_work_3x3/python_deps:/public/home/hou/wyh/MCPE26.0/power_combined/python_deps'
DEST=Path('D:/SRDP/论文大作！/MCPE26.0/9.2/同步MCPE12-30_七方案四类图_20260913')
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
def cmd(s):
    _,o,e=c.exec_command(s,timeout=180);a=o.read().decode();b=e.read().decode()
    assert o.channel.recv_exit_status()==0,(a,b)
    return a
def pbs(name,action):
    return f'''#!/bin/bash
#PBS -N {name}
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=02:00:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH={R}:{DEPS}
{PY} {action}
'''
def advance():
    state=json.loads(cmd(f'''cd {R} && {PY} -c 'from pathlib import Path;import json;p=Path(".");print(json.dumps(dict(preflight=(p/"PREFLIGHT_PASS").exists(),preflight_ready=[f.parent.name for f in p.glob("preflight/*/READY")],production=(p/"production_job.txt").read_text().strip() if (p/"production_job.txt").exists() else None,ready=len(list(p.glob("runs/*/*/READY"))),failed=[str(f) for f in p.glob("preflight/*/FAILED")]+[str(f) for f in p.glob("runs/*/*/FAILED")],post=(p/"post_job.txt").read_text().strip() if (p/"post_job.txt").exists() else None,complete=(p/"FIGURES_READY").exists(),post_failed=(p/"POST_FAILED").read_text() if (p/"POST_FAILED").exists() else None)))' '''))
    if state['failed'] or state['post_failed']:raise RuntimeError(state)
    if state['preflight'] and not state['production']:
        print('PRODUCTION',cmd(f'cd {R}/logs && qsub -t 0-209%10 ../run.pbs > ../production_job.txt && cat ../production_job.txt'),flush=True)
    if state['ready']==210 and not state['post']:
        print('POST',cmd(f'cd {R}/logs && qsub ../post.pbs > ../post_job.txt && cat ../post_job.txt'),flush=True)
    if state['complete']:
        with c.open_sftp() as ftp:
            for name in ['summary.json','delivery.json','PREFLIGHT_PASS','FIGURES_READY','preflight_job.txt','production_job.txt','post_job.txt']:
                ftp.get(R+'/'+name,str(B/name))
            meta=json.loads((B/'delivery.json').read_text())
            for name,info in meta['images'].items():
                local=B/'figures'/name;local.parent.mkdir(parents=True,exist_ok=True)
                ftp.get(R+'/figures/'+name,str(local));assert hashlib.sha256(local.read_bytes()).hexdigest()==info['sha256']
            for name in ['power_spectra/plot_data.json','parameter_means/plot_source_arrays.npz']:
                ftp.get(R+'/figures/'+name,str(B/'figures'/name))
        print('DOWNLOADED_24_PNG; visual inspection required before publishing',flush=True)
    return state
try:
    action=sys.argv[1]
    if action=='deploy':
        cmd(f'test ! -e {R} && mkdir -p {R}/logs')
        manifest=json.loads((B/'manifest.json').read_text())
        with c.open_sftp() as ftp:
            for name,h in manifest.items():
                assert hashlib.sha256((B/name).read_bytes()).hexdigest()==h
                ftp.put(str(B/name),R+'/'+name)
            ftp.put(str(B/'manifest.json'),R+'/manifest.json')
            for filename,name,run in [('preflight.pbs','Sync7Check','task.py preflight'),('run.pbs','Sync7Run','task.py "${PBS_ARRAYID:?}"'),('post.pbs','Sync7Plot','postprocess.py')]:
                with ftp.open(R+'/'+filename,'w') as f:f.write(pbs(name,run))
        print(cmd(f'''set -eu
cd {R}
{PY} -c 'import pathlib,json,hashlib;m=json.load(open("manifest.json"));assert all(hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest()==h for n,h in m.items());print("HASH_PASS")'
gfortran -O3 -ffree-line-length-none -c RKmethod.f90
gfortran -O3 -ffree-line-length-none -c MCPE42_new.f90
gfortran -O3 -ffree-line-length-none exp21_new.f90 MCPE42_new.o RKmethod.o -o exp21_new
gfortran -O0 -fcheck=all -ffree-line-length-none test_config.f90 MCPE42_new.o RKmethod.o -o test_config
{PY} -m py_compile task.py postprocess.py spectra.py
cd logs
qsub ../preflight.pbs > ../preflight_job.txt
cat ../preflight_job.txt
'''),flush=True)
    elif action in ['advance','watch']:
        previous=None
        for attempt in range(120 if action=='watch' else 1):
            state=advance()
            if state!=previous:print(json.dumps(state),flush=True);previous=state
            if state['complete']:break
            if action=='watch':time.sleep(20)
    elif action=='inspect':
        print(cmd(f'cd {R}; tail -n 25 logs/Sync7Check.o* 2>/dev/null || true; tail -n 25 logs/Sync7Plot.o* 2>/dev/null || true; qstat -u hou'),flush=True)
    else:raise ValueError(action)
finally:c.close()
