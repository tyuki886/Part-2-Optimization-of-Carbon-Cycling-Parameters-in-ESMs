! Independent entry-2000 / nearest-divisor-2000 MCPE version, 2026-09-11.
module MCPE42
    use RKmethod, only: dp
    use RKmethod
    implicit none
    integer, parameter :: n_all = 45
    logical :: proxy_x13=.false., channels_configured=.false.
    integer, parameter :: n_active = 33

    real(kind=dp),parameter::obs5_var(5)=[0.36_dp,0.64_dp,9.0_dp,0.36_dp,0.36_dp]
    real(kind=dp),parameter::obs5_freq(5)=[.04_dp,.04_dp,.04_dp,.20_dp,.20_dp]
    integer,parameter::obs5_idx(5)=[1,2,3,4,7]
    integer,parameter::obs7_idx(7)=[1,2,3,4,7,8,9]
    real(kind=dp),parameter::obs7_var(7)=[0.36_dp,0.64_dp,9.0_dp,0.36_dp,0.36_dp,0.09_dp,0.36_dp]
    real(kind=dp)::obs7_freq(7)=[.04_dp,.04_dp,.04_dp,.20_dp,.20_dp,1._dp,4._dp]  ! C-66 定稿: Catm 0.01/Co 2 TU
    integer,parameter::obs8_idx(8)=[1,2,3,4,7,8,9,10]
    real(kind=dp)::obs8_var(8)=[0.36_dp,0.64_dp,9.0_dp,0.36_dp,0.36_dp,0.09_dp,0.36_dp,0.09_dp]
    real(kind=dp)::obs8_freq(8)=[.04_dp,.04_dp,.04_dp,.20_dp,.20_dp,1._dp,4._dp,20._dp]  ! C-66 定稿: ALK 40 TU (Catm0.01/Co2/ALK40, 2026-08-10 观测频率扫描结论)

    integer,parameter::fixed(12)=[13,18,19,20,21,22,23,24,41,43,44,45]


    integer,parameter::phys_rows(19)=[1,2,3,4,5,6,7,8,25,26,27,28,29,30,31,32,33,34,42]
    integer,parameter::carb_rows(14)=[9,10,11,12,14,15,16,17,35,36,37,38,39,40]
    integer,parameter::phys_top10(10)=[2,4,3,1,33,5,42,26,7,32]
    integer,parameter::carb_top10(10)=[39,35,10,16,9,17,15,37,12,38]
    integer,parameter::top20(20)=[phys_top10,carb_top10]
    integer,parameter::top22(22)=[top20,40,36]
    integer,parameter::c37_phys(10)=[2,19,23,6,3,4,1,22,33,5]    ! κ,Od,Slm,c6,b,c1,σ,Sm,c13,c2
    integer,parameter::c37_carb(10)=[10,37,17,14,35,15,36,38,11,16]  ! c20,c19,c30,c26,c16,c28,c17,c23,c21,c29

contains

    subroutine configure_parameter_channels()
        character(32)::policy
        integer::st
        call get_environment_variable('MCPE_PARAM_CHANNELS',policy,status=st)
        if(st/=0)policy='x123_w_TL' ! user confirmed x1/x3 use x2 cycle
        select case(trim(policy))
        case('x2_w_TL'); error stop 'USER_APPROVED_X123_CHANNELS_REQUIRED'
        case('x123_w_TL'); proxy_x13=.true.
        case default; error stop 'INVALID_MCPE_PARAM_CHANNELS'
        end select
        channels_configured=.true.
    end subroutine

    subroutine set_obs_freq_from_env()
        character(64)::val; integer::st
        call get_environment_variable('MCPE_FREQ',val,status=st)
        if(st==0.and.len_trim(val)>0)then
            read(val,*) obs7_freq(6),obs7_freq(7),obs8_freq(8)
            obs8_freq(6:7)=obs7_freq(6:7)
        endif
    end subroutine

    function all_active_rows() result(rows)
        integer,allocatable::rows(:); integer::i,n
        allocate(rows(n_active)); n=0
        do i=1,n_all; if(.not.any(fixed==i))then; n=n+1; rows(n)=i; endif; enddo
    end function

    logical function is_physical(row)
        integer,intent(in)::row; is_physical=any(phys_rows==row)
    end function

    function scheme_est_rows(ns) result(rows)
        integer,intent(in)::ns; integer,allocatable::rows(:); integer::n,i,np,nc
        if(ns==22)then
            allocate(rows(22)); rows=top22; return
        endif
        if(ns<6.or.ns>20)error stop 'Invalid scheme (C-32: 6..20)'
        n=ns; np=(ns+1)/2; nc=ns/2
        allocate(rows(n))
        do i=1,np; rows(i)=phys_top10(i); enddo
        do i=1,nc; rows(np+i)=carb_top10(i); enddo
    end function

    function scheme_est_rows_5obs(ns) result(rows)
        integer,intent(in)::ns; integer,allocatable::rows(:); integer::n,i
        if(ns<6.or.ns>20)error stop 'Invalid scheme (C-32: 6..20)'
        n=(ns+1)/2
        allocate(rows(n))
        do i=1,n; rows(i)=phys_top10(i); enddo
    end function

    integer function param_rank(row)
        integer,intent(in)::row; integer::k
        do k=1,10; if(phys_top10(k)==row)then; param_rank=k; return; endif; enddo
        do k=1,10; if(carb_top10(k)==row)then; param_rank=k; return; endif; enddo
        param_rank=0
    end function

    subroutine scheme_config(ns,total_steps,eval_start,eval_end)
        integer,intent(in)::ns; integer(kind=8),intent(out)::total_steps,eval_start,eval_end
        total_steps=10000000_8; eval_start=9000000_8; eval_end=10000000_8
    end subroutine

    subroutine scheme_starts_ends(rows,starts,ends)
        integer,intent(in)::rows(:)
        integer(kind=8),allocatable,intent(out)::starts(:),ends(:)
        integer::k
        allocate(starts(size(rows)),ends(size(rows)))
        do k=1,size(rows)
            starts(k)=(20000_8+2000_8*int(k-1,8))*100_8
        enddo
        ends=10000001_8 ! includes the final 100000 TU step
    end subroutine

    subroutine canonical_cycles(row,cycles)
        integer,intent(in)::row
        integer(kind=8),intent(out)::cycles(8)
        if(.not.channels_configured)error stop 'PARAM_CHANNELS_NOT_CONFIGURED'
        cycles=0_8
        select case(row)
        case(2); cycles(2)=100_8; cycles(4)=1000_8; cycles(5)=800_8 ! kappa
        case(4); cycles(2)=200_8; cycles(4)=1000_8; cycles(5)=800_8 ! c1
        case(3); cycles(2)=200_8; cycles(4)=1000_8; cycles(5)=800_8 ! b
        case(1); cycles(2)=200_8; cycles(4)=800_8; cycles(5)=500_8 ! sigma
        case(33); cycles(2)=500_8; cycles(4)=1600_8; cycles(5)=800_8 ! c13
        case(5); cycles(2)=500_8; cycles(4)=1600_8; cycles(5)=800_8 ! c2
        case(42); cycles(2)=500_8; cycles(4)=1600_8; cycles(5)=1000_8 ! lambda
        case(26); cycles(2)=500_8; cycles(4)=1600_8; cycles(5)=800_8 ! c4
        case(7); cycles(2)=800_8; cycles(4)=1600_8; cycles(5)=1000_8 ! c12
        case(32); cycles(2)=800_8; cycles(4)=1000_8; cycles(5)=1000_8 ! c11
        case(39); cycles(6:8)=[500_8,1000_8,100000_8] ! c24
        case(35); cycles(6:8)=[400_8,500_8,50000_8] ! c16
        case(10); cycles(6:8)=[500_8,1000_8,100000_8] ! c20
        case(16); cycles(6:8)=[500_8,1000_8,100000_8] ! c29
        case(9); cycles(6:8)=[500_8,1000_8,0_8] ! c18
        case(17); cycles(6:8)=[500_8,1000_8,200000_8] ! c30
        case(15); cycles(6:8)=[1000_8,1000_8,0_8] ! c28
        case(37); cycles(6:8)=[1000_8,1000_8,50000_8] ! c19
        case(12); cycles(6:8)=[4000_8,5000_8,200000_8] ! c22
        case(38); cycles(6:8)=[2500_8,4000_8,100000_8] ! c23
        case(40); cycles(8)=150000_8 ! c27: ALK-only 1500 TU
        case(36); cycles(8)=100000_8 ! c17: ALK-only 1000 TU
        case default; error stop 'PARAMETER_NOT_IN_NEW_TOP22'
        end select
        if(proxy_x13.and.is_physical(row))then
            cycles(1)=cycles(2); cycles(3)=cycles(2)
        endif
    end subroutine

    function paper_rows() result(rows)
        integer,allocatable::rows(:)
        allocate(rows(6)); rows=[2,19,23,6,3,4]   ! kappa,od,slm,c6,b,c1
    end function

    function paper_rows_10() result(rows)
        integer,allocatable::rows(:)
        allocate(rows(10)); rows=[2,19,23,6,3,4,1,22,33,5]
    end function

    subroutine paper_starts_ends(starts,ends)
        integer(kind=8),allocatable,intent(out)::starts(:),ends(:)
        integer::k
        allocate(starts(6),ends(6))
        starts=[20000_8,20000_8,20000_8,20000_8,20200_8,20400_8]
        starts=starts*100_8   ! TU -> 步
        ends=10000000_8
    end subroutine

    function c37_rows(ns) result(rows)
        integer,intent(in)::ns; integer,allocatable::rows(:); integer::np,i
        if(ns<8.or.ns>20.or.mod(ns,2)/=0)error stop 'C37: n=8,10,...,20'
        np=4+(ns-8)/2
        allocate(rows(2*np))
        do i=1,np; rows(i)=c37_phys(i); enddo
        do i=1,np; rows(np+i)=c37_carb(i); enddo
    end function

    function c37_rows_5obs(ns) result(rows)
        integer,intent(in)::ns; integer,allocatable::rows(:); integer::np,i
        if(ns<8.or.ns>20.or.mod(ns,2)/=0)error stop 'C37: n=8,10,...,20'
        np=4+(ns-8)/2
        allocate(rows(np))
        do i=1,np; rows(i)=c37_phys(i); enddo
    end function

    subroutine c37_starts_ends(rows,starts,ends)
        integer,intent(in)::rows(:); integer(kind=8),allocatable,intent(out)::starts(:),ends(:)
        integer::n,i,j
        n=size(rows); allocate(starts(n),ends(n))
        do i=1,n
            if(is_physical(rows(i)))then
                if(i<=4)then; starts(i)=20000_8*100_8
                else; starts(i)=(20000_8+int(i-4,8)*3000_8)*100_8
                endif
            else
                j=i-(n/2)   ! 碳序号（n 为偶数，物理在前）
                starts(i)=(20000_8+int(j+6,8)*3000_8)*100_8
            endif
        enddo
        ends=10000000_8
    end subroutine

    subroutine fill_canonical_table(rows,nobs,table)
        integer,intent(in)::rows(:),nobs; integer(kind=8),intent(out)::table(size(rows),nobs)
        integer(kind=8)::full(8); integer::i
        do i=1,size(rows); call canonical_cycles(rows(i),full); table(i,:)=full(1:nobs); enddo
    end subroutine

    subroutine c39_starts_ends(rows,starts,ends)
        integer,intent(in)::rows(:)
        integer(kind=8),allocatable,intent(out)::starts(:),ends(:)
        integer::k
        allocate(starts(size(rows)),ends(size(rows)))
        do k=1,size(rows)
            starts(k)=(20000_8+2000_8*int(k-1,8))*100_8
        enddo
        ends=10000001_8 ! includes the final 100000 TU step
    end subroutine

    subroutine assign_component_mask(rows,nobs,weights)
        integer,intent(in)::rows(:),nobs
        real(kind=dp),intent(out)::weights(size(rows),nobs)
        integer(kind=8)::full(8)
        integer::i
        do i=1,size(rows)
            call canonical_cycles(rows(i),full)
            weights(i,:)=merge(1._dp,0._dp,full(1:nobs)>0_8)
        enddo
    end subroutine

    subroutine get_standard_params45(p)
        real(kind=dp),intent(out)::p(n_all)
        p(1)=sigma; p(2)=kappa; p(3)=b; p(4)=c1; p(5)=c2; p(6)=c6
        p(7)=c12; p(8)=c15; p(9)=c18; p(10)=c20; p(11)=c21; p(12)=c22
        p(13)=c25; p(14)=c26; p(15)=c28; p(16)=c29; p(17)=c30
        p(18)=E_rate; p(19)=od_cnst; p(20)=spd; p(21)=ss; p(22)=sm
        p(23)=slm; p(24)=old_val; p(25)=c3; p(26)=c4; p(27)=c5
        p(28)=c7; p(29)=c8; p(30)=c9; p(31)=c10; p(32)=c11
        p(33)=c13; p(34)=c14; p(35)=c16; p(36)=c17; p(37)=c19
        p(38)=c23; p(39)=c24; p(40)=c27; p(41)=gamma_deep
        p(42)=lambda; p(43)=sls_cnst; p(44)=om; p(45)=olm
    end subroutine

    subroutine set_member_params45(p)
        real(kind=dp),intent(in)::p(n_all)
        sigma=p(1); kappa=p(2); b=p(3); c1=p(4); c2=p(5); c6=p(6)
        c12=p(7); c15=p(8); c18=p(9); c20=p(10); c21=p(11); c22=p(12)
        c25=p(13); c26=p(14); c28=p(15); c29=p(16); c30=p(17)
        E_rate=p(18); od_cnst=p(19); spd=p(20); ss=p(21); sm=p(22)
        slm=p(23); old_val=p(24); c3=p(25); c4=p(26); c5=p(27)
        c7=p(28); c8=p(29); c9=p(30); c10=p(31); c11=p(32)
        c13=p(33); c14=p(34); c16=p(35); c17=p(36); c19=p(37)
        c23=p(38); c24=p(39); c27=p(40); gamma_deep=p(41)
        lambda=p(42); sls_cnst=p(43); om=p(44); olm=p(45)
    end subroutine
end module MCPE42
