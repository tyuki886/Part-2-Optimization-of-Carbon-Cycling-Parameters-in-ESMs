"""Run one independent Fortran experiment and validate timing/finite outputs."""
from pathlib import Path
import json,os,sys,subprocess,hashlib,math
import numpy as np
BASE=Path(__file__).resolve().parent
CFG=json.loads((BASE/'baseline_config.json').read_text())
OBS=['x1','x2','x3','w','TL','Catm','Cocean','ALK']
ROW={p['name']:p['row45'] for p in CFG['schemes'][-1]['parameters']}

def task(tid):
    if tid<450:return 6+tid//30,4+(tid//10)%3,tid%10
    if tid<460:return 10,0,tid-450
    return 20,1+(tid-460)//10,(tid-460)%10

def expected(n,v,steps):
    no=0 if v==0 else {1:5,2:7,3:8,4:5,5:7,6:8}[v]
    names=[] if v<4 else CFG['water_parameters'][:(n+1)//2]
    if v>=5:names+=CFG['carbon_parameters'][:n//2]
    if n==22 and v>=4:names=CFG['water_parameters']+CFG['carbon_parameters']
    counts=np.zeros((45,8),dtype=np.int64);first=np.full((45,8),-1,dtype=np.int64);last=first.copy()
    for k,p in enumerate(names):
        start=(20000+2000*k)*100
        for j,obs in enumerate(OBS[:no]):
            cycle=CFG['cycles_TU'][p].get(obs,0)*100
            if not cycle:continue
            freq=round(CFG['obs_frequency_TU'][obs]*100)
            initial=((start+cycle+freq-1)//freq)*freq
            period=((cycle+freq-1)//freq)*freq
            if initial<=steps:
                num=(steps-initial)//period+1
                counts[ROW[p]-1,j]=num;first[ROW[p]-1,j]=initial;last[ROW[p]-1,j]=initial+(num-1)*period
    state=np.zeros(8,dtype=np.int64)
    for j,obs in enumerate(OBS[:no]):
        freq=round(CFG['obs_frequency_TU'][obs]*100)
        state[j]=max(0,steps//freq-(1000000+freq-1)//freq+1)
    return names,counts,first,last,state

def validate(folder,n,v,steps,start,end):
    scal=(folder/'audit_scalars.txt').read_text().splitlines()
    a=np.fromstring(scal[0],sep=' ',dtype=np.int64)
    assert a.tolist()==[steps,start,end,end-start,0],('step/RMSE/rollback audit',a.tolist())
    names,counts,first,last,state=expected(n,v,steps)
    np.testing.assert_array_equal(np.fromstring(scal[1],sep=' ',dtype=np.int64),state)
    u=np.loadtxt(folder/'parameter_updates.txt',dtype=np.int64).reshape(45,8,5)
    np.testing.assert_array_equal(u[:,:,2],counts)
    np.testing.assert_array_equal(u[:,:,3],first)
    np.testing.assert_array_equal(u[:,:,4],last)
    init=np.loadtxt(folder/'initial_parameters.txt');final=np.loadtxt(folder/'final_parameters.txt')
    assert init.shape==final.shape==(45,4)
    assert np.isfinite(init).all() and np.isfinite(final).all()
    assert all(init[ROW[p]-1,3]>0 for p in CFG['water_parameters']+CFG['carbon_parameters'])
    if v<4:np.testing.assert_array_equal(init,final)
    path=folder/f'rmse_M{n:02d}_v{v:02d}.txt'
    rmse=np.loadtxt(path);assert rmse.shape==(10,) and np.isfinite(rmse).all() and (rmse>=0).all()
    if (folder/'parameter_mean.txt').exists():
        means=np.loadtxt(folder/'parameter_mean.txt')
        assert means.shape[1]==91 and np.isfinite(means).all()
        assert means[0,0]==0 and means[-1,0]==steps/100
        np.testing.assert_allclose(means[0,1:46],init[:,2],rtol=1e-14)
        np.testing.assert_allclose(means[-1,1:46],final[:,2],rtol=1e-14)
    return {'scheme':n,'variant':v,'steps':steps,'RMSE_window_TU':[start/100,end/100],
            'RMSE_samples':end-start,'rollback_events':0,'selected_parameters':names,
            'update_count':int(counts.sum()),'initial_sha256':hashlib.sha256((folder/'initial_parameters.txt').read_bytes()).hexdigest(),
            'rmse':rmse.tolist()}

def run(folder,n,v,seed,steps=10000000,start=9000000,end=10000000,smoke=False):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy()
    for key in list(env):
        if key.startswith('MCPE_'):env.pop(key)
    env.update(MCPE_SCHEME=str(n),MCPE_VARIANT=str(v),MCPE_SEED=str(seed),MCPE_FREQ='1,4,20',
               MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS=str(steps),MCPE_EVAL=str(start),MCPE_EVAL_END=str(end),
               OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    if smoke:env.update(MCPE_SMOKE='1',MCPE_CHECKPOINT='checkpoint.txt')
    if v==6 and n in [12,14,16]:env['MCPE_SAVE_PARAM_MEAN']='1'
    try:
        with (folder/'run.log').open('w') as log:subprocess.run([str(BASE/'exp21_new')],cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
        audit=validate(folder,n,v,steps,start,end);audit['seed']=seed
        (folder/'audit.json').write_text(json.dumps(audit,indent=2))
        (folder/'READY').touch()
        return audit
    except Exception as exc:
        (folder/'FAILED').write_text(str(exc));raise

def preflight():
    root=BASE/'preflight';root.mkdir(exist_ok=True)
    env=os.environ.copy();env['MCPE_PARAM_CHANNELS']='x123_w_TL'
    subprocess.run([str(BASE/'test_config')],env=env,check=True)
    # Same initial ensemble and pre-20000 protocol must reproduce CDA8 exactly.
    run(root/'mcpe_before',20,6,0,1999900,1999000,1999900,True)
    run(root/'cda_before',20,3,0,1999900,1999000,1999900,True)
    assert (root/'mcpe_before'/'checkpoint.txt').read_bytes()==(root/'cda_before'/'checkpoint.txt').read_bytes()
    # Dynamic checks pass first parameter entry and x1/x2/x3 updates.
    run(root/'mcpe_after',20,6,0,2002000,2000000,2002000,True)
    run(root/'mean_smoke',12,6,0,2000,1000,2000,True)
    (BASE/'PREFLIGHT_PASS').write_text('configuration, same pre-entry state, event counts, finite outputs and mean logging passed\n')

if __name__=='__main__':
    if sys.argv[1]=='preflight':preflight()
    else:
        tid=int(sys.argv[1]);assert 0<=tid<490
        assert (BASE/'PREFLIGHT_PASS').exists()
        n,v,seed=task(tid)
        run(BASE/'runs'/f'{tid:03d}',n,v,seed)
