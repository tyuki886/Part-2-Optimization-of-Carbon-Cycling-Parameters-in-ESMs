program test_config
use MCPE42
implicit none
integer,allocatable::r(:)
integer(kind=8),allocatable::s(:),e(:)
integer(kind=8)::c(8)
real(kind=dp)::w(22,8)
integer::i,j
call configure_parameter_channels()
r=scheme_est_rows(22)
if(size(r)/=22)error stop "SIZE"
if(any(r/=top22))error stop "ROWS"
call scheme_starts_ends(r,s,e)
do i=1,22
if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"
do j=i+1,22
if(r(i)==r(j))error stop "DUPLICATE"
enddo
enddo
if(any(e/=10000001_8))error stop "END"
call assign_component_mask(r,8,w)
call canonical_cycles(2,c)
if(any(c/=[100_8,100_8,100_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLE_kappa"
if(any(w(1,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_kappa"
call canonical_cycles(4,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLE_c1"
if(any(w(2,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c1"
call canonical_cycles(3,c)
if(any(c/=[200_8,200_8,200_8,1000_8,800_8,0_8,0_8,0_8]))error stop "CYCLE_b"
if(any(w(3,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_b"
call canonical_cycles(1,c)
if(any(c/=[200_8,200_8,200_8,800_8,500_8,0_8,0_8,0_8]))error stop "CYCLE_sigma"
if(any(w(4,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_sigma"
call canonical_cycles(33,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLE_c13"
if(any(w(5,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c13"
call canonical_cycles(5,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLE_c2"
if(any(w(6,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c2"
call canonical_cycles(42,c)
if(any(c/=[500_8,500_8,500_8,1600_8,1000_8,0_8,0_8,0_8]))error stop "CYCLE_lambda"
if(any(w(7,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_lambda"
call canonical_cycles(26,c)
if(any(c/=[500_8,500_8,500_8,1600_8,800_8,0_8,0_8,0_8]))error stop "CYCLE_c4"
if(any(w(8,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c4"
call canonical_cycles(7,c)
if(any(c/=[800_8,800_8,800_8,1600_8,1000_8,0_8,0_8,0_8]))error stop "CYCLE_c12"
if(any(w(9,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c12"
call canonical_cycles(32,c)
if(any(c/=[800_8,800_8,800_8,1000_8,1000_8,0_8,0_8,0_8]))error stop "CYCLE_c11"
if(any(w(10,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c11"
call canonical_cycles(39,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLE_c24"
if(any(w(11,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c24"
call canonical_cycles(35,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,400_8,500_8,50000_8]))error stop "CYCLE_c16"
if(any(w(12,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c16"
call canonical_cycles(10,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLE_c20"
if(any(w(13,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c20"
call canonical_cycles(16,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,100000_8]))error stop "CYCLE_c29"
if(any(w(14,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c29"
call canonical_cycles(9,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,0_8]))error stop "CYCLE_c18"
if(any(w(15,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c18"
call canonical_cycles(17,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,500_8,1000_8,200000_8]))error stop "CYCLE_c30"
if(any(w(16,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c30"
call canonical_cycles(15,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,0_8]))error stop "CYCLE_c28"
if(any(w(17,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c28"
call canonical_cycles(37,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,1000_8,1000_8,50000_8]))error stop "CYCLE_c19"
if(any(w(18,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c19"
call canonical_cycles(12,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,4000_8,5000_8,200000_8]))error stop "CYCLE_c22"
if(any(w(19,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c22"
call canonical_cycles(38,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,2500_8,4000_8,100000_8]))error stop "CYCLE_c23"
if(any(w(20,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c23"
call canonical_cycles(40,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,150000_8]))error stop "CYCLE_c27"
if(any(w(21,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c27"
call canonical_cycles(36,c)
if(any(c/=[0_8,0_8,0_8,0_8,0_8,0_8,0_8,100000_8]))error stop "CYCLE_c17"
if(any(w(22,:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_c17"
print *, "CONFIG_TEST_PASS"
end program
