from pathlib import Path
import json,re,hashlib
B=Path(__file__).resolve().parent
OLD=B.parent/'carbon_second_halving_20260912'
SAT=B.parent/'alk_top10_saturation_20260912'
def save(p,t):
    if isinstance(t,str):t=t.encode('utf-8')
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():assert p.read_bytes()==t,str(p)
    else:p.write_bytes(t)
cfg=json.loads((OLD/'C2/experiment_config.json').read_text())
proposal=json.loads((SAT/'three_channel_proposal.json').read_text())
cfg['version']='three_channel_full22_20260912'
cfg['carbon_parameters']+=['c27','c17']
params=[dict(p) for p in cfg['schemes'][-1]['parameters']]+[{'name':'c27','row45':40,'entry_TU':60000},{'name':'c17','row45':36,'entry_TU':62000}]
assert len(params)==22 and all(p['entry_TU']==20000+2000*i for i,p in enumerate(params))
cfg['schemes'].append({'scheme':22,'parameters':params})
cfg['single_shared_parameter_ensemble']=True
cfg['ALK_parameter_names']=['c27','c29','c30','c20','c16','c19','c24','c17','c22','c23']
for p in proposal['parameters']:
    cfg['cycles_TU'][p['parameter']]={'Catm':p['Catm_current_C2_TU'],'Cocean':p['Cocean_current_C2_TU'],'ALK':p['ALK_candidate_TU']}
assert cfg['cycles_TU']['c27']=={'Catm':0,'Cocean':0,'ALK':1500}
save(B/'baseline_config.json',json.dumps(cfg,indent=2))
t=(OLD/'C2/MCPE42_new.f90').read_text(encoding='utf-8')
t=t.replace('integer,parameter::top20(20)=[phys_top10,carb_top10]','integer,parameter::top20(20)=[phys_top10,carb_top10]\n    integer,parameter::top22(22)=[top20,40,36]')
needle="        if(ns<6.or.ns>20)error stop 'Invalid scheme (C-32: 6..20)'"
assert t.count(needle)==2
t=t.replace(needle,'        if(ns==22)then\n            allocate(rows(22)); rows=top22; return\n        endif\n'+needle,1)
for p in params[10:20]:
    v=cfg['cycles_TU'][p['name']]
    line=f'        case({p["row45"]}); cycles(6:8)=[{v["Catm"]*100}_8,{v["Cocean"]*100}_8,{v["ALK"]*100}_8] ! {p["name"]}'
    t,n=re.subn(r'^        case\('+str(p['row45'])+r'\); cycles.*! '+p['name']+'$',line,t,flags=re.M);assert n==1
t=t.replace("        case default; error stop 'PARAMETER_NOT_IN_NEW_TOP20'","        case(40); cycles(8)=150000_8 ! c27: ALK-only 1500 TU\n        case(36); cycles(8)=100000_8 ! c17: ALK-only 1000 TU\n        case default; error stop 'PARAMETER_NOT_IN_NEW_TOP22'")
save(B/'MCPE42_new.f90',t)
t=(OLD/'C2/exp21_new.f90').read_text(encoding='utf-8').replace('nr2=top20','nr2=top22').replace('case(6:20); write(stem','case(6:22); write(stem')
t=t.replace('    if(v>=4)call configure_parameter_channels()',"    if(n/=22.or.(v/=3.and.v/=6))error stop 'ONLY_FULL22_AND_MATCHED_CDA8'\n    if(v>=4)call configure_parameter_channels()")
save(B/'exp21_new.f90',t);save(B/'RKmethod.f90',(OLD/'C2/RKmethod.f90').read_bytes())
t=(OLD/'audit_base.py').read_text(encoding='utf-8')
t=t.replace("    if v>=5:names+=CFG['carbon_parameters'][:n//2]","    if v>=5:names+=CFG['carbon_parameters'][:n//2]\n    if n==22 and v>=4:names=CFG['water_parameters']+CFG['carbon_parameters']")
save(B/'audit_base.py',t);save(B/'checked_exec.py',(OLD/'checked_exec.py').read_bytes())
obs=['x1','x2','x3','w','TL','Catm','Cocean','ALK']
test=['program test_config','use MCPE42','implicit none','integer,allocatable::r(:)','integer(kind=8),allocatable::s(:),e(:)','integer(kind=8)::c(8)','real(kind=dp)::w(22,8)','integer::i,j','call configure_parameter_channels()','r=scheme_est_rows(22)',
      'if(size(r)/=22)error stop "SIZE"','if(any(r/=top22))error stop "ROWS"','call scheme_starts_ends(r,s,e)',
      'do i=1,22','if(s(i)/=(20000_8+2000_8*(i-1))*100_8)error stop "ENTRY"','do j=i+1,22','if(r(i)==r(j))error stop "DUPLICATE"','enddo','enddo','if(any(e/=10000001_8))error stop "END"','call assign_component_mask(r,8,w)']
for i,p in enumerate(params,1):
    v=cfg['cycles_TU'][p['name']];vec=','.join(str(v.get(o,0)*100)+'_8' for o in obs)
    test += [f'call canonical_cycles({p["row45"]},c)',f'if(any(c/=[{vec}]))error stop "CYCLE_{p["name"]}"',f'if(any(w({i},:)/=merge(1._dp,0._dp,c>0_8)))error stop "MASK_{p["name"]}"']
test+=['print *, "CONFIG_TEST_PASS"','end program']
save(B/'test_config.f90','\n'.join(test)+'\n')
files=['RKmethod.f90','MCPE42_new.f90','exp21_new.f90','test_config.f90','audit_base.py','checked_exec.py','baseline_config.json','task.py','summarize.py']
save(B/'manifest.json',json.dumps({n:hashlib.sha256((B/n).read_bytes()).hexdigest() for n in files},indent=2))
print('PREPARED 22 unique parameters, MCPE and matched CDA8; c27 ALK 1500 TU')
