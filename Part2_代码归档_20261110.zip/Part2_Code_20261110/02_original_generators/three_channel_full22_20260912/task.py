from pathlib import Path
import sys,os,json
import numpy as np
import audit_base as audit
from checked_exec import checked
B=Path(__file__).resolve().parent
def run(mode,seed,d,steps=10000000,start=9000000,end=10000000,checkpoint=False):
    assert mode in ['MCPE','CDA8'];v=6 if mode=='MCPE' else 3
    d.mkdir(parents=True,exist_ok=False)
    env={k:v for k,v in os.environ.items() if not k.startswith('MCPE_')}
    env.update(MCPE_SCHEME='22',MCPE_VARIANT=str(v),MCPE_SEED=str(seed),MCPE_FREQ='1,4,20',
      MCPE_PARAM_CHANNELS='x123_w_TL',MCPE_STEPS=str(steps),MCPE_EVAL=str(start),MCPE_EVAL_END=str(end),
      MCPE_SAVE_PARAM_MEAN='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    if steps!=10000000:env['MCPE_SMOKE']='1'
    if checkpoint:env['MCPE_CHECKPOINT']='checkpoint.txt'
    try:
        execution=checked(B/'exp21_new',d,env,'run')
        a=audit.validate(d,22,v,steps,start,end)
        init=np.loadtxt(d/'initial_parameters.txt');assert (init[[35,39],3]>0).all()
        a.update(mode=mode,seed=seed,execution=execution)
        if mode=='MCPE':
            schedule=np.loadtxt(d/'schedule.txt',dtype=np.int64)
            expected=np.array([[p['row45'],p['entry_TU']*100,10000001]+[audit.CFG['cycles_TU'][p['name']].get(o,0)*100 for o in audit.OBS] for p in audit.CFG['schemes'][-1]['parameters']])
            np.testing.assert_array_equal(schedule,expected)
        (d/'audit.json').write_text(json.dumps(a,indent=2));(d/'READY').touch();print('READY',mode,seed,steps,flush=True)
    except Exception as e:(d/'FAILED').write_text(repr(e));raise
def preflight():
    env=os.environ.copy();env['MCPE_PARAM_CHANNELS']='x123_w_TL'
    checked(B/'test_config',B,env,'config');assert 'CONFIG_TEST_PASS' in (B/'config.log').read_text()
    for mode in ['MCPE','CDA8']:run(mode,0,B/'preflight'/mode,1999900,1999000,1999900,True)
    for name in ['initial_parameters.txt','checkpoint.txt','parameter_mean.txt']:
        assert (B/'preflight/MCPE'/name).read_bytes()==(B/'preflight/CDA8'/name).read_bytes()
    run('MCPE',0,B/'preflight/all_entry',6400000,6398000,6400000)
    u=np.loadtxt(B/'preflight/all_entry/parameter_updates.txt',dtype=np.int64).reshape(45,8,5)
    assert u[39,7,2]>0 and u[35,7,2]>0
    assert not u[[39,35],:7,2].any()
    assert not u[[8,14],7,2].any()
    (B/'PREFLIGHT_PASS').write_text('22 unique rows; masks; cycles; equal pre-entry states; all-entry update counts; finite values passed.\n')
    print('PREFLIGHT_PASS',flush=True)
if __name__=='__main__':
    if sys.argv[1]=='preflight':preflight()
    else:
        assert (B/'PREFLIGHT_PASS').exists();i=int(sys.argv[1]);assert 0<=i<20
        mode='MCPE' if i<10 else 'CDA8';run(mode,i%10,B/'runs'/f'{mode}{i%10}')
