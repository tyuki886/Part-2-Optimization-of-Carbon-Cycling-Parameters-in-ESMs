from pathlib import Path
import sys,json,hashlib,getpass,time
import paramiko
B=Path(__file__).resolve().parent
R='/public/home/hou/wyh/MCPE26.0/three_channel_full22_20260912'
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
DEPS='/public/home/hou/wyh/MCPE26.0/twin_work_3x3/python_deps'
def pbs(name,action):
    return f'''#!/bin/bash
#PBS -N {name}
#PBS -q new
#PBS -l nodes=1:ppn=1
#PBS -l walltime=01:00:00
#PBS -j oe
set -eu
cd {R}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH={R}:{DEPS}
{PY} {action}
'''
c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('222.195.137.80',username='hou',password=getpass.getpass('HPC password: '),timeout=25,look_for_keys=False,allow_agent=False)
def cmd(s):
    _,o,e=c.exec_command(s,timeout=180);a=o.read().decode();b=e.read().decode();code=o.channel.recv_exit_status()
    assert code==0,(code,a,b)
    return a
try:
    if sys.argv[1]=='deploy':
        cmd(f'test ! -e {R} && mkdir -p {R}/logs')
        manifest=json.loads((B/'manifest.json').read_text())
        with c.open_sftp() as ftp:
            for n,h in manifest.items():
                assert hashlib.sha256((B/n).read_bytes()).hexdigest()==h
                ftp.put(str(B/n),R+'/'+n)
            ftp.put(str(B/'manifest.json'),R+'/manifest.json')
            for fn,name,action in [('preflight.pbs','TriCheck','task.py preflight'),('run.pbs','TriFull22','task.py "${PBS_ARRAYID:?}"'),('post.pbs','TriPost','summarize.py')]:
                with ftp.open(R+'/'+fn,'w') as f:f.write(pbs(name,action))
        a=cmd(f'''set -eu
cd {R}
{PY} -c 'import pathlib,json,hashlib;m=json.load(open("manifest.json"));assert all(hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest()==h for n,h in m.items());print("HASHES_PASS")'
gfortran -O3 -ffree-line-length-none -c RKmethod.f90
gfortran -O3 -ffree-line-length-none -c MCPE42_new.f90
gfortran -O3 -ffree-line-length-none exp21_new.f90 MCPE42_new.o RKmethod.o -o exp21_new
gfortran -O0 -fcheck=all -ffree-line-length-none test_config.f90 MCPE42_new.o RKmethod.o -o test_config
{PY} -m py_compile task.py audit_base.py checked_exec.py summarize.py
cd logs
qsub ../preflight.pbs > ../preflight_job.txt
cat ../preflight_job.txt
''')
        (B/'submission.json').write_text(json.dumps({'preflight':a,'files':manifest},indent=2))
        print(a,flush=True)
    elif sys.argv[1]=='finish':
        previous=None
        for _ in range(90):
            s=json.loads(cmd(f'''cd {R} && {PY} -c 'from pathlib import Path;import json;p=Path(".");print(json.dumps(dict(preflight=(p/"PREFLIGHT_PASS").exists(),production=(p/"production_job.txt").exists(),ready=len(list(p.glob("runs/*/READY"))),failed=[str(f) for f in p.glob("*/*/FAILED")],post=(p/"post_job.txt").exists(),complete=(p/"RESULTS_READY").exists(),post_failed=(p/"POST_FAILED").read_text() if (p/"POST_FAILED").exists() else None)))' '''))
            if previous!=s:print(json.dumps(s),flush=True);previous=s
            if s['failed'] or s['post_failed']:
                print(cmd(f'cd {R}; tail -n 30 logs/TriCheck.o* logs/TriPost.o* 2>/dev/null || true'),flush=True)
                raise RuntimeError(s)
            if s['preflight'] and not s['production']:
                print('PRODUCTION_JOB',cmd(f'cd {R} && test -f PREFLIGHT_PASS && test ! -e production_job.txt && cd logs && qsub -t 0-19%10 ../run.pbs > ../production_job.txt && cat ../production_job.txt'),flush=True)
            if s['ready']==20 and not s['post']:
                print('POST_JOB',cmd(f'cd {R} && test ! -e post_job.txt && cd logs && qsub ../post.pbs > ../post_job.txt && cat ../post_job.txt'),flush=True)
            if s['complete']:
                with c.open_sftp() as ftp:
                    for n in ['summary.json','validation.json','RESULTS_READY','PREFLIGHT_PASS','preflight_job.txt','production_job.txt','post_job.txt']:
                        ftp.get(R+'/'+n,str(B/n))
                out=json.loads((B/'summary.json').read_text())
                print('RMSE_MEAN',json.dumps(out['RMSE_mean']),flush=True)
                print('IMPROVED_SEEDS',out['improved_seeds'],flush=True)
                break
            time.sleep(20)
        else:print('CHECK_WINDOW_ENDED_WITHOUT_COMPLETION',flush=True)
    else:raise ValueError(sys.argv[1])
finally:c.close()
