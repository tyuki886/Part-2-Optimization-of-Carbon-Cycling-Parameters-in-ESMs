from pathlib import Path
import json,hashlib
import numpy as np
import audit_base as audit
B=Path(__file__).resolve().parent
def main():
    rms={};receipts=[]
    for mode,v in [('MCPE',6),('CDA8',3)]:
        rows=[]
        for seed in range(10):
            d=B/'runs'/f'{mode}{seed}';assert (d/'READY').exists() and not (d/'FAILED').exists()
            a=audit.validate(d,22,v,10000000,9000000,10000000)
            assert json.loads((d/'audit.json').read_text())['execution']['real_model_exit']==0
            twin=B/'runs'/f'CDA8{seed}'
            assert (d/'initial_parameters.txt').read_bytes()==(twin/'initial_parameters.txt').read_bytes()
            h=np.loadtxt(d/'parameter_mean.txt');h2=np.loadtxt(twin/'parameter_mean.txt')
            np.testing.assert_array_equal(h[h[:,0]<=20000],h2[h2[:,0]<=20000])
            rows.append(a['rmse']);receipts.append({'mode':mode,'seed':seed,'rmse_sha256':hashlib.sha256((d/f'rmse_M22_v{v:02d}.txt').read_bytes()).hexdigest()})
        rms[mode]=np.array(rows)
    delta=rms['MCPE']-rms['CDA8']
    out={'variables':['x1','x2','x3','w','eta','ice','TL','Catm','Cocean','ALK'],
      'RMSE_mean':{k:v.mean(axis=0).tolist() for k,v in rms.items()},'RMSE_per_seed':{k:v.tolist() for k,v in rms.items()},
      'MCPE_minus_CDA8':delta.tolist(),'improved_seeds':(delta<0).sum(axis=0).tolist(),
      'seed_count':10,'ensemble_size':20,'window_TU':[90000,100000],'boundary':'(90000,100000]',
      'native_samples_per_seed':1000000,'estimated_parameters':22,
      'design':'Full22 shared ensemble; C2 water and Catm/Cocean periods; measured ALK periods; c27=1500 TU user override.',
      'limitations':['New 22-parameter initialization; old CDA8 RMSE is not the matched baseline.','Exploratory ten seeds, no independent validation seeds.','Multiple design changes; not a one-factor ablation.']}
    (B/'summary.json').write_text(json.dumps(out,indent=2))
    (B/'validation.json').write_text(json.dumps({'validated_runs':20,'all_seeds_retained':True,'paired_initialization_exact':True,'receipts':receipts},indent=2))
    (B/'RESULTS_READY').write_text('20 matched runs verified\n');print(json.dumps(out['RMSE_mean']),flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:(B/'POST_FAILED').write_text(repr(e));raise
