import re
MAP={'c24':'c17','c17':'c18','c18':'c19','c19':'c20','c20':'c21','c21':'c22',
     'c22':'c23','c23':'c24','c25':'A0','c26':'c27','c27':'c28','c28':'c29',
     'c29':'c25','c30':'c26','E':'E0','E_rate':'E0'}
SUB=str.maketrans('0123456789','₀₁₂₃₄₅₆₇₈₉')
UNSUB=str.maketrans('₀₁₂₃₄₅₆₇₈₉','0123456789')
def rename_code(text):
    pattern=re.compile(r'\b(?:'+ '|'.join(sorted(MAP,key=len,reverse=True))+r')\b',re.I)
    lookup={k.lower():v for k,v in MAP.items()}
    return pattern.sub(lambda m:lookup[m.group().lower()],text)
def rename_display(text):
    # One simultaneous pass: replacements must never feed back into this map.
    pat=re.compile(r'(?<![A-Za-z_])c(?:_?\{([0-9]+)\}|_([0-9]+)|([0-9₀-₉]+))|(?<![A-Za-z0-9_])E(?![A-Za-z0-9_])')
    def sub(m):
        if m.group()=='E':return r'E_{0}' if '$' in text else 'E₀'
        index=next(g for g in m.groups() if g is not None).translate(UNSUB)
        old='c'+index;new=MAP.get(old,old)
        if new==old:return m.group()
        base=new[0];idx=new[1:]
        if m.group(1) is not None or m.group(2) is not None:return base+'_{'+idx+'}'
        if any(ch in m.group() for ch in '₀₁₂₃₄₅₆₇₈₉'):return base+idx.translate(SUB)
        return base+idx
    return pat.sub(sub,text)
