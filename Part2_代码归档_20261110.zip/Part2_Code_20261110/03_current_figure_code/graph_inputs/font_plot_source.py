from pathlib import Path
import hashlib, json, string, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
from matplotlib import font_manager
from PIL import Image

WORK = Path(__file__).resolve().parent
OUT = WORK / 'figures'
OUT.mkdir(exist_ok=True)
RESULTS = WORK / 'saturation_22_results.json'
CONFIG = WORK / 'config.json'
font_manager.fontManager.addfont(str(WORK / 'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman', 'font.size':9, 'axes.titlesize':10, 'axes.labelsize':9, 'xtick.labelsize':8, 'ytick.labelsize':8,
    'mathtext.fontset':'stix', 'axes.linewidth':.7, 'path.simplify':False,
    'agg.path.chunksize':10000, 'xtick.major.width':.5, 'ytick.major.width':.5,
    'xtick.major.size':2.5, 'ytick.major.size':2.5})
WATER = ['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11']
CARBON = ['c24','c16','c20','c29','c18','c30','c28','c19','c22','c23','c27','c17']
VARS = ['x2','w','TL','Catm','Cocean','ALK']
DISPLAY = ['$x_2$','$w$','$T_L$','$C_{\\mathrm{atm}}$','$C_{\\mathrm{ocn}}$','ALK']
COLS = [2,4,5,6,7,8]
LIMITS = [20,50,50,100,100,2000]
COLORS = ['#15558C','#CE6600','#227432','#AA2439']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pname(name):
    return {'kappa':r'$\kappa$', 'sigma':r'$\sigma$', 'lambda':r'$\lambda$',
            'b':'$b$'}.get(name, '$c_{'+name[1:]+'}$')

def evaluate(t, f):
    # Only restores the original plotting bounds; no fitting is performed.
    x=np.asarray(t)/f['window_TU']; k=f['k_per_TU']*f['window_TU']
    tau=f['inflection_TU']/f['window_TU']; decay=-np.expm1(-k*x)
    if f['model']=='Logistic':
        shape=decay/(1+np.exp(np.clip(-k*(x-tau),-700,700)))
    else:
        z0=np.exp(np.clip(k*tau,-50,50)); z=np.exp(np.clip(k*(tau-x),-50,50))
        shape=np.exp(-z)*(-np.expm1(-z0*decay))/(-np.expm1(-z0))
    return f['A']*shape

def save(fig, name):
    path=OUT/name
    fig.savefig(path,dpi=600,bbox_inches='tight',pad_inches=.035,facecolor='white')
    plt.close(fig)
    with Image.open(path) as im:
        pixels=im.size
        im.thumbnail((1500,1900))
        im.save(WORK/(path.stem+'_preview.png'))
    return {'path':str(path),'sha256':digest(path),'pixels':pixels}

def saturation():
    result_hash=digest(RESULTS)
    rows=json.loads(RESULTS.read_text())['results']
    assert len(rows)==66
    raw={}; checks=[]
    sources=json.loads((WORK/'curve_sources.json').read_text(encoding='utf-8'))
    expected=json.loads((WORK/'array_hashes.json').read_text())
    packed=np.load(WORK/'curve_data.npz',allow_pickle=False)
    for name in WATER+CARBON:
        for j in (range(3) if name in WATER else range(3,6)):
            tt=packed[f'{name}_{VARS[j]}_t'];yy=packed[f'{name}_{VARS[j]}_y']
            for suffix,val in [('t',tt),('y',yy)]:
                assert hashlib.sha256(np.ascontiguousarray(val).tobytes()).hexdigest()==expected[f'{name}_{VARS[j]}_{suffix}']
            raw[name,VARS[j]]=(tt,yy)
    groups=[WATER[:3],WATER[3:6],WATER[6:],CARBON[:4],CARBON[4:8],CARBON[8:]]
    fig,axes=plt.subplots(6,3,figsize=(8.2,10.2))
    fig.subplots_adjust(left=.08,right=.985,bottom=.045,top=.945,wspace=.38,hspace=.65)
    fig.suptitle('Parameter sensitivity responses and saturation-time estimates',fontsize=12.5,y=.992)
    for row,group in enumerate(groups):
        for col in range(3):
            j=col if row<3 else col+3; v=VARS[j]; ax=axes[row,col]
            for k,name in enumerate(group):
                r=next(r for r in rows if r['parameter']==name and r['variable']==v)
                assert r['source_sha256']==sources[name]['sha256']
                t,y=raw[name,v]; ts=r['measured_TU']
                label=pname(name)+(f' ({ts:.1f})' if ts is not None else '')
                line,=ax.plot(np.r_[0,t],np.r_[0,y],color=COLORS[k],lw=.55,label=label)
                np.testing.assert_array_equal(line.get_xdata()[1:],t)
                np.testing.assert_array_equal(line.get_ydata()[1:],y)
                if ts is not None:
                    ax.plot(ts,r['marker_y'],'o',ms=2.5,color=COLORS[k],mec='black',mew=.3,zorder=6)
                checks.append({'panel':string.ascii_lowercase[row*3+col], 'parameter':name,
                    'variable':v,'samples':len(t),'measured_TU':ts,'marker_y':r['marker_y'],
                    'raw_samples_exact':True,'window_TU':LIMITS[j]})
            ymax=max(max(float(np.max(raw[name,v][1])),float(np.max(evaluate(raw[name,v][0],
                next(r for r in rows if r['parameter']==name and r['variable']==v)['fit'])))) for name in group)
            ax.set(xlim=(0,LIMITS[j]),ylim=(0,1.07*ymax))
            ax.set_xlabel('Time (TU)',fontsize=9,labelpad=2)
            ax.set_ylabel(DISPLAY[j],fontsize=9,labelpad=2)
            ax.set_title(f'({string.ascii_lowercase[row*3+col]}) '+DISPLAY[j],fontsize=10,pad=3)
            ax.tick_params(labelsize=8,pad=1.5)
            ax.grid(alpha=.2,ls=':',lw=.5)
            ax.legend(loc='lower right',fontsize=8,framealpha=.9,handlelength=1.3,
                handletextpad=.35,borderpad=.25,labelspacing=.13,columnspacing=.5)
    output=save(fig,'Fig2_22parameters_font_unified.png')
    assert len(checks)==66 and len(sources)==22 and digest(RESULTS)==result_hash
    return {'source_results':str(RESULTS),'source_results_sha256':result_hash,
        'layout':'6 rows by 3 columns; water first 3 rows; carbon last 3 rows',
        'legend_times_unit':'TU','new_fits_performed':False,'fitted_lines_displayed':False,
        'sources':sources,'checks':checks,'output':output}

def timeline():
    config_hash=digest(CONFIG); cfg=json.loads(CONFIG.read_text(encoding='utf-8'))
    schemes=cfg['schemes']; assert schemes==[12,15,18,21,24,27,30]
    colors=['#DC6E4B','#4C7EDB','#268577']; entries=[]
    fig=plt.figure(figsize=(8.2,5.6))
    grid=fig.add_gridspec(2,1,height_ratios=[5.8,1.35],hspace=.4,
        left=.14,right=.985,bottom=.09,top=.86)
    ax=fig.add_subplot(grid[0]); labels=[]
    for row,n in enumerate(schemes):
        y=len(schemes)-1-row; labels.append(f'MCPE{n}\n({n//3}+{n//3}+{n//3})')
        slots=cfg['configs']['sync'][str(n)]['slots']; assert len(slots)==n
        for slot in slots:
            g=slot['group'];rank=slot['rank'];t=slot['entry_TU']
            assert t==20000+6000*(rank-1)+(0 if g==0 else 2000)
            assert slot['name']==cfg['groups'][g][rank-1]
            channels=range(5) if g==0 else ([5,6] if g==1 else [7])
            for ch in channels:
                assert cfg['configs']['sync'][str(n)]['entries_steps'][slot['name']][ch]==round(t/cfg['dt_TU'])
            bottom=y-.36 if g in [0,2] else y
            height=.72 if g==0 else .36; width=2 if g==0 else 4
            ax.add_patch(Rectangle((t/1000,bottom),width,height,
                facecolor=colors[g],edgecolor='white',linewidth=.35))
            ax.text(t/1000+width/2,bottom+height/2,pname(slot['name']),
                ha='center',va='center',fontsize=8,color='white')
            entries.append({'scheme':n,**slot,'box_end_TU':t+width*1000,'box_width_TU':width*1000})
        for rank in range(1,n//3+1):
            ss=[e for e in entries if e['scheme']==n and e['rank']==rank]
            water=next(s for s in ss if s['group']==0)
            c=next(s for s in ss if s['group']==1); alk=next(s for s in ss if s['group']==2)
            assert water['box_end_TU']==c['entry_TU']==alk['entry_TU']
            assert c['box_end_TU']==alk['box_end_TU']==20000+6000*rank
    ax.set(xlim=(20,80),ylim=(-.6,6.65),yticks=range(6,-1,-1),yticklabels=labels)
    ax.set_xticks(range(20,81,6)); ax.set_xticks(range(20,81,2),minor=True)
    ax.set_xlabel(r'Time ($10^3$ TU)',fontsize=9,labelpad=2)
    ax.tick_params(axis='x',labelsize=8,pad=2);ax.tick_params(axis='y',length=0,labelsize=8,pad=3)
    ax.grid(axis='x',which='major',color='#DDDDDD',lw=.4)
    ax.grid(axis='x',which='minor',color='#EFEFEF',lw=.3); ax.set_axisbelow(True)
    fig.suptitle('MCPE parameter-entry timeline',fontsize=12.5,y=.985)
    fig.legend(handles=[Patch(facecolor=c,label=l) for c,l in zip(colors,
        ['Water-cycle parameters','Carbon: $C_{\\mathrm{atm}}$ / $C_{\\mathrm{ocn}}$','Carbon: ALK'])],
        loc='upper center',bbox_to_anchor=(.56,.951),ncol=3,fontsize=8,frameon=False,
        handlelength=1.2,columnspacing=1)
    phase=fig.add_subplot(grid[1]); phase.set(xlim=(0,100),ylim=(0,1.65))
    for start,width,color,label in [(0,10,'#A7A7A7','Spin-up'),(10,10,'#5E8FD2','Pure CDA')]:
        phase.add_patch(Rectangle((start,.25),width,.66,facecolor=color,edgecolor='white',lw=.5))
        phase.text(start+width/2,.58,label,ha='center',va='center',color='white',fontsize=8)
    phase.add_patch(Rectangle((20,.25),80,.66,facecolor='#F1C6B5',edgecolor='white',lw=.5))
    phase.text(60,.58,'State assimilation + parameter estimation',ha='center',va='center',fontsize=8)
    phase.annotate('',xy=(20,1.16),xytext=(76,1.16),
        arrowprops={'arrowstyle':'|-|','color':'#A14E34','lw':.6})
    phase.text(48,1.31,'Progressive channel entry',ha='center',fontsize=8)
    phase.add_patch(Rectangle((90,1),10,.2,facecolor='#D9A90D',edgecolor='none'))
    phase.text(95,1.31,'RMSE window',ha='center',fontsize=8)
    phase.set_xticks([0,20,40,60,80,100]);phase.set_xlabel(r'Time ($10^3$ TU)',fontsize=9,labelpad=2)
    phase.tick_params(labelsize=8,length=0,pad=2);phase.set_yticks([])
    for spine in phase.spines.values():spine.set_visible(False)
    output=save(fig,'Fig3_MCPE_timeline_font_unified.png')
    assert digest(CONFIG)==config_hash
    return {'source':str(CONFIG),'source_sha256':config_hash,'entries':entries,
        'footer_removed':True,'phase_bars_retained':True,'time_values_unchanged':True,
        'axis_unit':'1000 TU','output':output}

if __name__=='__main__':
    audit={'saturation':saturation(),'timeline':timeline(),'font':{'family':'Times New Roman','mathtext':'stix','base_pt':9,'axes_labels_pt':9,'ticks_pt':8,'panel_titles_pt':10,'figure_titles_pt':12.5}}
    (WORK/'figure_integrity_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v['output'] for k,v in audit.items() if k!='font'},ensure_ascii=False))
