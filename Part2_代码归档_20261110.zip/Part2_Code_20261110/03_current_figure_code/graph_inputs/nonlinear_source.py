"""仅压缩既有ALK/Bcal/括号项三联图的高度，全部数据、窗口和颜色保持不变。"""
from pathlib import Path
import json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'nonlinear_compact_20260914'
OUT.mkdir(exist_ok=True)
COLORS={'CTL':'#4a7bd9','CDA5':'#d96b4a','CDA7':'#2e9e5b'}
STEMS={'CTL':'rmse_M10_v00.txt','CDA5':'rmse_M20_v01.txt','CDA7':'rmse_M20_v02.txt'}
font_manager.fontManager.addfont(r'C:\Windows\Fonts\times.ttf')
plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'path.simplify':False})
original_audit=json.loads((ROOT/'nonlinear_combined'/'audit.json').read_text(encoding='utf-8'))
sources=[]

def load(kind,start,stop,ncols):
    result={};expected=np.arange(start*100,stop*100+1)/100.
    for name,stem in STEMS.items():
        path=ROOT/'local_results'/f'results_C80_F1_4_20_{kind}'/name/'seed0'/f'{stem}.{kind}'
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        previous=next(s for s in original_audit['sources'] if Path(s['path'])==path)
        assert digest==previous['sha256']
        d=np.loadtxt(path);assert d.shape==(len(expected),ncols) and np.isfinite(d).all()
        np.testing.assert_allclose(d[:,0],expected,rtol=0,atol=1e-8)
        result[name]=d;sources.append({'path':str(path),'sha256':digest,'shape':list(d.shape)})
    for name in ['CDA5','CDA7']:
        np.testing.assert_array_equal(result[name][:,1],result['CTL'][:,1])
        if ncols==5:np.testing.assert_array_equal(result[name][:,3],result['CTL'][:,3])
    return result

alk=load('alktraj',10000,11000,3)
bcal=load('bcaltraj',10400,10500,5)
panels=[
    (alk,1,2,'ALK','ALK time series: CTL, CDA5 and CDA7 (10000–11000 TU; 0.01 TU sampling)',(10000,11000)),
    (bcal,1,2,'Bcal','Bcal time series: CTL, CDA5 and CDA7 (10400–10500 TU; 0.01 TU sampling)',(10400,10500)),
    (bcal,3,4,'ALK - c27·Cocean + c28','Bcal nonlinear bracket: CTL, CDA5 and CDA7 (10400–10500 TU; 0.01 TU sampling)',(10400,10500))]
fig,axes=plt.subplots(3,1,figsize=(13,10.5),sharex=False)
for ax,(data,tc,sc,ylabel,title,limits) in zip(axes,panels):
    t=data['CTL'][:,0]
    line,=ax.plot(t,data['CTL'][:,tc],color='#222222',lw=1.25,ls='--',label='Truth',zorder=4)
    np.testing.assert_array_equal(line.get_ydata(),data['CTL'][:,tc])
    for name in COLORS:
        line,=ax.plot(t,data[name][:,sc],color=COLORS[name],lw=1,label=name)
        np.testing.assert_array_equal(line.get_xdata(),data[name][:,0])
        np.testing.assert_array_equal(line.get_ydata(),data[name][:,sc])
    if tc==3:ax.axhline(0,color='#777777',lw=.9,ls=':',zorder=1)
    ax.set_xlim(*limits)
    ax.set_xlabel('Time (TU)',fontsize=12,labelpad=3)
    ax.set_ylabel(ylabel,fontsize=12)
    ax.set_title(title,fontsize=13,pad=7)
    ax.ticklabel_format(axis='x',style='plain',useOffset=False)
    ax.grid(True,ls='--',lw=.6,alpha=.35)
    ax.legend(loc='best',frameon=True,fontsize=10,ncol=2)
fig.tight_layout(pad=1.15,h_pad=1.5)
target=OUT/'ALK_Bcal_nonlinear_bracket_vertical_compact.png'
fig.savefig(target,dpi=300,bbox_inches='tight',facecolor='white')
positions=[{'xlim':list(ax.get_xlim()),'ylim':list(ax.get_ylim())} for ax in axes]
plt.close(fig)
with Image.open(target) as im:
    pixels=list(im.size)
    im.thumbnail((1300,1050));im.convert('RGB').save(OUT/'preview.jpg',quality=75)
reference=Path(r'D:\SRDP\论文大作！\MCPE26.0\9.2\1,4,20\非线性\ALK_Bcal_nonlinear_bracket_vertical.png')
with Image.open(reference) as im:old_pixels=list(im.size)
audit={'sources':sources,'original_figure':str(reference),'output':str(target),
       'original_pixels':old_pixels,'compact_pixels':pixels,
       'height_reduction_same_width_pct':100*(1-(pixels[1]/pixels[0])/(old_pixels[1]/old_pixels[0])),
       'sample_counts_per_curve':[100001,10001,10001],'original_sources_hash_verified':True,
       'smoothed':False,'resampled':False,'axes':positions,'font':'Times New Roman','dpi':300,
       'layout_change':'figure height 17.5 to 10.5 inches; tighter gaps; 2-column legends'}
(OUT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in audit.items() if k!='sources'},ensure_ascii=False))
