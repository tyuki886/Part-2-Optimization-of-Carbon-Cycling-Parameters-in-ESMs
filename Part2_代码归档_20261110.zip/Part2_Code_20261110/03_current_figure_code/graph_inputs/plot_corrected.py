from matplotlib import pyplot as plt,font_manager
def configure_font(base):
 font_manager.fontManager.addfont(str(base/'times.ttf'))
 plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'mathtext.fontset':'stix','axes.titlesize':13,'axes.labelsize':11,'xtick.labelsize':10,'ytick.labelsize':10,'axes.linewidth':.8,'savefig.facecolor':'white','figure.facecolor':'white'})
