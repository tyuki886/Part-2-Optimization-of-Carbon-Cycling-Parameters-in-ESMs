"""Parameter-ensemble diagnostics from saved means and population SDs, no fabricated members."""
from pathlib import Path
import sys,json,hashlib,math
B=Path(__file__).resolve().parent
for d in [B.parent/'twin_work_3x3/python_deps',B.parent/'power_combined/python_deps']:
    sys.path.insert(0,str(d))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from PIL import Image
import plot_corrected as plot
OUT=B/'parameter_ensemble_20260913'
SCHEMES=[12,15,18,21,24,27,30]

def main():
    OUT.mkdir(exist_ok=True)
    C=json.loads((B/'config.json').read_text());old=np.load(B/'figures/parameter_means/plot_source_arrays.npz')
    t=np.arange(0,100001,100);arrays={'time_TU':t};receipts=[]
    meta={'schemes':SCHEMES,'obs':8,'window_TU':[0,100000],'record_interval_TU':100,
        'seeds':list(range(10)),'members_per_seed':20,'all_seeds_retained':True,
        'member_trajectories_available':False,'no_reconstructed_members':True,
        'band':'Pooled mean +/- one pooled population SD across all 10 x 20 members; not a confidence interval or quantile range.',
        'pooled_variance':'mean_seed(within_seed_population_variance) + variance_seed(ensemble_mean, ddof=0)',
        'within_spread':'sqrt(mean_seed(within_seed_population_variance)) / abs(truth)',
        'between_seed_sd':'std_seed(ensemble_mean, ddof=0) / abs(truth)',
        'parameter_error':'sqrt(mean_seed((ensemble_mean-truth)^2)) / abs(truth)',
        'images':{}}
    plot.configure_font(B)
    for n in SCHEMES:
        histories=[];truth=None
        for s in range(10):
            d=B/'runs'/f'M{n}_v6'/f'seed{s}';assert (d/'READY').exists() and not (d/'FAILED').exists()
            p=d/'parameter_mean.txt';h=np.loadtxt(p);initial=np.loadtxt(d/'initial_parameters.txt');final=np.loadtxt(d/'final_parameters.txt')
            assert h.shape==(1501,91) and initial.shape==final.shape==(45,4)
            np.testing.assert_array_equal(h[:,0],np.arange(0,150001,100))
            assert np.isfinite(h).all() and (h[:,46:91]>=0).all()
            np.testing.assert_array_equal(h[0,1:46],initial[:,2]);np.testing.assert_array_equal(h[0,46:91],initial[:,3])
            np.testing.assert_array_equal(h[-1,1:46],final[:,2]);np.testing.assert_array_equal(h[-1,46:91],final[:,3])
            if truth is None:truth=initial[:,1]
            else:np.testing.assert_array_equal(truth,initial[:,1])
            histories.append(h[:1001]);receipts.append({'scheme':n,'seed':s,'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        H=np.array(histories);mu=H[:,:,1:46];sd=H[:,:,46:91]
        np.testing.assert_array_equal(mu,old[f'M{n}_seed_means']);np.testing.assert_array_equal(truth,old[f'M{n}_truth'])
        assert (truth!=0).all()
        center=mu.mean(0);within=np.mean(sd**2,axis=0);between=np.mean((mu-center[None,:,:])**2,axis=0)
        pooled=np.sqrt(within+between);error=np.sqrt(np.mean((mu-truth[None,None,:])**2,axis=0))
        # Independent second-moment identity, not an average of interval bounds.
        second=np.mean(sd**2+mu**2,axis=0)-center**2
        np.testing.assert_allclose(pooled**2,second,rtol=1e-8,atol=1e-9)
        np.testing.assert_allclose(error**2,between+(center-truth)**2,rtol=1e-10,atol=1e-12)
        for name,a in [('seed_means',mu),('seed_population_sd',sd),('truth',truth),('pooled_mean',center),('pooled_sd',pooled),
                       ('within_rms_sd',np.sqrt(within)),('between_seed_sd',np.sqrt(between)),('mean_parameter_rmse',error)]:arrays[f'M{n}_{name}']=a
        cfg=C['configs']['sync'][str(n)];names=cfg['unique_parameters']
        display=[p for p in names if p in C['groups'][0]]+[p for p in names if p not in C['groups'][0]]
        nr=math.ceil(len(display)/4)
        for kind in ['mean_spread','spread_error']:
            folder=OUT/kind;folder.mkdir(exist_ok=True)
            fig,axes=plt.subplots(nr,4,figsize=(16,3.2*nr),squeeze=False)
            bounds=[]
            for ax,p in zip(axes.flat,display):
                j=C['row45'][p]-1;den=abs(truth[j]);color='#2166AC' if p in C['groups'][0] else '#B2182B'
                if kind=='mean_spread':
                    a=center[:,j]/truth[j];z=pooled[:,j]/den;lo=a-z;hi=a+z
                    ax.fill_between(t,lo,hi,color=color,alpha=.20,lw=0)
                    for s in range(10):
                        ln,=ax.plot(t,mu[s,:,j]/truth[j],color='#888888',lw=.55,alpha=.5,zorder=2)
                        np.testing.assert_array_equal(ln.get_ydata(),mu[s,:,j]/truth[j])
                    ln,=ax.plot(t,a,color=color,lw=1.4,zorder=4);np.testing.assert_array_equal(ln.get_ydata(),a)
                    ax.axhline(1,color='black',ls='--',lw=1,zorder=3);ax.set_ylabel('Parameter / truth')
                    bounds.append({'parameter':p,'row':j+1,'band_min':float(lo.min()),'band_max':float(hi.max())})
                    assert np.isfinite(lo).all() and np.isfinite(hi).all() and (lo<=hi).all()
                else:
                    ys=[np.sqrt(within[:,j])/den,np.sqrt(between[:,j])/den,error[:,j]/den]
                    for y,c,ls in zip(ys,['#2166AC','#777777','#D55E00'],['-',':','--']):
                        ln,=ax.plot(t,y,color=c,ls=ls,lw=1.3);np.testing.assert_array_equal(ln.get_ydata(),y)
                    ax.set_ylabel('Normalized spread / error');ax.set_ylim(bottom=0)
                for slot in cfg['slots']:
                    if slot['name']==p:ax.axvline(slot['entry_TU'],color='#777777',ls='-.' if slot['group']==2 else ':',lw=.8,zorder=1)
                ax.set(title=p,xlabel='Time (TU)',xlim=(0,100000));ax.set_xticks([0,20000,40000,60000,80000,100000]);ax.tick_params(axis='x',labelsize=8);ax.grid(alpha=.2)
            for ax in list(axes.flat)[len(display):]:ax.set_visible(False)
            if kind=='mean_spread':
                handles=[Line2D([],[],color='#888888',lw=.6,label='Individual seed ensemble means'),
                    Line2D([],[],color='#2166AC',lw=1.4,label='Mean over 10 seeds'),Patch(facecolor='#2166AC',alpha=.2,label='Mean +/- pooled SD'),
                    Line2D([],[],color='black',ls='--',label='Truth')]
                title=f'MCPE{n} parameter ensemble evolution (8obs)'
                foot='20 members per seed; 10 seeds | Shading: pooled population SD, not a confidence interval | No individual member paths reconstructed'
            else:
                handles=[Line2D([],[],color='#2166AC',lw=1.3,label='Within-seed RMS ensemble spread'),
                    Line2D([],[],color='#777777',ls=':',label='Between-seed SD of ensemble means'),
                    Line2D([],[],color='#D55E00',ls='--',label='RMSE of ensemble means across seeds')]
                title=f'MCPE{n} parameter spread and estimation error (8obs)'
                foot='All quantities normalized by absolute parameter truth | Population SD (ddof = 0) | All 10 seeds retained'
            fig.suptitle(title,fontsize=16,y=.99)
            fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.964),ncol=len(handles),frameon=False,fontsize=10)
            fig.text(.5,.026,foot,ha='center',fontsize=9)
            fig.text(.5,.012,'Recorded every 100 TU; no temporal smoothing | Entry lines: dotted = water or Catm/Cocean; dash-dot = ALK | Shared parameters shown once',ha='center',fontsize=9)
            fig.tight_layout(rect=(0,.045,1,.92));fig.canvas.draw()
            renderer=fig.canvas.get_renderer()
            for ax in axes.flat:
                if not ax.get_visible():continue
                boxes=[q.get_window_extent(renderer) for q in ax.get_xticklabels()]
                assert all(a.x1<b.x0 for a,b in zip(boxes,boxes[1:]))
            path=folder/f'parameter_{kind}_MCPE{n}_8obs.png';fig.savefig(path,dpi=300);plt.close(fig)
            with Image.open(path) as im:im.verify()
            with Image.open(path) as im:size=list(im.size)
            meta['images'][str(path.relative_to(OUT))]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':size,'parameters':display,'bound_values_checked':True,'band_extrema':bounds}
            print('FIGURE_READY',kind,n,flush=True)
    np.savez_compressed(OUT/'plot_arrays.npz',**arrays);assert len(meta['images'])==14 and len(receipts)==70
    meta['sources']=receipts
    (OUT/'audit.json').write_text(json.dumps(meta,indent=2));(OUT/'READY').write_text('14 parameter ensemble PNGs; moments verified; visual QA pending.\n')
if __name__=='__main__':
    try:main()
    except Exception as E0:OUT.mkdir(exist_ok=True);(OUT/'FAILED').write_text(repr(E0));raise
