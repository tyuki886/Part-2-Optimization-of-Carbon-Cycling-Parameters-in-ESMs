"""Layout-only compact MCPE30 parameter ensemble figure, from validated saved moments."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from PIL import Image
import plot_corrected as plot
B=Path(__file__).resolve().parent;S=B/'parameter_ensemble_20260913';O=S/'compact_mcpe30';O.mkdir(exist_ok=True)
src=S/'plot_arrays.npz';h=hashlib.sha256(src.read_bytes()).hexdigest();a=np.load(src)
C=json.loads((B/'config.json').read_text());cfg=C['configs']['sync']['30'];names=cfg['unique_parameters']
display=[p for p in names if p in C['groups'][0]]+[p for p in names if p not in C['groups'][0]]
assert len(display)==22
t=a['time_TU'];mu=a['M30_seed_means'];sd=a['M30_seed_population_sd'];truth=a['M30_truth'];center=a['M30_pooled_mean'];pooled=a['M30_pooled_sd']
np.testing.assert_array_equal(center,mu.mean(0))
np.testing.assert_allclose(pooled**2,np.mean(sd**2,axis=0)+np.var(mu,axis=0),rtol=1e-10,atol=1e-12)
plot.configure_font(B)
fig,axes=plt.subplots(6,4,figsize=(16,16.4),squeeze=False)
fig.subplots_adjust(left=.055,right=.988,bottom=.034,top=.936,wspace=.31,hspace=.49)
checks=[]
for ax,p in zip(axes.flat,display):
    j=C['row45'][p]-1;den=abs(truth[j]);color='#2166AC' if p in C['groups'][0] else '#B2182B'
    y=center[:,j]/truth[j];z=pooled[:,j]/den;lo=y-z;hi=y+z
    band=ax.fill_between(t,lo,hi,color=color,alpha=.20,lw=0)
    vertices=band.get_paths()[0].vertices
    # Verify every band vertex lies on one of the actual saved mean +/- SD bounds.
    inds=np.searchsorted(t,vertices[:,0]);assert (inds<len(t)).all()
    assert np.all(np.isclose(vertices[:,1],lo[inds],rtol=0,atol=1e-12)|np.isclose(vertices[:,1],hi[inds],rtol=0,atol=1e-12))
    for s in range(10):
        line,=ax.plot(t,mu[s,:,j]/truth[j],color='#888888',lw=.55,alpha=.5,zorder=2)
        np.testing.assert_array_equal(line.get_ydata(),mu[s,:,j]/truth[j])
    line,=ax.plot(t,y,color=color,lw=1.4,zorder=4);np.testing.assert_array_equal(line.get_ydata(),y)
    ax.axhline(1,color='black',ls='--',lw=1,zorder=3);ax.set_ylabel('Parameter / truth')
    entries=[]
    for slot in cfg['slots']:
        if slot['name']==p:
            line=ax.axvline(slot['entry_TU'],color='#777777',ls='-.' if slot['group']==2 else ':',lw=.8,zorder=1)
            np.testing.assert_array_equal(line.get_xdata(),[slot['entry_TU']]*2);entries.append(slot['entry_TU'])
    ax.set(title=p,xlabel='Time (TU)',xlim=(0,100000));ax.set_xticks([0,20000,40000,60000,80000,100000]);ax.tick_params(axis='x',labelsize=8);ax.grid(alpha=.2)
    checks.append({'parameter':p,'entry_TU':entries,'ylim':list(ax.get_ylim()),'curves_verified':11,'band_verified':True})
for ax in list(axes.flat)[22:]:ax.set_visible(False)
handles=[Line2D([],[],color='#888888',lw=.6,label='Individual seed ensemble means'),Line2D([],[],color='#2166AC',lw=1.4,label='Mean over 10 seeds'),Patch(facecolor='#2166AC',alpha=.2,label='Mean +/- pooled SD'),Line2D([],[],color='black',ls='--',label='Truth')]
fig.suptitle('MCPE30 parameter ensemble evolution (8obs)',fontsize=16,y=.995)
leg=fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.977),ncol=4,frameon=False,fontsize=10)
fig.canvas.draw();renderer=fig.canvas.get_renderer();bb=leg.get_window_extent(renderer)
assert not bb.overlaps(fig._suptitle.get_window_extent(renderer))
for ax in list(axes.flat)[:22]:
    ab=ax.get_tightbbox(renderer);assert not ab.overlaps(bb)
    assert ab.x0>=0 and ab.y0>=0 and ab.x1<=fig.bbox.x1 and ab.y1<=fig.bbox.y1
    ticks=[q.get_window_extent(renderer) for q in ax.get_xticklabels()]
    assert all(x.x1<y.x0 for x,y in zip(ticks,ticks[1:]))
for i in range(18):
    assert not axes.flat[i].get_tightbbox(renderer).overlaps(axes.flat[i+4].get_tightbbox(renderer)),i
assert len(fig.texts)==1
p=O/'parameter_mean_spread_MCPE30_8obs.png';fig.savefig(p,dpi=300,facecolor='white');plt.close(fig)
assert hashlib.sha256(src.read_bytes()).hexdigest()==h
with Image.open(p) as im:size=list(im.size);assert size==[4800,4920]
(O/'validation.json').write_text(json.dumps({'source_sha256':h,'panels':checks,'size':size,'old_size':[4800,5760],'height_reduction_percent':100*(1-4920/5760),'data_unchanged':True,'removed':'bottom explanatory notes','footer_count':0},indent=2))
print(p);print('PASS: 22 panels, 242 data curves, 22 bands and all entry markers verified; no overlaps.')
