"""复用旧图的色块时间线样式，按已运行同步配置绘制七方案；不修改配置。"""
from pathlib import Path
import hashlib,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch,Rectangle
from matplotlib import font_manager
from PIL import Image

BASE=Path(__file__).resolve().parent
SRC=BASE/'config.json'
OUT=BASE/'entry_timeline_20260913_continuous'

def main():
    cfg=json.loads(SRC.read_text(encoding='utf-8'))
    digest=hashlib.sha256(SRC.read_bytes()).hexdigest()
    OUT.mkdir(exist_ok=True)
    schemes=cfg['schemes']; assert schemes==[12,15,18,21,24,27,30]
    font_manager.fontManager.addfont(str(BASE.parent/'saturation_remeasure_20260911'/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':13})
    colors=['#DC6E4B','#4C7EDB','#268577']
    fig=plt.figure(figsize=(21,10),layout='constrained')
    grid=fig.add_gridspec(3,1,height_ratios=[12,2.3,1.1],hspace=.04)
    ax=fig.add_subplot(grid[0]);ticks=[];labels=[];entries=[]
    for row,n in enumerate(schemes):
        y=len(schemes)-1-row; ticks.append(y);labels.append(f'MCPE{n}  ({n//3}+{n//3}+{n//3})')
        slots=cfg['configs']['sync'][str(n)]['slots'];assert len(slots)==n
        assert len({s['name'] for s in slots})==len(cfg['configs']['sync'][str(n)]['unique_parameters'])
        for slot in slots:
            g=slot['group'];rank=slot['rank'];t=slot['entry_TU']
            assert t==20000+6000*(rank-1)+(0 if g==0 else 2000)
            assert slot['name']==cfg['groups'][g][rank-1]
            channels=range(5) if g==0 else ([5,6] if g==1 else [7])
            for ch in channels:
                assert cfg['configs']['sync'][str(n)]['entries_steps'][slot['name']][ch]==round(t/cfg['dt_TU'])
            bottom=y-.34 if g in [0,2] else y
            height=.68 if g==0 else .34
            width=2 if g==0 else 4
            stage_end=t+width*1000
            assert stage_end==20000+6000*(rank-1)+(2000 if g==0 else 6000)
            rect=Rectangle((t/1000,bottom),width,height,facecolor=colors[g],edgecolor='white',linewidth=.8)
            ax.add_patch(rect)
            ax.text(t/1000+width/2,bottom+height/2,slot['name'],ha='center',va='center',fontsize=9.1,color='white',fontweight='bold')
            entries.append({'scheme':n,**slot,'box_end_TU':stage_end,'box_width_TU':width*1000})
        for rank in range(1,n//3+1):
            rr=[s for s in entries if s['scheme']==n and s['rank']==rank]
            water=next(s for s in rr if s['group']==0)
            cc=next(s for s in rr if s['group']==1)
            alk=next(s for s in rr if s['group']==2)
            assert water['box_end_TU']==cc['entry_TU']==alk['entry_TU']
            assert cc['box_end_TU']==alk['box_end_TU']==20000+6000*rank
            if rank<n//3:
                following=next(s for s in slots if s['group']==0 and s['rank']==rank+1)
                assert cc['box_end_TU']==following['entry_TU']
    ax.set(xlim=(20,80),ylim=(-.65,7.15),yticks=ticks,yticklabels=labels,
           xlabel='Time (TU)',ylabel='Scheme')
    ax.set_xticks(list(range(20,81,6)))
    ax.set_xticklabels([str(x*1000) for x in range(20,81,6)])
    ax.set_xticks(list(range(20,81,2)),minor=True)
    ax.grid(axis='x',which='major',color='#DDDDDD',lw=.7)
    ax.grid(axis='x',which='minor',color='#F0F0F0',lw=.5)
    ax.set_axisbelow(True);ax.tick_params(axis='y',length=0)
    ax.set_title('MCPE entry timeline',fontsize=19,pad=14)
    ax.legend(handles=[Patch(facecolor=c,label=l) for c,l in zip(colors,
              ['Water cycle parameters','Carbon parameters: Catm / Cocean channel','Carbon parameters: ALK channel'])],
              loc='upper right',fontsize=11,framealpha=.97)
    phase=fig.add_subplot(grid[1]);phase.set(xlim=(0,100),ylim=(0,1.6))
    for start,width,color,label in [(0,10,'#A7A7A7','Spin-up'),(10,10,'#5E8FD2','Pure CDA')]:
        phase.add_patch(Rectangle((start,.22),width,.65,facecolor=color,edgecolor='white'))
        phase.text(start+width/2,.55,label,ha='center',va='center',color='white',fontsize=11)
    phase.add_patch(Rectangle((20,.22),80,.65,facecolor='#F1C6B5',edgecolor='white'))
    phase.text(60,.55,'State assimilation + parameter estimation',ha='center',va='center',fontsize=12)
    phase.annotate('',xy=(20,1.15),xytext=(76,1.15),arrowprops={'arrowstyle':'|-|','color':'#A14E34','lw':1.3})
    phase.text(48,1.25,'Progressive channel entry (20000–76000 TU)',ha='center',fontsize=11)
    phase.add_patch(Rectangle((90,.94),10,.21,facecolor='#D9A90D',edgecolor='none'))
    phase.text(95,1.25,'RMSE window',ha='center',fontsize=10.5)
    phase.set_xticks([0,10,20,40,60,76,90,100]);phase.set_xticklabels(['0','10000','20000','40000','60000','76000','90000','100000'])
    phase.set_xlabel('Time (TU)',fontsize=12);phase.set_yticks([])
    for spine in phase.spines.values():spine.set_visible(False)
    phase.tick_params(length=0)
    note=fig.add_subplot(grid[2]);note.axis('off')
    note.text(.5,.95,'Orange: 2000-TU entry stage; blue/green: 4000-TU entry stage. Entered parameters remain under estimation.',ha='center',va='top',fontsize=11,transform=note.transAxes)
    note.text(.5,.62,'Stacked blue/green boxes enter simultaneously. Shared parameters retain one ensemble; MCPE numbers count group slots.',ha='center',va='top',fontsize=11,transform=note.transAxes)
    note.text(.5,.29,'RMSE: 90000–100000 TU. For 8obs, assimilation and estimation continue to 150000 TU; PSD: 100000–150000 TU (not shown).',ha='center',va='top',fontsize=10.5,transform=note.transAxes)
    dest=OUT/'MCPE12-30_parameter_entry_timeline_continuous.png'
    fig.savefig(dest,dpi=300,facecolor='white');plt.close(fig)
    with Image.open(dest) as im:
        assert im.size==(6300,3000)
        im.thumbnail((1600,850));im.convert('RGB').save(OUT/'preview.jpg',quality=80)
    assert digest==hashlib.sha256(SRC.read_bytes()).hexdigest()
    audit={'source':str(SRC),'source_sha256':digest,'schemes':schemes,'entries':entries,
           'checked_against_step_channel_arrays':True,'continuous_stage_boundaries_checked':True,
           'last_entry_TU':max(s['entry_TU'] for s in entries),'last_display_stage_end_TU':max(s['box_end_TU'] for s in entries),
           'output':str(dest),'pixels':[6300,3000]}
    (OUT/'validation.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in audit.items() if k!='entries'},ensure_ascii=False))

if __name__=='__main__':main()
